# Atlas Pages Bundle: Home, Ledger, Guard Report

## Routes (the three pages you asked for)
- `src/routes/index.tsx` — Home / workspace shell (5,187 lines, the main coordinator)
- `src/routes/ledger.tsx` — Decision Ledger page (Committed / In Tension / Overridden grouped view)
- `src/routes/guard-report.tsx` — Guard Report page (output-guard validation results)

## Supporting code (everything they import)
- `src/styles.css` — design tokens (--accent-gold, --phosphor, --ember, --shell-edge)
- `src/components/atlas/*` — every Atlas component used across the three routes
  - Ledger-specific: `DecisionLedgerGrouped.tsx`, `EntryCard.tsx`, `StatusTag.tsx`, `MemoryChips.tsx`
  - Home-specific: `DesktopWorkspace.tsx`, `MobileShell.tsx`, `ProjectHeaderCenter.tsx`,
    `SessionBreadcrumb.tsx`, `SovereignScrubRail.tsx`, `BuildStateTimeline.tsx`,
    `AtlasFrontDoor.tsx`, `BelowFoldDashboard.tsx`, `CommitCard.tsx`, `DecisionCatchCard.tsx`,
    `ThreadAnchor.tsx`, `CommitPrompt.tsx`, etc.
- `src/lib/` — `atlas.ts`, `entries.ts`, `atlas-status.ts`, `decision-catch.ts`, `artifacts.ts`,
  `haptics.ts`, `auth.tsx`, `utils.ts`
- `src/hooks/` — `use-mobile.tsx`, `useMediaQuery.ts`, `useVoiceInput.ts`

Unzip next to your branch and diff folder-to-folder.
