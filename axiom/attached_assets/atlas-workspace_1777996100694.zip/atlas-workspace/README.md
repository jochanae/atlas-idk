# Atlas Workspace Bundle

Snapshot of the workspace surface (route /, the chat/workspace/preview shell).

## Entry points
- src/routes/index.tsx          — WorkspacePage (5187 lines, holds all state)
- src/routes/__root.tsx         — Root layout
- src/router.tsx                — Router config
- src/styles.css                — Design tokens (--phosphor, --ember, --accent-gold, --shell-edge)

## Header
- components/atlas/AtlasLogo.tsx
- components/atlas/ProjectHeaderCenter.tsx
- components/atlas/SessionBreadcrumb.tsx
- components/atlas/UserAvatar.tsx, UserMenu.tsx, ThemeDropdown.tsx
- components/atlas/SystemMenu.tsx
- components/atlas/ContextualHUD.tsx

## Gold timeline rail (vertical)
- components/atlas/SovereignScrubRail.tsx

## Build state timeline (horizontal)
- components/atlas/BuildStateTimeline.tsx

## Shell layouts
- components/atlas/DesktopWorkspace.tsx
- components/atlas/MobileShell.tsx
- components/atlas/MobileSurfaceBar.tsx

## Body / surfaces
- components/atlas/AtlasFrontDoor.tsx
- components/atlas/BelowFoldDashboard.tsx
- components/atlas/StreamingText.tsx
- components/atlas/CommitCard.tsx, DecisionCatchCard.tsx, MemoryChips.tsx
- components/atlas/ThreadAnchor.tsx, CommitPrompt.tsx
- components/atlas/ThinkingPromptCard.tsx, GlossaryCard.tsx
- components/atlas/ProjectGallery.tsx, TaskQueue.tsx, DependencyGraph.tsx, LiveConsoleStream.tsx

## Drawers / panels
- All *Drawer.tsx and *Panel.tsx files in components/atlas/

## Footer
- components/atlas/AtlasFooterNav.tsx
- components/atlas/SessionFooter.tsx
- components/atlas/FooterAuditLine.tsx

## Logic
- lib/atlas.ts, atlas-status.ts, entries.ts, decision-catch.ts, artifacts.ts, haptics.ts, auth.tsx
- hooks/useMediaQuery.ts, useVoiceInput.ts, use-mobile.tsx
