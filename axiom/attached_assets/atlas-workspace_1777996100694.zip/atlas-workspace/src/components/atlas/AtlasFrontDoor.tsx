import { type ReactNode, useEffect, useRef, useState } from "react";
import { haptic } from "@/lib/haptics";
import { RotatingPlaceholder } from "./RotatingPlaceholder";
import { AtlasLogo } from "./AtlasLogo";
import { SystemMenu } from "./SystemMenu";
import { AttachedFilesChips } from "./AttachedFilesChips";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { PlanPanel } from "./PlanPanel";
import type { PlanStep } from "./DependencyGraph";

export const MODES = [
  { id: "think", label: "Think", color: "ember" },
  { id: "plan", label: "Plan", color: "accent-gold" },
  { id: "build", label: "Build", color: "ember" },
  { id: "explore", label: "Explore", color: "phosphor" },
  { id: "decide", label: "Decide", color: "ember" },
  { id: "audit", label: "Audit", color: "ember" },
] as const;

export type ModeId = typeof MODES[number]["id"];

const MODE_PLACEHOLDERS: Record<ModeId, string> = {
  think: "What are you turning over?",
  plan: "Map the next move…",
  build: "What are you putting together?",
  explore: "What are you curious about?",
  decide: "What are you choosing between?",
  audit: "What's worth a second look?",
};

/** Minimalist SVG icons for each mode — 16×16 viewBox, stroke-based */
export function ModeIcon({ mode, size = 13 }: { mode: ModeId; size?: number }) {
  const s = { width: size, height: size, flexShrink: 0 } as const;
  const common = { viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (mode) {
    case "think":
      return (<svg {...common} style={s}><path d="M8 1a4.5 4.5 0 0 0-1.5 8.74V12h3V9.74A4.5 4.5 0 0 0 8 1z" /><path d="M6.5 13.5h3M7 15h2" /></svg>);
    case "plan":
      return (<svg {...common} style={s}><circle cx="8" cy="4" r="2" /><circle cx="4" cy="12" r="2" /><circle cx="12" cy="12" r="2" /><path d="M8 6v2M6.5 10.5 7.5 8M9.5 10.5 8.5 8" /></svg>);
    case "build":
      return (<svg {...common} style={s}><path d="M5 2v12M11 2v12M5 5h6M5 11h6" /></svg>);
    case "explore":
      return (<svg {...common} style={s}><circle cx="8" cy="8" r="6" /><path d="M8 2v2M8 12v2M2 8h2M12 8h2" /><path d="M8 5l2 3-2 3-2-3z" fill="currentColor" stroke="none" /></svg>);
    case "decide":
      return (<svg {...common} style={s}><path d="M4 8.5l2.5 3L12 5" /></svg>);
    case "audit":
      return (<svg {...common} style={s}><path d="M4 2h8l1 3v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5z" /><path d="M6 7h4M6 10h2" /></svg>);
  }
}

export interface RecentSession {
  id: string;
  title: string;
  mode: string | null;
  created_at: string;
  /** Last actual chat message in this session — used for the living-thread line. */
  last_message?: string | null;
}

type AtlasFrontDoorProps = {
  active: boolean;
  activeMode: ModeId;
  input: string;
  sending: boolean;
  headerActions: ReactNode;
  /** Center element for the header (project name + dropdown). Falls back to "Atlas" wordmark. */
  headerCenter?: ReactNode;
  bottomTabs?: ReactNode;
  secondaryPanel?: ReactNode;
  utilityBarLeft?: ReactNode;
  utilityBarRight?: ReactNode;
  inputFocusSignal: number;
  sidebarToggle?: ReactNode;
  userName?: string | null;
  /** Recent sessions shown under the resting input as "Continue where you left off". */
  recents?: RecentSession[];
  onOpenSession?: (sessionId: string) => void;
  /** Optional handler invoked when the user taps "View all" under recents. */
  onViewAllRecents?: () => void;
  onModeChange: (mode: ModeId) => void;
  onInputChange: (value: string) => void;
  onSend: (text: string, mode: ModeId) => void;
  /** Cancels the in-flight Atlas request. Required when sending=true. */
  onStop?: () => void;
  onWordmarkClick?: () => void;
  /** Props forwarded to SystemMenu for file upload */
  userId?: string;
  projectId?: string | null;
  onFilesUploaded?: (files: Array<{ name: string; url: string; type: string }>) => void;
  /** Files currently attached to the next outgoing message — rendered as chips above the textarea. */
  attachedFiles?: Array<{ name: string; url: string; type: string }>;
  /** Remove a single attached file by index. */
  onRemoveAttachedFile?: (index: number) => void;
  /** Called when user selects "Build" from system menu or uses /build command */
  onGenerateCode?: (prompt: string) => void;
  /** Called when user opens a system menu feature drawer */
  onSystemMenuSelect?: (id: string) => void;
  /** Contextual HUD element rendered above the active input */
  contextualHUD?: ReactNode;
  taskQueue?: ReactNode;
  /** When true, placeholder switches to queue-specific language */
  queueActive?: boolean;
  onAddToQueue?: (text: string) => void;
  /** Plan mode dependency graph (rendered above queue when Plan is active) */
  planGraph?: ReactNode;
  /** Plan steps for PlanPanel */
  planSteps?: PlanStep[];
  /** One-tap queue a single plan step */
  onQueuePlanStep?: (step: PlanStep) => void;
  /** Queue all plan steps at once */
  onQueueAllPlanSteps?: () => void;
  /** Expand/drill into a plan step */
  onExpandPlanStep?: (step: PlanStep) => void;
  /** Adaptive placeholder set from external tap events */
  adaptivePlaceholder?: string | null;
  /** Mobile surface bar rendered below header in active mode */
  mobileSurfaceBar?: ReactNode;
  /** Voice input controls */
  voiceListening?: boolean;
  onVoiceToggle?: () => void;
  /** Below-the-fold dashboard sections — only shown in resting (non-active) view. */
  belowFold?: ReactNode;
  children?: ReactNode;
};

function ModeDropdown({ activeMode, onModeChange }: { activeMode: ModeId; onModeChange: (m: ModeId) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [open]);

  const m = MODES.find((x) => x.id === activeMode)!;
  const isPhosphor = m.color === "phosphor";
  const isGold = m.color === "accent-gold";
  const accent = isGold ? "var(--accent-gold)" : isPhosphor ? "var(--phosphor)" : "var(--ember)";
  const glow = isGold ? "rgba(202,169,104,0.35)" : isPhosphor ? "rgba(6,182,212,0.35)" : "rgba(234,88,12,0.4)";

  return (
    <div ref={ref} style={{ position: "fixed", top: "var(--mode-pill-top)", left: 0, right: 0, zIndex: 9999, display: "flex", justifyContent: "center", pointerEvents: "none" }}>
      <div style={{ position: "relative", pointerEvents: "auto" }}>
        <button
          type="button"
          onClick={() => { setOpen((o) => !o); haptic("light"); }}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            minHeight: 44,
            padding: "10px 18px",
            borderRadius: 999,
            border: `0.5px solid ${accent}`,
            background: "color-mix(in oklab, var(--surface) 86%, transparent)",
            backdropFilter: "blur(15px)",
            WebkitBackdropFilter: "blur(15px)",
            fontFamily: "var(--font-sans)",
            fontWeight: 400,
            fontSize: 13,
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            color: accent,
            boxShadow: `0 0 14px -3px ${glow}`,
            cursor: "pointer",
            transition: "all 180ms var(--ease-cinematic)",
          }}
          title="Switch mode"
        >
          <span className="atlas-mode-icon"><ModeIcon mode={activeMode} size={13} /></span>
          {m.label}
          <svg viewBox="0 0 16 16" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ marginLeft: 2, transform: open ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 200ms ease" }}>
            <path d="M4 6l4 4 4-4" />
          </svg>
        </button>
        {open && (
          <div
            style={{
              position: "absolute",
              top: "calc(100% + 8px)",
              left: "50%",
              transform: "translateX(-50%)",
              background: "var(--glass-bg)",
              backdropFilter: "blur(var(--glass-blur)) saturate(140%)",
              WebkitBackdropFilter: "blur(var(--glass-blur)) saturate(140%)",
              border: "0.5px solid var(--glass-border)",
              borderRadius: 16,
              padding: "8px",
              boxShadow: "0 12px 40px rgba(0,0,0,0.3)",
              minWidth: 188,
              zIndex: 9999,
              animation: "atlas-sys-menu-in 180ms ease forwards",
            }}
          >
            {MODES.map((mode) => {
              const isActive = mode.id === activeMode;
              const mp = mode.color === "phosphor";
              const mg = mode.color === "accent-gold";
              const c = mg ? "var(--accent-gold)" : mp ? "var(--phosphor)" : "var(--ember)";
              return (
                <button
                  key={mode.id}
                  onClick={() => { onModeChange(mode.id); setOpen(false); haptic("light"); }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    width: "100%",
                    minHeight: 48,
                    padding: "12px 14px",
                    border: "none",
                    borderRadius: 12,
                    background: isActive ? "rgba(212, 175, 55, 0.08)" : "transparent",
                    fontFamily: "var(--font-sans)",
                    fontWeight: 400,
                    fontSize: 13,
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    color: isActive ? c : "var(--muted-text)",
                    cursor: "pointer",
                    transition: "background 120ms ease, color 120ms ease",
                  }}
                >
                  <ModeIcon mode={mode.id} size={14} />
                   {mode.label}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * ThreadReveal — shows three pulsing "Atlas thinking" dots for 1.5s on mount,
 * then fades them out and crossfades the living-thread line in. The dots
 * always show (even with no recent message) to preserve the rhythm.
 */
function ThreadReveal({ lastMessage }: { lastMessage: string | null }) {
  const [revealed, setRevealed] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setRevealed(true), 1500);
    return () => clearTimeout(t);
  }, []);

  // Three persistent pulsing dots — render inline before text once revealed,
  // centered alone (no message yet) before reveal.
  const Dots = (
    <span
      aria-hidden
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        flexShrink: 0,
        verticalAlign: "middle",
      }}
    >
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          style={{
            width: 4,
            height: 4,
            borderRadius: "50%",
            background: "var(--accent-gold)",
            opacity: 0.5,
            animation: `atlas-thinking-pulse 1400ms ease-in-out ${i * 180}ms infinite`,
          }}
        />
      ))}
    </span>
  );

  return (
    <div
      style={{
        marginTop: 8,
        minHeight: 38,
        display: "flex",
        alignItems: lastMessage ? "flex-start" : "center",
        justifyContent: "center",
        gap: 10,
        position: "relative",
        padding: "0 4px",
      }}
    >
      {/* Dots — always visible. When alone, centered under the greeting.
          When paired with text, sit inline at the text baseline. */}
      <span
        style={{
          paddingTop: lastMessage ? 7 : 0,
          opacity: revealed || !lastMessage ? 1 : 0.7,
          transition: "opacity 400ms ease",
        }}
      >
        {Dots}
      </span>

      {/* Living thread */}
      {lastMessage && (
        <div
          style={{
            fontSize: 12.5,
            fontWeight: 300,
            lineHeight: 1.5,
            color: "var(--muted-text)",
            opacity: revealed ? 0.65 : 0,
            fontStyle: "italic",
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
            fontFamily: "var(--font-sans)",
            transition: "opacity 600ms ease 100ms",
          }}
          title={lastMessage}
        >
          {lastMessage}
        </div>
      )}
    </div>
  );
}


export function AtlasFrontDoor({
  active,
  activeMode,
  input,
  sending,
  headerActions,
  headerCenter,
  bottomTabs,
  secondaryPanel,
  utilityBarLeft,
  utilityBarRight,
  inputFocusSignal,
  sidebarToggle,
  userName,
  recents,
  onOpenSession,
  onViewAllRecents,
  onModeChange,
  onInputChange,
  onSend,
  onStop,
  onWordmarkClick,
  userId,
  projectId,
  onFilesUploaded,
  attachedFiles,
  onRemoveAttachedFile,
  onGenerateCode,
  onSystemMenuSelect,
  contextualHUD,
  taskQueue,
  queueActive,
  onAddToQueue,
  planGraph,
  planSteps,
  onQueuePlanStep,
  onQueueAllPlanSteps,
  onExpandPlanStep,
  adaptivePlaceholder,
  mobileSurfaceBar,
  voiceListening,
  onVoiceToggle,
  belowFold,
  children,
}: AtlasFrontDoorProps) {
  const pillsRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [pillsOverflow, setPillsOverflow] = useState(false);
  const [pillsAtEnd, setPillsAtEnd] = useState(false);
  const [pillsAtStart, setPillsAtStart] = useState(true);

  const TEXTAREA_MIN_HEIGHT = 48;
  const TEXTAREA_MAX_HEIGHT_RESTING = 160;
  // Active mode: cap at 40% of viewport so keyboard + chat stay visible
  const TEXTAREA_MAX_HEIGHT_ACTIVE = typeof window !== "undefined" ? Math.round(window.innerHeight * 0.4) : 200;

  const adjustTextareaHeight = (element: HTMLTextAreaElement | null, maxH?: number) => {
    if (!element) return;
    const cap = maxH ?? (active ? TEXTAREA_MAX_HEIGHT_ACTIVE : TEXTAREA_MAX_HEIGHT_RESTING);
    element.style.height = "0px";
    const nextHeight = Math.max(TEXTAREA_MIN_HEIGHT, Math.min(element.scrollHeight, cap));
    element.style.height = `${nextHeight}px`;
    element.style.overflowY = element.scrollHeight > cap ? "auto" : "hidden";
  };

  const handleInputChange = (value: string) => {
    onInputChange(value);
    requestAnimationFrame(() => adjustTextareaHeight(textareaRef.current));
  };

  useEffect(() => {
    const row = pillsRef.current;
    if (!row) return;

    const updateOverflow = () => {
      setPillsOverflow(row.scrollWidth > row.clientWidth + 2);
      setPillsAtStart(row.scrollLeft < 4);
      setPillsAtEnd(row.scrollLeft + row.clientWidth >= row.scrollWidth - 4);
    };

    updateOverflow();
    row.addEventListener("scroll", updateOverflow, { passive: true });

    if (typeof ResizeObserver !== "undefined") {
      const observer = new ResizeObserver(updateOverflow);
      observer.observe(row);
      const inner = row.firstElementChild;
      if (inner instanceof HTMLElement) observer.observe(inner);
      return () => { observer.disconnect(); row.removeEventListener("scroll", updateOverflow); };
    }

    window.addEventListener("resize", updateOverflow);
    return () => { window.removeEventListener("resize", updateOverflow); row.removeEventListener("scroll", updateOverflow); };
  }, []);

  useEffect(() => {
    if (inputFocusSignal > 0) textareaRef.current?.focus();
  }, [inputFocusSignal]);

  useEffect(() => {
    adjustTextareaHeight(textareaRef.current);
  }, [input, active]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // In resting mode, Enter sends. In active mode, Enter = newline, only send button submits.
    if (!active && e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSend(input, activeMode);
    }
    // In active mode, Enter always inserts newline (default textarea behavior)
  };

  const showPlaceholder = !input && !active;

  return (
    <div
      style={{
        background: "var(--background)",
        height: "100dvh",
        minHeight: "100dvh",
        width: "100%",
        maxWidth: "100%",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        overflow: "hidden",
        overflowX: "clip",
        boxSizing: "border-box",
      }}
    >
      {/* Sovereign Glass header — see-through, frosted glassmorphism */}
      <div
        className="atlas-sticky-header atlas-sovereign-glass"
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          width: "100%",
          maxWidth: "100%",
          zIndex: 50,
          display: "grid",
          gridTemplateColumns: "auto 1fr auto",
          alignItems: "center",
          padding: "10px clamp(10px, 3vw, 16px) 8px",
          minHeight: "fit-content",
          gap: 8,
          background: "transparent",
          backdropFilter: "blur(24px) saturate(150%)",
          WebkitBackdropFilter: "blur(24px) saturate(150%)",
          borderBottom: "0.5px solid var(--glass-border)",
          flexShrink: 0,
          boxSizing: "border-box",
        }}
      >
        {/* Left: sidebar toggle + Atlas wordmark */}
        <div style={{ display: "flex", alignItems: "center", gap: 4, minHeight: 36, flexShrink: 0 }}>
          {sidebarToggle}
          {(
            <button
              onClick={() => { onWordmarkClick?.(); haptic("light"); }}
              style={{
                background: "transparent",
                border: "none",
                padding: 0,
                height: 36,
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                fontSize: 16,
                fontWeight: 500,
                color: "var(--foreground)",
                letterSpacing: "0.08em",
                lineHeight: 1,
                cursor: onWordmarkClick ? "pointer" : "default",
              }}
            >
              <span
                aria-label="Atlas"
                style={{ color: "var(--foreground)", display: "inline-flex", alignItems: "center", gap: 8 }}
              >
                <AtlasLogo size={22} strokeWidth={1.6} />
                <span
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 15,
                    fontWeight: 500,
                    letterSpacing: "0.06em",
                    color: "var(--foreground)",
                    lineHeight: 1,
                  }}
                >
                  Atlas
                </span>
              </span>
            </button>
          )}
        </div>

        {/* Center: project name + mode (active) or empty (resting) */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", minWidth: 0, gap: 0 }}>
          {headerCenter}
          {/* Surface breadcrumb (collapsible MobileSurfaceBar sits here) */}
          {active && mobileSurfaceBar && (
            <div style={{ marginTop: -2 }}>
              {mobileSurfaceBar}
            </div>
          )}
        </div>

        {/* Right: actions + avatar */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 36, justifyContent: "flex-end", flexShrink: 0 }}>
          {headerActions}
        </div>
      </div>

      {/* Stage: scrollable content area beneath fixed header */}
      <div
        style={{
          flex: 1,
          minHeight: 0,
          minWidth: 0,
          width: "100%",
          maxWidth: "100%",
          position: "relative",
          display: "flex",
          flexDirection: "column",
          overflowY: "auto",
          overflowX: "clip",
          scrollBehavior: "smooth",
          boxSizing: "border-box",
          paddingTop: active
            ? "calc(var(--header-height) + 16px)"
            : "calc(var(--header-height) + 16px)",
        }}
      >
        {/* Resting hero — greeting, pills, input. Fades/translates out on activate. */}
        <div
          aria-hidden={active}
          style={{
            position: active ? "absolute" : "relative",
            inset: active ? 0 : "auto",
            flex: active ? "none" : undefined,
            minHeight: active ? undefined : "calc(100dvh - var(--header-height))",
            flexShrink: 0,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "stretch",
            padding: "8vh 0 4vh",
            opacity: active ? 0 : 1,
            transform: active ? "translateY(-20px)" : "translateY(0)",
            pointerEvents: active ? "none" : "auto",
            transition:
              "opacity 400ms cubic-bezier(0.4, 0, 0.2, 1), transform 400ms cubic-bezier(0.4, 0, 0.2, 1)",
            willChange: "opacity, transform",
          }}
        >
          <div style={{ textAlign: "center", padding: "0 24px 28px" }}>
            <div
              className="atlas-greeting"
              style={{
                fontWeight: 300,
                fontSize: 22,
                color: "var(--foreground)",
                lineHeight: 1.3,
                letterSpacing: "-0.005em",
                opacity: 0.85,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              Where were we.
            </div>
            <ThreadReveal lastMessage={recents?.[0]?.last_message ?? null} />

          </div>

          {/* Input — centered, etched glass with focus glow */}
          <div
            className="atlas-input-shell"
            style={{
              margin: "0 var(--shell-edge)",
              background: "rgba(18, 18, 22, 0.65)",
              backdropFilter: "blur(24px) saturate(140%)",
              WebkitBackdropFilter: "blur(24px) saturate(140%)",
              borderRadius: "var(--input-radius)",
              border: "1px solid var(--accent-gold)",
              padding: "20px 22px",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,0.03)",
              position: "relative",
              transition: "border-color 220ms var(--ease-cinematic), box-shadow 220ms var(--ease-cinematic)",
            }}
          >
            <AttachedFilesChips files={attachedFiles ?? []} onRemove={onRemoveAttachedFile} />
            <div style={{ position: "relative" }}>
              {showPlaceholder && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: 0,
                    color: "var(--muted-text)",
                    fontSize: 18,
                    lineHeight: 1.55,
                    opacity: 0.85,
                    pointerEvents: "none",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    fontFamily: "var(--font-sans)",
                  }}
                >
                  {adaptivePlaceholder ? (
                    <span aria-hidden style={{ pointerEvents: "none" }}>{adaptivePlaceholder}</span>
                  ) : queueActive ? (
                    <span aria-hidden style={{ pointerEvents: "none" }}>add a follow-up to the queue…</span>
                  ) : (
                    <RotatingPlaceholder mode={activeMode} paused={false} />
                  )}
                </div>
              )}
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={2}
                style={{
                  width: "100%",
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: "var(--foreground)",
                  fontSize: 18,
                  lineHeight: 1.6,
                  resize: "none",
                  fontFamily: "var(--font-sans)",
                  position: "relative",
                  zIndex: 1,
                  minHeight: 60,
                  maxHeight: TEXTAREA_MAX_HEIGHT_RESTING,
                  overflowY: "hidden",
                  display: "block",
                }}
              />
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: 12,
                gap: 12,
              }}
            >
              {/* Left: system menu trigger */}
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <SystemMenu
                  userId={userId}
                  projectId={projectId}
                  onFilesUploaded={onFilesUploaded}
                  onSelect={(id) => {
                    onSystemMenuSelect?.(id);
                  }}
                />
                <button
                  type="button"
                  aria-label="Attach file"
                  title="Attach file"
                  className="atlas-utility-btn"
                  onClick={async () => {
                    if (!userId) {
                      toast.error("Sign in to attach files");
                      return;
                    }
                    const fileInput = document.createElement("input");
                    fileInput.type = "file";
                    fileInput.multiple = true;
                    fileInput.accept = "image/*,application/pdf,.doc,.docx,.txt,.csv,.json,.zip";
                    fileInput.onchange = async () => {
                      if (!fileInput.files?.length) return;
                      const uploaded: Array<{ name: string; url: string; type: string }> = [];
                      for (const file of Array.from(fileInput.files)) {
                        const path = `${userId}/${projectId ?? "general"}/${Date.now()}-${file.name}`;
                        const { error } = await supabase.storage
                          .from("project-assets")
                          .upload(path, file, { upsert: false });
                        if (error) {
                          toast.error(`Upload failed: ${file.name}`);
                          continue;
                        }
                        const { data: urlData } = supabase.storage
                          .from("project-assets")
                          .getPublicUrl(path);
                        uploaded.push({ name: file.name, url: urlData.publicUrl, type: file.type });
                      }
                      if (uploaded.length > 0) {
                        toast.success(`${uploaded.length} file${uploaded.length > 1 ? "s" : ""} attached`);
                        onFilesUploaded?.(uploaded);
                      }
                    };
                    fileInput.click();
                  }}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    background: "transparent",
                    border: "0.5px solid color-mix(in oklab, var(--border) 70%, transparent)",
                    color: "var(--muted-text)",
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    transition: "color 160ms ease, border-color 160ms ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = "var(--accent-gold)";
                    e.currentTarget.style.borderColor = "color-mix(in oklab, var(--accent-gold) 50%, transparent)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = "var(--muted-text)";
                    e.currentTarget.style.borderColor = "color-mix(in oklab, var(--border) 70%, transparent)";
                  }}
                >
                  <svg viewBox="0 0 16 16" width={13} height={13} stroke="currentColor" fill="none" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                    <path d="M13.2 7.3 8 12.5a3 3 0 1 1-4.2-4.2l5.6-5.6a2 2 0 1 1 2.8 2.8L6.6 11.1a1 1 0 1 1-1.4-1.4l4.9-4.9" />
                  </svg>
                </button>
              </div>

              {/* Right: hint + mic + send */}
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span
                  className="atlas-shortcut-hint"
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: 11,
                    letterSpacing: "0.06em",
                    color: "var(--muted-text)",
                    opacity: 0.45,
                    userSelect: "none",
                    whiteSpace: "nowrap",
                  }}
                >
                  type <span style={{ color: "var(--accent-gold)", opacity: 0.9 }}>/</span> for shortcuts
                </span>
                <button
                  type="button"
                  aria-label={voiceListening ? "Stop listening" : "Voice input"}
                  title={voiceListening ? "Stop listening" : "Voice input"}
                  className="atlas-icon-btn atlas-mic-btn"
                  onClick={onVoiceToggle}
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: 12,
                    background: "transparent",
                    border: "none",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 2,
                    color: "color-mix(in oklab, var(--accent-gold) 55%, var(--muted-text))",
                    cursor: "pointer",
                    opacity: 0.55,
                    transition: "opacity 160ms var(--ease-cinematic), color 160ms var(--ease-cinematic), transform 160ms var(--ease-cinematic)",
                    flexShrink: 0,
                  }}
                >
                  <svg viewBox="0 0 16 16" width={13} height={13} stroke="currentColor" fill="none" strokeWidth={1.6}>
                    <rect x="6" y="2" width="4" height="8" rx="2" />
                    <path d="M3.5 8a4.5 4.5 0 0 0 9 0M8 12.5V14" strokeLinecap="round" />
                  </svg>
                  {/* Waveform */}
                  <span className="atlas-wave" aria-hidden style={{ display: "inline-flex", alignItems: "center", gap: 1.5, height: 12 }}>
                    <i style={{ width: 1.5, background: "currentColor", borderRadius: 1, display: "block" }} />
                    <i style={{ width: 1.5, background: "currentColor", borderRadius: 1, display: "block" }} />
                    <i style={{ width: 1.5, background: "currentColor", borderRadius: 1, display: "block" }} />
                  </span>
                </button>
                <button
                  className="atlas-send-btn"
                  onClick={() => (sending ? onStop?.() : onSend(input, activeMode))}
                  disabled={sending ? !onStop : !input.trim()}
                  aria-label={sending ? "Stop Atlas" : "Send"}
                  title={sending ? "Stop Atlas" : "Send"}
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: 12,
                    background: sending
                      ? "var(--surface)"
                      : input.trim() ? "var(--ember)" : "var(--surface)",
                    border: sending
                      ? "0.5px solid var(--ember)"
                      : input.trim() ? "none" : "0.5px solid var(--border)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: sending || input.trim() ? "pointer" : "default",
                    boxShadow: !sending && input.trim() ? "0 0 16px -2px rgba(234,88,12,0.55)" : "none",
                    transition: "all 220ms var(--ease-cinematic)",
                  }}
                >
                  {sending ? (
                    <svg viewBox="0 0 16 16" width={12} height={12} fill="var(--ember)">
                      <rect x="3" y="3" width="10" height="10" rx="1.5" />
                    </svg>
                  ) : (
                    <svg viewBox="0 0 20 20" width={16} height={16} fill={input.trim() ? "var(--background)" : "none"} stroke={input.trim() ? "var(--background)" : "var(--muted-text)"} strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round">
                      <path d="M2.5 10L17 3 13 17l-3.5-5.5z" />
                      <path d="M17 3 9.5 11.5" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Scroll hint — one-time gentle bounce arrow signalling there's more below.
              Only shown in resting view when the dashboard exists below the fold. */}
          {!active && belowFold && (
            <button
              type="button"
              aria-label="Scroll to your workspace"
              onClick={() => {
                const el = document.getElementById("discovery-moment");
                if (el) {
                  el.scrollIntoView({ behavior: "smooth", block: "start" });
                  haptic("light");
                }
              }}
              style={{
                marginTop: 14,
                marginBottom: 4,
                background: "transparent",
                border: "none",
                padding: "6px 12px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 4,
                color: "var(--muted-text)",
                cursor: "pointer",
                alignSelf: "center",
                opacity: 0.55,
                transition: "opacity 200ms ease",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.opacity = "0.85"; }}
              onMouseLeave={(e) => { e.currentTarget.style.opacity = "0.55"; }}
            >
              <span
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: 9.5,
                  letterSpacing: "0.16em",
                  textTransform: "uppercase",
                }}
              >
                scroll for your workspace
              </span>
              <svg
                className="atlas-scroll-arrow"
                viewBox="0 0 16 16"
                width={14}
                height={14}
                fill="none"
                stroke="currentColor"
                strokeWidth={1.5}
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden
              >
                <path d="M4 6l4 4 4-4" />
              </svg>
            </button>
          )}

          {/* Inline timestamp — anchored under the input, in flow (not floating). */}
          <InlineTimestamp />

          {/* Continue where you left off — recent sessions list. Only when not active. */}
          {recents && recents.length > 0 && onOpenSession && (
            <div
              style={{
                margin: "20px 0 0",
                animation: "atlas-recents-in 480ms cubic-bezier(0.4, 0, 0.2, 1) 200ms backwards",
              }}
            >
              <div
                style={{
                  padding: "0 22px 6px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  fontFamily: "var(--font-mono)",
                  fontSize: 9.5,
                  letterSpacing: "0.14em",
                  textTransform: "uppercase",
                  color: "var(--muted-text)",
                  opacity: 0.7,
                }}
              >
                <span>Where were we</span>
                {recents.length > 3 && onViewAllRecents && (
                  <button
                    type="button"
                    onClick={onViewAllRecents}
                    style={{
                      background: "transparent",
                      border: "none",
                      padding: 0,
                      fontFamily: "var(--font-mono)",
                      fontSize: 9.5,
                      letterSpacing: "0.14em",
                      textTransform: "uppercase",
                      color: "var(--accent-gold)",
                      opacity: 0.85,
                      cursor: "pointer",
                    }}
                  >
                    View all →
                  </button>
                )}
              </div>
              <SessionHistoryList
                sessions={recents.slice(0, 3)}
                onOpenSession={onOpenSession}
              />
            </div>
          )}

        </div>

        {/* Below-the-fold dashboard — only in resting view */}
        {!active && belowFold && (
          <div style={{ flexShrink: 0, paddingBottom: "calc(var(--footer-nav-height, 62px) + 32px)" }}>
            {belowFold}
          </div>
        )}

        {/* Active session content — cross-fades in over the resting hero */}
        <div
          aria-hidden={!active}
          style={{
            position: active ? "relative" : "absolute",
            inset: active ? "auto" : 0,
            flex: active ? 1 : "none",
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            opacity: active ? 1 : 0,
            transform: active ? "translateY(0)" : "translateY(20px)",
            pointerEvents: active ? "auto" : "none",
            transition:
              "opacity 400ms cubic-bezier(0.4, 0, 0.2, 1), transform 400ms cubic-bezier(0.4, 0, 0.2, 1)",
            transitionDelay: active ? "120ms" : "0ms",
            willChange: "opacity, transform",
          }}
        >
          {/* ModeDropdown moved to fixed header area */}
          <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
            {children}
          </div>
        </div>
      </div>

      {/* Plan Mode — dedicated Plan/Blueprint panel */}
      {active && activeMode === "plan" && (
        <div
          style={{
            margin: "0 var(--shell-edge) 8px",
            flexShrink: 0,
            animation: "atlas-bubble-in 200ms ease forwards",
          }}
        >
          <PlanPanel
            steps={planSteps ?? []}
            graph={planGraph ?? <></>}
            onQueueStep={onQueuePlanStep}
            onQueueAll={onQueueAllPlanSteps}
            onExpandStep={onExpandPlanStep}
          />
        </div>
      )}

      {/* Task Queue — rendered above contextual HUD when items exist */}
      {active && taskQueue && (
        <div
          style={{
            margin: "0 var(--shell-edge) 8px",
            flexShrink: 0,
            animation: "atlas-bubble-in 200ms ease forwards",
          }}
        >
          {taskQueue}
        </div>
      )}

      {/* Floating Contextual HUD — glass layer above the input bar */}
      {active && contextualHUD && (
        <div
          style={{
            margin: "0 var(--shell-edge) 8px",
            flexShrink: 0,
            animation: "atlas-bubble-in 200ms ease forwards",
          }}
        >
          {contextualHUD}
        </div>
      )}

      {/* Active-mode input — fixed at bottom, floating above bezel */}
      {active && (
        <div
          className={`atlas-active-input-shell${sending ? " atlas-breathing" : ""}`}
          style={{
            position: "fixed",
            bottom: "calc(var(--footer-nav-height, 62px) + 24px)",
            left: 0,
            right: 0,
            width: "100%",
            maxWidth: "100%",
            zIndex: 48,
            margin: 0,
            padding: "0 var(--shell-edge) 0",
            paddingBottom: "24px",
            background: "transparent",
            overflowX: "clip",
            boxSizing: "border-box",
          }}
        >
          <div
            className="atlas-active-input-card"
            style={{
              backdropFilter: "blur(24px) saturate(140%)",
              WebkitBackdropFilter: "blur(24px) saturate(140%)",
              borderRadius: "var(--input-radius)",
              border: sending
                ? "1px solid color-mix(in oklab, var(--accent-gold) 70%, transparent)"
                : "1px solid var(--accent-gold)",
              padding: "16px 18px 12px",
              boxShadow: sending
                ? "inset 0 1px 0 color-mix(in oklab, var(--foreground) 4%, transparent), 0 0 20px -4px color-mix(in oklab, var(--accent-gold) 25%, transparent)"
                : "inset 0 1px 0 color-mix(in oklab, var(--foreground) 4%, transparent), 0 8px 28px -10px rgba(0,0,0,0.45)",
              transition: "border-color 220ms var(--ease-cinematic), box-shadow 220ms var(--ease-cinematic)",
              flexShrink: 0,
            }}
          >
          <AttachedFilesChips files={attachedFiles ?? []} onRemove={onRemoveAttachedFile} />
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              adaptivePlaceholder
                ? adaptivePlaceholder
                : queueActive
                  ? "add a follow-up to the queue…"
                  : MODE_PLACEHOLDERS[activeMode]
            }
            rows={1}
            style={{
              width: "100%",
              background: "transparent",
              border: "none",
              outline: "none",
              color: "var(--foreground)",
              fontSize: 18,
              lineHeight: 1.6,
              letterSpacing: "-0.01em",
              resize: "none",
              fontFamily: "var(--font-sans)",
              padding: "6px 8px",
              minHeight: 60,
              maxHeight: TEXTAREA_MAX_HEIGHT_ACTIVE,
              overflowY: "hidden",
              display: "block",
              scrollbarWidth: "thin",
              scrollbarColor: "color-mix(in oklab, var(--accent-gold) 30%, transparent) transparent",
            }}
          />
          {/* Utility Bar: 2 left (Plus, Paperclip) | right (Mic, More, Send) */}
          <div
            className="atlas-utility-bar"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              width: "100%",
              marginTop: 10,
              paddingTop: 10,
              borderTop: "0.5px solid color-mix(in oklab, var(--border) 70%, transparent)",
              gap: 8,
            }}
          >
            {/* Left group */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
              {utilityBarLeft}
            </div>
            {/* Right group + send */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
              {utilityBarRight}
              <button
                className="atlas-send-btn"
                onClick={() => (sending ? onStop?.() : onSend(input, activeMode))}
                disabled={sending ? !onStop : !input.trim()}
                aria-label={sending ? "Stop Atlas" : "Send"}
                title={sending ? "Stop Atlas" : "Send"}
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  background: sending
                    ? "transparent"
                    : input.trim() ? "var(--ember)" : "transparent",
                  border: sending
                    ? "0.5px solid var(--ember)"
                    : input.trim() ? "none" : "0.5px solid var(--border)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: sending || input.trim() ? 1 : 0.4,
                  cursor: sending || input.trim() ? "pointer" : "default",
                  transition: "all 220ms var(--ease-cinematic)",
                  flexShrink: 0,
                }}
              >
                {sending ? (
                  <svg viewBox="0 0 16 16" width={11} height={11} fill="var(--ember)">
                    <rect x="3" y="3" width="10" height="10" rx="1.5" />
                  </svg>
                ) : (
                  <svg viewBox="0 0 20 20" width={15} height={15} fill={input.trim() ? "var(--background)" : "none"} stroke={input.trim() ? "var(--background)" : "var(--muted-text)"} strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round">
                    <path d="M2.5 10L17 3 13 17l-3.5-5.5z" />
                    <path d="M17 3 9.5 11.5" />
                  </svg>
                )}
              </button>
            </div>
          </div>
          </div>
        </div>
      )}

      {secondaryPanel}
      {bottomTabs}

      <style>{`
        .atlas-greeting { font-size: 26px; }
        @media (max-width: 480px) {
          .atlas-greeting { font-size: 22px; }
        }
        @media (max-width: 420px) {
          .atlas-shortcut-hint { display: none; }
        }
        @media (max-width: 400px) {
          .atlas-pills-row { padding-left: 14px !important; padding-right: 14px !important; }
          .atlas-pills-inner { gap: 5px !important; padding-inline: 0 !important; }
          .atlas-mode-pill { font-size: 9.5px !important; padding: 4px 8px !important; letter-spacing: 0.04em !important; }
        }
        @media (max-width: 360px) {
          .atlas-greeting { font-size: 19px; }
          .atlas-mode-pill { font-size: 9px !important; padding: 3px 7px !important; }
          .atlas-input-shell, .atlas-active-input-shell { margin: 0 12px 20px !important; padding: 14px 14px !important; }
          .atlas-utility-btn { width: 34px !important; height: 34px !important; }
          .atlas-utility-bar { gap: 4px !important; }
        }
        @keyframes atlas-rise {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes atlas-pills-peek {
          0%   { transform: translateX(0); }
          40%  { transform: translateX(-24px); }
          100% { transform: translateX(0); }
        }
        @keyframes atlas-tag-in {
          from { opacity: 0; transform: translateY(-4px) scale(0.92); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes atlas-recents-in {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes atlas-thinking-pulse {
          0%, 100% { opacity: 0.25; transform: scale(0.85); }
          50%      { opacity: 1;    transform: scale(1); }
        }
        @keyframes atlas-scroll-arrow-bounce {
          0%   { transform: translateY(0); }
          20%  { transform: translateY(0); }
          45%  { transform: translateY(5px); }
          70%  { transform: translateY(0); }
          100% { transform: translateY(0); }
        }
        .atlas-scroll-arrow {
          animation: atlas-scroll-arrow-bounce 1600ms cubic-bezier(0.4, 0, 0.2, 1) 600ms 1 both;
        }
        @media (prefers-reduced-motion: reduce) {
          .atlas-scroll-arrow { animation: none; }
        }
        .atlas-input-shell:focus-within {
          border-color: color-mix(in oklab, var(--accent-gold) 55%, transparent) !important;
          box-shadow:
            inset 0 1px 0 rgba(255,255,255,0.05),
            0 8px 32px rgba(0,0,0,0.45),
            0 0 22px -6px color-mix(in oklab, var(--accent-gold) 55%, transparent) !important;
        }
        .atlas-active-input-shell:focus-within {
          border-color: color-mix(in oklab, var(--accent-gold) 55%, var(--border)) !important;
          box-shadow:
            inset 0 1px 0 rgba(255,255,255,0.04),
            0 6px 24px rgba(0,0,0,0.4),
            0 0 20px -4px color-mix(in oklab, var(--accent-gold) 50%, transparent) !important;
        }
        @keyframes atlas-breathing-glow {
          0%, 100% {
            border-color: rgba(212, 175, 55, 0.35);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.03), 0 6px 24px rgba(0,0,0,0.35), 0 0 12px -4px rgba(212, 175, 55, 0.2);
          }
          50% {
            border-color: rgba(212, 175, 55, 0.75);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.03), 0 6px 24px rgba(0,0,0,0.35), 0 0 24px -2px rgba(212, 175, 55, 0.45);
          }
        }
        .atlas-breathing {
          animation: atlas-breathing-glow 2.4s cubic-bezier(0.37, 0, 0.63, 1) infinite !important;
        }
        .atlas-active-input-shell textarea::-webkit-scrollbar {
          width: 3px;
        }
        .atlas-active-input-shell textarea::-webkit-scrollbar-track {
          background: transparent;
        }
        .atlas-active-input-shell textarea::-webkit-scrollbar-thumb {
          background: color-mix(in oklab, var(--accent-gold) 30%, transparent);
          border-radius: 2px;
        }
        .atlas-utility-btn {
          width: var(--touch-target-compact);
          height: var(--touch-target-compact);
          border-radius: 10px;
          background: transparent;
          border: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: color-mix(in oklab, var(--accent-gold) 50%, var(--muted-text));
          cursor: pointer;
          opacity: 0.7;
          transition: opacity 160ms var(--ease-cinematic), color 160ms var(--ease-cinematic), background 160ms var(--ease-cinematic);
          flex-shrink: 0;
          position: relative;
        }
        .atlas-utility-btn:hover {
          opacity: 1;
          color: var(--accent-gold);
          background: color-mix(in oklab, var(--accent-gold) 8%, transparent);
        }
        .atlas-utility-row {
          display: flex;
          gap: 12px;
          justify-content: center;
          width: 100%;
        }
        .atlas-utility-btn[data-active="true"] {
          opacity: 1;
          color: var(--accent-gold);
          background: color-mix(in oklab, var(--accent-gold) 12%, transparent);
        }
        .atlas-icon-btn:hover {
          opacity: 1 !important;
          color: var(--accent-gold) !important;
          transform: translateY(-1px);
        }
        .atlas-mic-btn .atlas-wave i {
          height: 3px;
          opacity: 0.75;
          animation: atlas-wave-bounce 1.1s ease-in-out infinite;
        }
        .atlas-mic-btn .atlas-wave i:nth-child(1) { animation-delay: 0ms; }
        .atlas-mic-btn .atlas-wave i:nth-child(2) { animation-delay: 140ms; }
        .atlas-mic-btn .atlas-wave i:nth-child(3) { animation-delay: 280ms; }
        @keyframes atlas-wave-bounce {
          0%, 100% { height: 3px; }
          50%      { height: 10px; }
        }
        .atlas-avatar:hover {
          transform: translateY(-1px) scale(1.04);
          border-color: color-mix(in oklab, var(--accent-gold) 80%, var(--border)) !important;
          box-shadow:
            0 0 0 3px color-mix(in oklab, var(--accent-gold) 18%, transparent),
            0 0 24px -2px color-mix(in oklab, var(--accent-gold) 55%, transparent),
            0 0 48px -8px color-mix(in oklab, var(--accent-gold) 25%, transparent),
            0 4px 18px -4px rgba(0,0,0,0.55) !important;
        }
      `}</style>
    </div>
  );
}

// Kept exported for other callers (HistoryPanel etc.) — not used on front door anymore.
export function SessionHistoryList({
  sessions,
  onOpenSession,
}: {
  sessions: RecentSession[];
  onOpenSession: (sessionId: string) => void;
}) {
  return (
    <>
      {sessions.map((session) => {
        const isPhosphor = session.mode === "explore";
        const dotColor = isPhosphor ? "#06B6D4" : session.mode ? "#EA580C" : "#2C2926";
        return (
          <button
            key={session.id}
            onClick={() => onOpenSession(session.id)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "10px 20px",
              border: "none",
              borderTop: "0.5px solid #1C1917",
              background: "transparent",
              cursor: "pointer",
              textAlign: "left",
            }}
          >
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: dotColor, flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0, overflow: "hidden" }}>
              <div
                style={{
                  fontSize: 13,
                  color: "#78716C",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  marginBottom: 2,
                  maxWidth: "100%",
                }}
              >
                {session.title || "Untitled session"}
              </div>
              <div
                style={{
                  fontFamily: "monospace",
                  fontSize: 10,
                  color: "#3C3530",
                  letterSpacing: "0.04em",
                  textTransform: "uppercase",
                }}
              >
                {session.mode || "think"}
              </div>
            </div>
            <span style={{ fontSize: 14, color: "#2C2926" }}>›</span>
          </button>
        );
      })}
    </>
  );
}

export function greetingFor(now: Date, name?: string | null): string {
  const h = now.getHours();
  const period = h < 12 ? "Morning" : h < 17 ? "Afternoon" : "Evening";
  const first = (name || "").trim().split(/\s+/)[0];
  return first ? `Good ${period}, ${first}.` : `Good ${period}.`;
}

function InlineTimestamp() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(id);
  }, []);
  const days = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const day = days[now.getDay()];
  const mon = months[now.getMonth()];
  const date = now.getDate();
  let h = now.getHours();
  const m = now.getMinutes().toString().padStart(2, "0");
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  const stamp = `${day} ${mon} ${date} | ${h}:${m} ${ampm}`;
  return (
    <div
      aria-hidden
      style={{
        textAlign: "center",
        padding: "10px 22px 0",
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        letterSpacing: "0.18em",
        color: "color-mix(in oklab, var(--foreground) 42%, transparent)",
        userSelect: "none",
      }}
    >
      {stamp}
    </div>
  );
}

