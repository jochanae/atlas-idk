# Axiom — Replit Agent Prompt: Footer Padding + Chat Input + Deposit to Vault

## Three Fixes. Read Every Section Before Touching Any Code.

---

## Fix 1: Footer Padding — Content Clipping

### The Problem
Content at the bottom of the screen is being clipped by the footer bar. The chat input area and last messages are partially hidden behind the footer.

### What To Fix

In `src/components/axiom/AxiomLayout.tsx` and `src/components/axiom/ChatHook.tsx`:

Add bottom padding to the scrollable content areas so content clears the footer:

```css
/* The main content area needs bottom padding to clear the footer */
padding-bottom: calc(80px + env(safe-area-inset-bottom, 0px));
```

80px accounts for the footer bar height including the raised button.

Also ensure the footer itself has proper safe area padding at the very bottom:

```css
/* Footer container */
padding-bottom: env(safe-area-inset-bottom, 8px);
```

Apply this to both the mobile layout and the flex mode layout.

---

## Fix 2: Chat Input Bar — Paperclip and Mic Positioning

### The Problem
The paperclip attachment icon and send button are not properly positioned within the chat input area. The mic icon is missing where it should appear.

### What To Fix

In `src/components/axiom/ChatHook.tsx`:

The input bar should have this layout:

```
[📎]  [text input field — flex 1]  [🎤]  [➤]
```

**Paperclip (📎):**
- Left side of input bar
- 44px tap target
- Muted silver icon, gold on tap
- Opens image picker (existing behavior)

**Microphone (🎤):**
- Right side of input bar, left of the send button
- 44px tap target
- Muted silver icon, gold when recording
- For now: wire to Web Speech API if available, otherwise show "Voice input coming soon" toast
- On devices that don't support it: hide the mic icon entirely (don't show a broken button)

```javascript
// Detect speech support
const speechSupported = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
```

**Send button (➤):**
- Far right
- Existing gold button — keep as-is

**Input field:**
- Takes remaining space between paperclip and mic
- Placeholder: "Describe your architecture..."
- Shift+Enter for new line
- Enter to send

**Input bar container style:**
```css
display: flex;
align-items: center;
gap: 8px;
padding: 10px 12px;
background: rgba(255, 255, 255, 0.05);
border: 1px solid rgba(212, 175, 55, 0.2);
border-radius: 14px;
```

---

## Fix 3: Deposit to Vault

### The Problem
There is no way to save a generated prompt to the Vault from either Quick Prompt or the main Chat Hook. This was planned but not yet implemented.

### What To Build

#### A: Quick Prompt — After Generation

In `src/components/axiom/QuickPrompt.tsx`:

After a prompt is successfully generated and displayed in the Gold Container, add a third button alongside Copy and Regenerate:

**"Save to Vault"** button:
- Style: outlined, gold border, gold text
- Icon: vault/archive icon (or small diamond ◆)
- Position: third button in the action row: `[Copy Prompt] [Regenerate] [Save to Vault]`

When tapped:
1. Save to `legacy_log` table in Supabase:
```javascript
await supabase.from('legacy_log').insert({
  prompt_output: generatedPrompt,
  builder: selectedBuilder,
  compatibility_score: null,
  created_at: new Date().toISOString(),
  // Add these new columns if they don't exist, or use existing structure:
  // input_description: userInput,
  // project_context: projectContext,
  // mode: 'quick'
});
```
2. Show success toast: **"Saved to Vault ◆"** in gold for 2 seconds
3. Button briefly turns fully gold to confirm

If Supabase save fails — show error toast: "Save failed. Try again." Don't block the UI.

#### B: Main Chat Hook — After AI Response

In `src/components/axiom/ChatHook.tsx`:

The existing message action bar (Copy, Regenerate per message) needs a **"Save to Vault"** option.

Add it as a third action on every AI message bubble action bar:
- Icon: small diamond ◆ or vault icon
- Label: "Save"
- Same position as Copy (tap to show, always visible on mobile)

When tapped:
1. Save to `legacy_log` table:
```javascript
await supabase.from('legacy_log').insert({
  prompt_output: message.content,
  builder: detectedBuilder,
  compatibility_score: readinessScore,
  created_at: new Date().toISOString(),
});
```
2. Show "Saved to Vault ◆" toast for 2 seconds
3. The Save icon turns gold briefly

#### C: Vault Page — Show Saved Items

In `src/components/axiom/VaultGrid.tsx`:

The Vault page currently shows a hardcoded empty state. Wire it to actually load from Supabase:

```javascript
const { data: vaultItems } = await supabase
  .from('legacy_log')
  .select('*')
  .order('created_at', { ascending: false });
```

Display each item as an Obsidian tile with gold border:

```
┌─────────────────────────────────────────┐
│  [Builder badge]           [date/time]  │
│                                         │
│  [First 100 chars of prompt_output...]  │
│                                         │
│  [Copy] [Delete]                        │
└─────────────────────────────────────────┘
```

**Tile style:**
- Background: `rgba(13, 11, 9, 0.95)`
- Border: `1px solid rgba(212, 175, 55, 0.3)`
- Border radius: 12px
- Padding: 16px
- Builder badge: small pill, gold outline, builder name in gold
- Date: muted silver, small, right-aligned
- Preview text: white, 14px, 2 lines max, ellipsis overflow
- Copy button: copies full prompt_output to clipboard
- Delete button: muted, confirms before deleting, removes from Supabase

**Empty state (when no items saved yet):**
```
◆
No specs saved yet.
Save a prompt from Quick Prompt or your Chat sessions
to build your architecture library.
```

---

## After Building

1. Restart dev server
2. Confirm footer no longer clips content — scroll to bottom of chat, last message fully visible
3. Confirm input bar shows paperclip left, mic center-right, send right
4. Tap mic on Z Fold 6 — confirm voice input works OR hides gracefully if unsupported
5. Generate a Quick Prompt — confirm "Save to Vault" button appears
6. Tap Save — confirm gold toast appears
7. Navigate to /vault — confirm the saved item appears as a tile
8. Tap Copy on vault tile — confirm it copies
9. Tap Delete — confirm it removes

---

## Scope

- `src/components/axiom/AxiomLayout.tsx` — footer padding + safe area
- `src/components/axiom/ChatHook.tsx` — input bar layout + mic + Save to Vault action
- `src/components/axiom/QuickPrompt.tsx` — Save to Vault button after generation
- `src/components/axiom/VaultGrid.tsx` — wire to Supabase + real tile display

Do not change the Settings panel.
Do not change the System Map.
Do not change the floating panel open/close behavior.
Do not touch the footer shape or the raised A button.
