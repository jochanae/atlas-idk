# Axiom — Replit Agent Prompt: New Session + Export Blueprint

## Two Features To Build. Nothing Else.

---

## Feature 1: New Session Button

### Where It Lives
In the top header bar, right side — next to the "83%" / "0%" Readiness percentage indicator.

### What It Does
Tapping "New Session" resets Axiom completely:
- Clears all chat messages
- Resets all System Map nodes back to unresolved (amber glow, dashed edges)
- Resets Readiness Score back to 0%
- Resets detectedBuilder back to null (no builder badge on map)
- Restores the welcome message: *"Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?"*

### Confirmation Step
Before resetting, show a small inline confirmation directly in the header (not a modal):
- Text: **"Clear this session?"**
- Two small buttons: **"Yes, clear"** (gold) and **"Cancel"** (muted)
- If "Yes, clear" → reset everything
- If "Cancel" → dismiss, nothing changes
- Confirmation disappears after either action

### Styling
- Button label: **"+ New"** (keep it short)
- Style: slim, Luxury Gold border, Obsidian background, gold text
- Same height as the readiness % indicator
- Sits in the top right of the header, left of the readiness %

---

## Feature 2: Wire the Export Button → Download Blueprint

The Export button already exists in the Tactical Cockpit Bar. It currently does nothing. Wire it to generate and download a real Blueprint file.

### What Happens When Export Is Tapped

**Step 1: Build the Blueprint content**

Compile the session into a Markdown document using this exact structure:

```
# [Project Name] :: Axiom Blueprint
Generated: [current date and time]
Builder: [detectedBuilder or "Unspecified"]
Readiness Score: [readinessScore]%

---

## Technical Manifest — Bill of Materials

| Component | Detail |
|---|---|
| Platform | [detectedBuilder or "Unspecified"] |
| Database Nodes | [count of resolved db-type nodes] |
| API Route Nodes | [count of resolved api-type nodes] |
| Logic Block Nodes | [count of resolved logic-type nodes] |
| Auth Node | [resolved or unresolved] |
| Overall Readiness | [readinessScore]% |
| Execution Complexity | [Standard if >80%, Moderate if >50%, Complex if below] |

---

## Architecture Map — Node Status

[For each node, list: Node Name | Type | Status (Resolved/Unresolved)]

---

## Full Conversation Log

[Every message in the session formatted as:]
[AXIOM]: [message content]
[YOU]: [message content]

---

## Master Initialization Prompt

[Search the conversation for the last AI message containing any of these phrases:
"Golden Specification", "Technical Manifest", "The Plumbing", "Full Spec", "Sprint 3 complete"

If found: extract that full message and place it here.
If not found: write this exactly:
"Complete all three Sprints in Axiom to generate your Master Initialization Prompt.
Return to the session and answer all Sprint questions to unlock the full spec."]

---

*Built with Axiom — The Specification Engine*
*Into Innovations*
```

**Step 2: Trigger file download**
- File name: `axiom-blueprint-[YYYY-MM-DD-HHmm].md`
- Trigger browser download of the `.md` file immediately

**Step 3: Show a Gold confirmation toast**
After download triggers, show a brief toast notification at the top of the screen:
- Text: **"Blueprint exported."**
- Style: Luxury Gold text, Obsidian background, thin gold border
- Auto-dismisses after 2 seconds

### Also Add: Copy Last Response Button
On the most recent AI message bubble only — add a small **"Copy"** icon button that appears on tap (mobile) or hover (desktop).
- Tapping it copies that message's full text to clipboard
- On copy success: icon briefly turns gold, shows "Copied" for 1.5 seconds
- Icon: document/copy icon, 16px, muted silver by default

---

## Scope Reminder

**Only these two features.**
- New Session button in header
- Export button wired to Blueprint download + Copy on last AI message

Do not change the layout.
Do not change the AI logic.
Do not change the System Map.
Do not change the Vault page.
Do not change any styling outside what is specified above.
If anything breaks, revert and report.
