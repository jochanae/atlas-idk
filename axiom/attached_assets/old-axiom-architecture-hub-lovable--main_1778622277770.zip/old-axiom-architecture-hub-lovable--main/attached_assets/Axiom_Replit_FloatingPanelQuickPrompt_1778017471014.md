# Axiom — Replit Agent Prompt: Floating Panel + Quick Prompt Mode

## Two Final Features. Read Every Section Before Writing Any Code.

---

## Feature 1: Floating Pop-Out Panel

### What It Is
A floating, collapsible panel that lets the user access Axiom alongside any other tool — without leaving their builder. On mobile it slides up from the bottom. On desktop it floats as a resizable side panel.

### The Trigger Button
Add a persistent floating trigger button that lives on top of all content:

- Position: fixed, bottom-right corner, 20px from bottom, 20px from right
- Size: 52px circle
- Style: Luxury Gold background `#D4AF37`, dark obsidian icon
- Icon: the Axiom "A" lettermark OR a architect/compass icon
- Z-index: 9999 — always on top of everything
- Subtle pulse animation when Axiom has an active session (readiness > 0%)
- No pulse when session is empty

### Mobile Panel Behavior (primary)
When the trigger is tapped on mobile:

- A bottom sheet slides up from the bottom of the screen
- Height: 70% of screen height
- Full width
- Handle bar at top center for drag-to-dismiss
- Header: "AXIOM" in gold, current Readiness %, close button (✕)
- Two tabs at the top of the panel:
  - **SPEC** — the full Axiom experience (Chat Hook + System Map)
  - **QUICK** — the Quick Prompt mode (see Feature 2)
- Default tab: QUICK (because most mid-build uses need a quick answer)
- Background: deep Obsidian with purple ambient glow
- Smooth slide-up animation (250ms ease-out)
- Drag down past 30% of panel height → dismisses panel
- Tapping outside panel → dismisses panel
- Panel state persists — if dismissed and reopened, conversation is still there

### Desktop Panel Behavior
When the trigger is clicked on desktop:

- A side panel slides in from the right edge
- Width: 380px
- Full viewport height
- Same two tabs: SPEC and QUICK
- Resizable — drag the left edge to adjust width (min 300px, max 500px)
- Can be pinned open (pin icon in header) so it stays visible while working
- When pinned: main content shifts left to accommodate panel width
- When unpinned: panel overlays content

### Panel Header
```
[AXIOM logo]  [SPEC | QUICK tabs]  [Readiness %]  [Pin icon]  [✕]
```

---

## Feature 2: Quick Prompt Mode

### What It Is
A focused single-task mode that lives inside the floating panel. Instead of running full three-sprint architecture sessions, the user describes ONE specific thing they need to do and Axiom outputs ONE precise, surgical prompt they can paste directly into their builder.

This is the "prompt calculator" — you tell it what you're trying to say, it tells you exactly how to say it.

### The Interface
Simple, clean, three elements:

**1. Builder Selector** (top)
Three pill buttons: `Lovable` | `Cursor` | `Atlas/Replit`
Tapping one selects the target builder — the output prompt will be formatted for that tool.
Detected builder from main session pre-selects this automatically.

**2. Input Field**
Large, glassmorphic text area with placeholder:
*"Describe what you need to do in plain language..."*

Examples shown below the input as tappable chips:
- "Add a delete button to project cards"
- "Fix the z-index on a dropdown menu"  
- "Add Google auth to my app"
- "Create a new page for user settings"
- "Make the header sticky on scroll"

Tapping a chip populates the input field.

**3. Generate Button**
Full-width Luxury Gold button: **"Generate Prompt →"**

### The AI Behavior for Quick Prompt Mode

Add a new system prompt for Quick Prompt mode — separate from the main Axiom interrogation system prompt.

In `supabase/functions/axiom-chat/index.ts`:

When the request includes `mode: "quick"` in the body, use this system prompt instead of the main Axiom system prompt:

```
You are Axiom in Quick Prompt mode.

The user needs help formulating a precise, surgical prompt for their AI builder. They will describe what they want to do in plain language. Your job is to translate their description into a professional, high-density prompt they can paste directly into their target builder.

RULES:
1. Output ONLY the prompt they should use — nothing else. No explanation. No preamble. No "here's your prompt:". Just the prompt itself.
2. Format the prompt for the specified builder:
   - Lovable: One-shot, complete, includes component names and Supabase context if relevant
   - Cursor: Scoped to specific files, includes "Do not change anything else" guardrail
   - Atlas/Replit: Includes BUILD mode instruction, FILE_EDIT target if relevant
3. Keep it under 150 words — dense and precise, not verbose
4. Always end Cursor prompts with: "Do not change anything else. Do not touch any other files."
5. Always end Lovable prompts with: "Do not change the existing design or layout."
6. If the request is vague, make reasonable assumptions and state them in one line at the top of the prompt: "Assuming: [assumption]"

The output is the prompt. Nothing else.
```

### The Output
After the AI responds, display the output in a **Gold Container card**:

- Gold border, Obsidian background
- The generated prompt text in clean monospace font
- Two action buttons below:
  - **"Copy Prompt"** (gold, filled) — copies to clipboard, shows "Copied ✓"
  - **"Regenerate"** (outlined) — sends the same input again for a different version
- A small label above the output: `PROMPT FOR [BUILDER]` in small gold caps

### Quick Prompt API Call

In `supabase/functions/axiom-chat/index.ts`:

Update the edge function to handle the `mode` field in the request body:

```javascript
const { messages, builder, mode } = await req.json();

const systemContent = mode === 'quick' 
  ? QUICK_PROMPT_SYSTEM 
  : MAIN_SYSTEM_PROMPT;

if (builder) {
  systemContent += `\n\nTarget builder: ${builder}. Format the output specifically for ${builder}.`;
}
```

Store `QUICK_PROMPT_SYSTEM` as a separate constant at the top of the file.

---

## Haptics for Panel

Wire these haptic + sound events for the panel:

- Panel opens → `haptics.tap()` + `sounds.tap()`
- Quick Prompt generated → `haptics.cardConfirmed()` + `sounds.cardConfirmed()`
- Prompt copied → `haptics.nodeResolved()` + `sounds.nodeResolved()`

---

## Do Not Break

- All existing Axiom functionality
- The main Chat Hook and System Map
- Sprint card tap-to-answer flow
- Export Blueprint
- Vault access
- New Session
- Keyword definitions
- Copy buttons

---

## Files To Create/Update

- `src/components/axiom/FloatingPanel.tsx` — new file
- `src/components/axiom/QuickPrompt.tsx` — new file
- `src/components/axiom/AxiomLayout.tsx` — add FloatingPanel
- `supabase/functions/axiom-chat/index.ts` — add mode handling + Quick Prompt system prompt

---

## After Building

1. Restart dev server
2. Confirm the gold floating trigger button appears in bottom-right corner
3. Tap it — confirm panel slides up
4. Tap QUICK tab — confirm Quick Prompt interface appears
5. Select "Cursor" as builder
6. Type: "Add a delete button to project cards in Atlas"
7. Tap Generate — confirm a clean, scoped Cursor prompt appears in the Gold Container
8. Tap Copy — confirm it copies and shows "Copied ✓"
9. Dismiss panel — confirm it slides back down
10. Reopen — confirm conversation is still there

Report what works and what doesn't.

---

## Scope

Four files only. Nothing else.
Do not change any existing component behavior.
Do not change the main Axiom layout when panel is closed.
