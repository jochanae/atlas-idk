# Axiom — Replit Agent Prompt: Swap to Anthropic Claude

## What To Do

Update the `axiom-chat` edge function to use the Anthropic API directly instead of the Lovable AI Gateway.

The `ANTHROPIC_API_KEY` secret has already been added to Replit Secrets.

---

## The Change

Find the edge function file at:
`supabase/functions/axiom-chat/index.ts`

Make these exact changes:

### Change 1: Update the API endpoint and model

Replace:
```javascript
const GATEWAY_URL = "https://gateway.lovable.dev/openai/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash";
```

With:
```javascript
const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-5";
```

---

### Change 2: Update the API key source

Replace:
```javascript
const apiKey = Deno.env.get("LOVABLE_API_KEY");
if (!apiKey) {
  return new Response(JSON.stringify({ error: "API key not configured" }), {
    status: 500,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  });
}
```

With:
```javascript
const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
if (!apiKey) {
  return new Response(JSON.stringify({ error: "API key not configured" }), {
    status: 500,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  });
}
```

---

### Change 3: Update the API call format

The Anthropic API uses a different format than OpenAI. Replace the fetch call with:

```javascript
const response = await fetch(ANTHROPIC_URL, {
  method: "POST",
  headers: {
    "x-api-key": apiKey,
    "anthropic-version": "2023-06-01",
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: MODEL,
    max_tokens: 1024,
    system: systemContent,
    messages: messages,
  }),
});
```

---

### Change 4: Update the response parsing

The Anthropic response format is different from OpenAI. Replace:

```javascript
const aiResponse = data.choices?.[0]?.message?.content || "No response generated.";
```

With:

```javascript
const aiResponse = data.content?.[0]?.text || "No response generated.";
```

---

## After Making Changes

1. Save the file
2. Restart the Replit dev server (`npm run dev`)
3. Open the app and type in the chat: **"I'm building a task manager app and I'm taking it to Atlas"**
4. Confirm Axiom responds with a real, intelligent Sprint 1 question — not a generic response
5. Report what Axiom says back

---

## Scope

**This file only: `supabase/functions/axiom-chat/index.ts`**
Do not change anything else.
Do not touch the frontend.
Do not touch any other files.
