# Axiom — Replit Agent Prompt: Interactive Node Taps + General Question Handling

## Two Updates. Do Not Touch Anything Else.

---

## Update 1: Interactive System Map Node Taps

### The Problem
Tapping a node on the System Map currently focuses the chat but gives no feedback on the map itself. Nodes should be informative and interactive.

### What To Build

In `src/components/axiom/SystemMap.tsx`:

When a node is tapped, show a **Node Info Card** that appears on the map overlaying near that node.

**Node Info Card Content:**
- Node name (e.g., "Authentication")
- Status: "✓ Resolved" (gold) or "○ Needs Definition" (amber)
- One-line description of what this architectural layer does
- If unresolved: a prompt line in italic: *"Tap to define this layer in the chat"*
- A small ✕ close button to dismiss the card

**Node descriptions to implement:**

```javascript
const NODE_DESCRIPTIONS = {
  auth: "Controls who can access your app and how they prove their identity. Must be defined before anything else.",
  db: "The permanent storage layer. Every piece of data your app remembers lives here in structured tables.",
  api: "The communication layer between your UI and your database. Routes define how data flows in and out.",
  state: "Temporary memory your app holds while a user is active. Manages UI interactions before data is saved.",
  ui: "The visual shell — screens, components, and layouts your users interact with directly.",
  logic: "The rules engine — business logic, calculations, validations, and automated processes.",
};
```

**Card Style:**
- Background: Obsidian `rgba(20, 18, 14, 0.95)`
- Border: 1px solid `rgba(212, 175, 55, 0.4)` (Luxury Gold)
- Border radius: 10px
- Padding: 12px
- Max width: 220px
- Position: appears above or beside the tapped node (avoid going off-screen)
- Drop shadow: `0 4px 20px rgba(0,0,0,0.6)`
- Resolved status text color: Luxury Gold
- Unresolved status text color: amber `#F59E0B`
- Close button: small ✕ top-right, muted silver

**Behavior:**
- Only one card open at a time
- Tapping the same node again closes the card
- Tapping a different node closes the current card and opens the new one
- Tapping anywhere on the map background closes the card
- Card does NOT block or interfere with the chat focus behavior (both still happen)

**Also update the chat pivot message:**
When a node is tapped, instead of a generic focus message, send a context-aware message to the chat:

- If node is **unresolved**: *"Let's define your [Node Name]. [One relevant Sprint question for that node type]"*
- If node is **resolved**: *"Your [Node Name] layer is locked. To modify it, describe what you want to change."*

Node-specific pivot questions:
```javascript
const NODE_PIVOT_QUESTIONS = {
  auth: "Who needs to log in, and how should they verify their identity?",
  db: "What are the main things your app needs to remember permanently?",
  api: "What actions will your app need to perform on that data?",
  state: "What does your app need to remember while a user is actively using it?",
  ui: "What are the primary screens or views your users will navigate between?",
  logic: "What rules or calculations does your app need to enforce automatically?",
};
```

---

## Update 2: System Prompt Addition for General Questions

### The Problem
Axiom currently only handles architecture interrogation. Users who arrive confused, unsure, or with general questions get a poor experience because Axiom tries to force them into the sprint structure before they're ready.

### What To Update

In `supabase/functions/axiom-chat/index.ts`:

Find the system prompt string. Add this new section at the end of the system prompt, before the closing:

```
## VI. HANDLING GENERAL QUESTIONS & PRE-BUILD CONFUSION

Not every user arrives ready to architect. Some arrive confused, curious, or just thinking out loud. Axiom handles all of them.

WHEN A USER SEEMS CONFUSED OR UNSURE:
Do not force them into Sprint 1 immediately. First, become a thinking partner.
Ask: "Tell me the problem you're trying to solve — even if it's vague. We'll find the shape of it from there."
Let them describe freely for one or two exchanges, then gently guide them toward the first Sprint question once the idea has a shape.

WHEN A USER ASKS A GENERAL QUESTION (not about their specific build):
Answer it directly and helpfully within the context of building software.
Examples:
- "What's the difference between Lovable and Cursor?" → Answer clearly and concisely, then ask if they know which one they want to use.
- "Should I use Supabase or Firebase?" → Give a direct honest comparison, then ask what their app needs to store.
- "I don't know where to start" → Say: "Start with the problem, not the solution. What's the thing you wish existed that doesn't?" Then listen.
- "What does Axiom do?" → Explain clearly: "I'm your specification engine. Before you spend a dollar in any builder, I make sure you know exactly what you're building. I ask the questions the builders can't — so you arrive with a complete blueprint instead of a vague idea."

NEVER:
- Refuse to answer a question because it's not architecture-related
- Tell a user to "stay on topic"
- Ignore confusion and push forward with sprints anyway

ALWAYS:
- Meet the user where they are
- Answer first, guide second
- Keep the tone warm and direct — never clinical or dismissive
```

---

## After Building

1. Restart the dev server
2. Test node taps:
   - Tap the Authentication node — confirm info card appears with description and status
   - Confirm chat receives the pivot question
   - Tap the ✕ to close the card
3. Test general questions:
   - Type: "I don't know what I want to build yet"
   - Confirm Axiom responds warmly and asks about the problem rather than forcing Sprint 1
   - Type: "What's the difference between Lovable and Cursor?"
   - Confirm Axiom answers the question directly
4. Report what works and what doesn't

---

## Scope

**Two files only:**
- `src/components/axiom/SystemMap.tsx` — node tap info cards
- `supabase/functions/axiom-chat/index.ts` — system prompt addition

Do not touch any other files.
Do not change any layout, colors, or other components.
Do not modify the existing sprint interrogation logic.
