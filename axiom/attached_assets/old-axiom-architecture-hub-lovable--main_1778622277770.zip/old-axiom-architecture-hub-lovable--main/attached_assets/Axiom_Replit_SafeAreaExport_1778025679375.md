# Axiom — Replit Agent Prompt: Safe Area + Header Branding + Blueprint Export

## Three Fixes. One Prompt. Read Before Touching Anything.

---

## Fix 1: Safe Area Padding + Header Branding

### The Problem
On iOS devices with notch/dynamic island and on Android devices, the "SYSTEM MAP" label sits too close to the top of the screen with no padding buffer. It can get clipped by the status bar.

Also — when the chat is collapsed, the AXIOM wordmark disappears. Users lose context about what product they're in.

### What To Fix

In `src/components/axiom/AxiomLayout.tsx`:

**Add safe area padding to the top of the main container:**

```css
padding-top: max(env(safe-area-inset-top), 12px);
```

Apply this to the outermost container element so all content clears the device status bar on every device type — iOS notch, Android punch hole, Z Fold 6 cover screen, everything.

**Add AXIOM header that's always visible:**

Add a persistent slim header bar at the very top of the layout — visible in ALL states (map only, chat visible, flex mode):

```
[Folder icon]  AXIOM  [spacer]  100% •  [+ New]
```

Style:
- Height: 44px
- Background: `rgba(13, 11, 9, 0.95)` with thin gold bottom border `rgba(212, 175, 55, 0.2)`
- "AXIOM" text: Luxury Gold `#D4AF37`, 13px, font-weight 600, letter-spacing 0.1em
- Readiness % and + New button: already exist, move them here from wherever they currently are
- Folder icon: already exists, keep it here
- This header must respect safe area insets at the top

**Remove the "SYSTEM MAP" label** from the map canvas — it's redundant now that AXIOM is always visible in the header. The map speaks for itself.

Or if keeping it — reduce it to just a small subtle label, not a bold header.

---

## Fix 2: Blueprint Export — Copy to Clipboard + TXT Download

### The Problem
The current Blueprint export only downloads a `.md` file. On mobile, markdown files require long-pressing and extra steps to copy content. Most users won't know what to do with it.

### What To Change

In `src/components/axiom/GoldContainer.tsx` (or wherever the export logic lives):

**Replace the single "Export to Gold Vault" / download action with three options:**

When the user taps Export, show a small action sheet with three choices:

**Option 1: Copy Full Spec** (primary, gold filled button)
- Copies the entire Blueprint content as plain text to clipboard
- Shows "Copied ✓" confirmation for 2 seconds
- This is the PRIMARY action — most users will use this

**Option 2: Download as TXT** (secondary, outlined)
- Downloads as `axiom-blueprint-[timestamp].txt`
- Plain text, universally openable on every device
- Easy to copy from on mobile

**Option 3: Download as MD** (tertiary, text only)
- Keeps existing markdown download for technical users
- Labeled "Download .md (technical)"
- Smallest visual weight — it's the least common use case

**Action sheet style:**
```
┌─────────────────────────────────┐
│  Export Blueprint               │
│                                 │
│  [Copy Full Spec to Clipboard]  │  ← gold filled
│  [Download as TXT]              │  ← outlined
│  [Download .md (technical)]     │  ← text only
│  [Cancel]                       │  ← muted
└─────────────────────────────────┘
```

Background: Obsidian, gold border, slides up from bottom on mobile.

**The Copy Full Spec button** should compile this content:
- The Technical Manifest table
- The Architecture Map node status
- The full conversation log
- The Master Initialization Prompt (if sprint is complete)

As clean plain text — no markdown symbols in the copied version. Strip `**`, `##`, `---` etc. so what gets pasted into Lovable/Cursor/Replit is clean readable text.

---

## Fix 3: Blueprint Content — Strip Markdown from Clipboard Copy

When compiling content for the "Copy Full Spec" clipboard action:

Strip these markdown symbols from the plain text version:
- `**bold**` → just the word
- `## Heading` → just the heading text, no ##
- `---` dividers → empty line
- `` `code` `` → just the text
- Backtick code blocks → keep the content, remove the backticks

The `.md` download keeps all markdown formatting intact. Only the clipboard copy gets stripped to plain text.

---

## After Building

1. Restart dev server
2. Open Axiom on mobile — confirm AXIOM header is visible and status bar safe
3. Test on different screen sizes — confirm no clipping at top
4. Tap Export — confirm action sheet slides up with three options
5. Tap "Copy Full Spec" — paste into Notes app — confirm clean plain text with no markdown symbols
6. Tap "Download as TXT" — confirm file downloads and opens cleanly
7. Report what works and what doesn't

---

## Scope

- `src/components/axiom/AxiomLayout.tsx` — safe area padding + persistent header
- `src/components/axiom/GoldContainer.tsx` — export action sheet + copy logic
- `src/components/axiom/CockpitBar.tsx` — only if export button needs to be moved
- No other files

Do not change the AI logic.
Do not change the System Map nodes or edges.
Do not change the Chat Hook.
Do not change the Vault page.
