# Axiom — Replit Agent Prompt: Copy Button + Tappable Keyword Definitions

## Two Fixes Only. Do Not Touch Anything Else.

---

## Fix 1: Copy Button on Every AI Message

### The Problem
There is currently no way to copy an AI response. Users need to copy responses to paste into their builders.

### What To Build
In `src/components/axiom/ChatHook.tsx`:

Add a **Copy button** to every AI message bubble (role: "system" / assistant messages). Not just the last one — every single AI message in the conversation.

**Placement:** Bottom-right corner inside the message bubble. Always visible — do not hide it behind hover or tap. On mobile it must be permanently visible because hover does not exist.

**Behavior:**
- Tapping Copy copies the full plain text of that message to clipboard (strip any markdown symbols before copying — copy clean readable text, not raw markdown)
- On success: button turns Luxury Gold and shows "Copied ✓" for 2 seconds
- Then returns to normal state

**Style:**
- Small button, 32px tap target minimum
- Icon: two overlapping squares (copy icon) OR just the word "Copy" in small text
- Default color: muted silver/grey
- Active/success color: Luxury Gold #D4AF37
- Background: transparent
- Do not show on user messages
- Do not show on the welcome message

---

## Fix 2: Tappable Keyword Definitions

### The Problem
Gold keywords like "Auth Method", "Schema", "Entity", "Relationships" are highlighted in gold but tapping them does nothing. They are supposed to expand a definition inline so users can learn while they work.

### What To Build
In `src/components/axiom/ChatHook.tsx`:

Make every gold-highlighted keyword **tappable**. When tapped, a small definition card expands inline directly below that keyword.

**Definition Card Behavior:**
- Tapping a keyword expands a definition card directly beneath it
- Tapping the same keyword again collapses it
- Only one definition card open at a time — tapping a new keyword closes the previous one
- Definition card does not shift or reflow the message bubble — it expands smoothly below the keyword within the message

**Definition Card Style:**
- Background: `rgba(212, 175, 55, 0.08)` (very subtle gold tint)
- Border: 1px solid `rgba(212, 175, 55, 0.25)`
- Border radius: 8px
- Padding: 8px 12px
- Text: small (12px), muted silver color
- A thin Luxury Gold left border (3px) to indicate it is an expansion
- Smooth expand/collapse animation (150ms)

**Keyword Definitions to implement:**

```javascript
const KEYWORD_DEFINITIONS = {
  "auth": "Authentication verifies who a user is before granting access. Common methods: Email/Password, Google OAuth, or Magic Link (passwordless).",
  "auth method": "How users prove their identity. Choosing the wrong method early is expensive to change later.",
  "schema": "The blueprint of your database — defines what tables exist, what columns they have, and how they relate to each other.",
  "database": "Where your app's data lives permanently. Tables store structured information like users, orders, or tasks.",
  "entity": "A real-world object your app needs to track. Users, Orders, Tasks, and Projects are all examples of entities.",
  "relationships": "How database tables connect to each other. Example: a Task belongs to a Project, a Project belongs to a User.",
  "privacy model": "Rules that control who can see what data. Critical for multi-user apps — gets complex fast if not defined early.",
  "api": "Application Programming Interface — the layer between your frontend UI and your database. Routes data in and out.",
  "api routes": "The specific paths your app uses to send and receive data. Example: POST /tasks creates a task, GET /tasks lists them.",
  "state management": "How your app remembers information while a user is actively using it — before anything is saved to the database.",
  "state": "Temporary data your app holds in memory during a session. Forms, selections, and UI state all live here.",
  "middleware": "Code that runs between a request arriving and your app responding — used for auth checks, logging, and validation.",
  "edge function": "A small serverless function that runs close to the user for speed. Supabase Edge Functions handle backend logic without a full server.",
  "webhook": "An automatic notification sent from one system to another when something happens. Example: Stripe notifies your app when a payment succeeds.",
  "validation": "Rules that check if data is correct before saving it. Prevents bad data from entering your database.",
  "rls": "Row Level Security — Supabase's system for ensuring users can only access their own data in the database.",
  "supabase": "Your backend platform — handles database, authentication, file storage, and serverless functions in one place.",
  "oauth": "Open Authorization — a secure way to let users log in with an existing account like Google or GitHub without sharing their password.",
  "sprint": "A focused phase of the Axiom interrogation. Sprint 1 covers data, Sprint 2 covers logic, Sprint 3 covers the shell.",
};
```

**How keyword matching works:**
- Match keywords case-insensitively
- Keywords can appear anywhere in the AI response text
- If a phrase like "Auth Method" is highlighted in gold, tapping it shows the definition for "auth method"
- If a single word like "Schema" is highlighted, tapping it shows the definition for "schema"

---

## Do Not Break

- Existing gold keyword highlighting must still work (color, underline)
- Copy button on messages must not interfere with tappable keywords
- Chat scroll behavior must not change
- Send on Enter must still work
- Typing indicator must still work
- New Session button must still work
- Export button must still work

---

## After Building

1. Restart the dev server
2. Type: "I'm building a task manager and taking it to Atlas"
3. When Axiom responds with Sprint 1 questions, confirm:
   - Each AI message has a Copy button visible in the bottom-right corner
   - Tapping "Auth Method" in gold shows its definition card inline
   - Tapping it again collapses it
   - Tapping Copy on any message copies the text and shows "Copied ✓"
4. Report what works and what doesn't

---

## Scope

**`src/components/axiom/ChatHook.tsx` only.**
Do not touch any other files unless absolutely required for imports.
Do not change layout, colors, or any other component.
