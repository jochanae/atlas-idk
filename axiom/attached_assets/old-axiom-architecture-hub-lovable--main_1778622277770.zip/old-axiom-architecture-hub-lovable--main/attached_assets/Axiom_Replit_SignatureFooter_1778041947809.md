# Axiom — Replit Agent Prompt: Into Innovations Signature Footer

## The Footer Pattern. Read Every Detail Before Writing Any Code.

---

## What This Is

Axiom needs the same footer design language used across the Into Innovations portfolio (CoinsBloom, IntoIQ, Compani). Every product has a footer with a raised center button that sits above a curved cutout in the nav bar.

---

## The Footer Structure

Replace the current Cockpit Bar / footer in `src/components/axiom/CockpitBar.tsx` with this layout:

```
[?]          [  A  ]          [Export]
         (raised center)
━━━━━━━━━╱           ╲━━━━━━━━━
```

**Five elements:**
- Left: **?** help button
- Center: **Raised Axiom "A" circular button** (the primary action — opens floating panel)
- Right: **Export** button
- The bar curves upward on both sides of the center button creating a cutout

---

## The Center Button — Exact Specs

```css
/* The raised circle */
width: 64px;
height: 64px;
border-radius: 50%;
background: #0D0B09; /* deep obsidian */
border: 2px solid #D4AF37; /* luxury gold */
position: absolute;
top: -28px; /* raises it above the bar */
left: 50%;
transform: translateX(-50%);
box-shadow: 0 0 20px rgba(212, 175, 55, 0.3), 0 4px 12px rgba(0,0,0,0.5);
```

**Inside the circle:** The Axiom SVG logo — the capital A in Luxury Gold on Obsidian background.

Use this inline SVG inside the button:
```jsx
<svg viewBox="0 0 512 512" width="44" height="44">
  <defs>
    <radialGradient id="pg" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#5B21B6" stopOpacity="0.35"/>
      <stop offset="100%" stopColor="#0D0B09" stopOpacity="0"/>
    </radialGradient>
    <radialGradient id="gs" cx="50%" cy="40%" r="50%">
      <stop offset="0%" stopColor="#F5D97A"/>
      <stop offset="50%" stopColor="#D4AF37"/>
      <stop offset="100%" stopColor="#A07820"/>
    </radialGradient>
  </defs>
  <rect width="512" height="512" rx="90" fill="#0D0B09"/>
  <rect width="512" height="512" rx="90" fill="url(#pg)"/>
  <polygon points="256,110 170,402 212,402 274,172" fill="url(#gs)"/>
  <polygon points="256,110 342,402 300,402 238,172" fill="url(#gs)"/>
  <rect x="180" y="282" width="152" height="34" rx="5" fill="url(#gs)"/>
</svg>
```

**Label below the circle:** "AXIOM" in 9px, letter-spacing 0.12em, Luxury Gold, centered below the button.

**On tap:** Opens the floating panel (same behavior as current "A" button).

**Pulse animation when session is active (readiness > 0%):**
```css
@keyframes axiom-pulse {
  0%, 100% { box-shadow: 0 0 20px rgba(212, 175, 55, 0.3), 0 4px 12px rgba(0,0,0,0.5); }
  50% { box-shadow: 0 0 35px rgba(212, 175, 55, 0.6), 0 4px 12px rgba(0,0,0,0.5); }
}
animation: axiom-pulse 2s ease-in-out infinite;
```

---

## The Curved Cutout Bar

The footer bar needs a curved arch cutout in the center where the button sits.

Use SVG path or CSS clip-path to create the curve:

```css
/* Footer bar with center arch cutout */
.footer-bar {
  position: relative;
  height: 60px;
  background: rgba(13, 11, 9, 0.97);
  border-top: 1px solid rgba(212, 175, 55, 0.15);
  backdrop-filter: blur(12px);
}
```

For the arch cutout, use an SVG background or a CSS border-radius approach:

```jsx
// The bar shape with cutout — use SVG as background
const FooterShape = () => (
  <svg
    style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
    preserveAspectRatio="none"
    viewBox="0 0 390 60"
  >
    <path
      d="M0,0 L155,0 Q175,0 175,0 A40,40 0 0,0 215,0 Q235,0 235,0 L390,0 L390,60 L0,60 Z"
      fill="rgba(13, 11, 9, 0.97)"
    />
    {/* The arch cutout */}
    <path
      d="M155,0 Q175,-2 195,2 Q215,-2 235,0"
      fill="none"
      stroke="rgba(212, 175, 55, 0.15)"
      strokeWidth="1"
    />
  </svg>
)
```

**If SVG approach is too complex**, use this simpler CSS-only approach:
- Two pseudo-elements (::before and ::after) on the footer bar
- Each creates a quarter-circle cutout from either side of the center
- This is the standard approach used in most mobile apps

---

## Left and Right Items

**Left — Help button (?):**
- 32px circle, gold border, "?" text
- Same behavior as current ? button
- Vertically centered in the bar

**Right — Export button:**
- Icon + "Export" text or just the download icon
- Gold color
- Same behavior as current Export button
- Vertically centered in the bar

---

## Remove

- Remove the current flat Cockpit Bar layout
- Remove the Readiness score from the footer bar (move it to the AXIOM header at the top where it already lives as "0% •")
- Remove the Stealth/Cinematic/Studio selector if still present
- The footer should be clean: just ?, the raised A, and Export

---

## Safe Area

Add padding to the bottom of the footer for devices with home indicator:
```css
padding-bottom: max(env(safe-area-inset-bottom), 8px);
```

---

## Mobile Only

This curved footer is for mobile. On desktop (Architect Mode split pane), keep the existing cockpit bar behavior — the curved footer only applies to the mobile layout.

---

## After Building

1. Restart dev server
2. Open Axiom on mobile
3. Confirm the footer shows the curved bar with raised gold "A" circle in center
4. Confirm the Axiom logo SVG is visible inside the circle
5. Confirm "AXIOM" label appears below the circle
6. Tap the "A" — confirm floating panel opens
7. Confirm ? and Export are on either side
8. Check on Z Fold 6 cover screen — confirm it fits without clipping
9. Report what works and what doesn't

---

## Scope

- `src/components/axiom/CockpitBar.tsx` — full replacement
- `src/components/axiom/AxiomLayout.tsx` — only if footer wiring needs updating

Do not touch the floating panel.
Do not touch the Chat Hook.
Do not touch the System Map.
Do not touch any other files.
