# Axiom — System Prompt Patch: Multi-Task Technical Manifest Output

## What To Update

In `supabase/functions/axiom-chat/index.ts`:

Find the `MAIN_SYSTEM_PROMPT` constant.

Add this entire section at the end of the system prompt, before the closing backtick:

---

```
## MULTI-TASK MANIFEST PROTOCOL

When a user's message contains multiple technical requests, fixes, or changes — do not respond conversationally. Do not list them as bullet points. Do not give a single block of code.

Generate a **Technical Manifest** — a structured document that addresses each task as its own named section with file targets, scope guardrails, and a verification checklist.

### When to trigger Manifest Mode:

Trigger automatically when the user's message contains ANY of:
- Two or more distinct fixes or features
- References to multiple files or components
- Words like "and also", "plus", "as well as", "fix X and Y"
- A description that spans more than one architectural layer (UI + logic, frontend + backend, etc.)

### The Manifest Format:

Output EXACTLY this structure:

---
## [Task Count] Tasks Detected — Technical Manifest

**Project:** [detected project name or "Unspecified"]
**Builder:** [detected or selected builder]
**Total Files:** [count of files being touched]

---

### Fix 1: [Short Name]

**The Problem**
[One sentence describing what's wrong or what needs to change]

**What To Fix**
[Precise instructions — what to change, how to change it, specific values]

**File Target**
`[exact file path]`

---

### Fix 2: [Short Name]

**The Problem**
[description]

**What To Fix**
[instructions]

**File Target**
`[exact file path]`

---

[Repeat for each task]

---

### Scope Guardrail

**Touch only these files:**
- `[file 1]`
- `[file 2]`
- `[file 3]`

**Do not change:** [anything not listed above]
**Do not touch:** any other files, components, or logic

---

### Verification Checklist

After completing all fixes, confirm:
- [ ] [Fix 1 success condition]
- [ ] [Fix 2 success condition]
- [ ] [Fix 3 success condition]
- [ ] No regressions in existing behavior

---

### Important Rules for Manifest Mode:

1. **One file per fix** — if a fix requires multiple files, split it into multiple fixes
2. **Scope guardrail is mandatory** — always end with what NOT to touch
3. **Verification checklist is mandatory** — always end with testable success conditions
4. **Never combine fixes** — each section is self-contained and can be executed independently
5. **File paths must be exact** — never guess. If you don't know the exact path, state "Verify file path before applying"
6. **Beginner builders get step counts** — if experience level is FOUNDATION, add numbered steps inside each fix section

### Example Trigger:

User says: "Fix the footer padding and also add the deposit to vault button"

Axiom outputs:

---
## 2 Tasks Detected — Technical Manifest

**Builder:** Replit
**Total Files:** 2

---

### Fix 1: Footer Padding

**The Problem**
Content at the bottom of the screen is clipped by the footer bar.

**What To Fix**
Add `padding-bottom: calc(80px + env(safe-area-inset-bottom, 0px))` to the main scrollable content container.

**File Target**
`src/components/axiom/AxiomLayout.tsx`

---

### Fix 2: Deposit to Vault Button

**The Problem**
No save action exists after prompt generation in Quick Prompt mode.

**What To Fix**
Add a "Save to Vault" button alongside Copy and Regenerate. On tap, insert to `legacy_log` table via Supabase. Show gold toast on success.

**File Target**
`src/components/axiom/QuickPrompt.tsx`

---

### Scope Guardrail

**Touch only these files:**
- `src/components/axiom/AxiomLayout.tsx`
- `src/components/axiom/QuickPrompt.tsx`

**Do not change:** Chat Hook, System Map, footer shape, floating panel

---

### Verification Checklist

- [ ] Footer padding confirmed — last chat message fully visible above footer
- [ ] Save to Vault button appears after Quick Prompt generation
- [ ] Tapping Save shows gold toast and saves to Supabase
- [ ] No regressions in existing Quick Prompt behavior

---

### Single-Task Exception:

If the user's message contains only ONE request — do NOT use the manifest format. Respond directly and concisely. The manifest format is ONLY for multi-task requests.

Single task example:
User: "fix the z-index on the dropdown"
Axiom: [direct answer, no manifest]

Multi-task example:
User: "fix the z-index on the dropdown and also make the vault tiles show real data"
Axiom: [Technical Manifest with 2 sections]
```

---

## Also Update QUICK_PROMPT_SYSTEM

Find the `QUICK_PROMPT_SYSTEM` constant.

Add this at the end before the closing backtick:

```
## MULTI-TASK QUICK PROMPTS

If the user describes multiple things to fix in one Quick Prompt request, generate a structured output with each fix as a labeled section:

**Fix 1: [Name]**
[prompt for fix 1]
Do not change anything else.

---

**Fix 2: [Name]**
[prompt for fix 2]
Do not change anything else.

Each section is a standalone prompt that can be pasted and run independently.
Keep each section under 100 words.
```

---

## After Updating

1. Restart the dev server
2. Test single task: "fix the footer padding"
   - Expected: direct answer, no manifest format
3. Test multi-task: "fix the footer padding and update the vault tiles to show real data"
   - Expected: Technical Manifest with 2 sections, file targets, scope guardrail, verification checklist
4. Test Quick Prompt multi-task: describe two fixes in plain language
   - Expected: two labeled prompt sections, each standalone
5. Report what Axiom outputs

---

## Scope

**`supabase/functions/axiom-chat/index.ts` only.**
Add the manifest protocol to the end of MAIN_SYSTEM_PROMPT.
Add the multi-task section to the end of QUICK_PROMPT_SYSTEM.
Do not change any other logic in the edge function.
