# Axiom — Replit Agent Prompt: Settings Menu + Project Profiles

## New Feature Set. Read Every Section Before Writing Any Code.

---

## What We Are Building

A settings menu accessible from the AXIOM header, plus a Project Profiles system that saves named project contexts for reuse in Quick Prompt mode.

---

## Part 1: Settings Entry Point

### The Trigger

In `src/components/axiom/AxiomLayout.tsx`:

Add a small **gear icon** to the top-right of the AXIOM header bar, left of the readiness % indicator.

```
[Folder]  AXIOM  [spacer]  [⚙]  0% •  [+ New]
```

- Icon: `Settings` from lucide-react
- Size: 18px
- Color: muted silver by default, Luxury Gold on tap
- Tapping opens the Settings panel

### The Settings Panel

A bottom sheet that slides up from the bottom of the screen (same behavior as the floating panel):

- Height: 80% of screen
- Background: deep Obsidian `#0D0B09`
- Gold border top: `rgba(212, 175, 55, 0.3)`
- Handle bar at top center
- Header: **SETTINGS** in Luxury Gold caps, ✕ close button

---

## Part 2: Settings Sections

### Section 1: DEFAULT BUILDER

A styled dropdown (same Obsidian/Gold custom dropdown from QuickPrompt):

Label: **DEFAULT BUILDER**
Subtitle: "Pre-selected every time you open Quick Prompt"

Options: Lovable, Cursor, Replit, Bolt, Windsurf, v0 by Vercel, Bubble, FlutterFlow, GitHub Copilot, Other

Save to localStorage key: `axiom_default_builder`

When saved — show brief gold toast: "Default builder saved."

---

### Section 2: EXPERIENCE LEVEL

Label: **EXPERIENCE LEVEL**
Subtitle: "Axiom adapts its responses to match your level"

Three radio options styled as gold-bordered cards:

```
┌─────────────────────────────────────┐
│  ◉  ARCHITECT                       │
│     90% code, 10% context.          │
│     Drop the diff. Skip the         │
│     tutorial.                       │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  ○  BUILDER                         │
│     Code with the "why" included.   │
│     I'm building actively but       │
│     still learning.                 │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  ○  FOUNDATION                      │
│     Step-by-step guidance.          │
│     Explain concepts as they        │
│     appear.                         │
└─────────────────────────────────────┘
```

Selected card: gold border brightens, gold filled radio dot
Unselected: subtle gold border, empty radio

Save to localStorage key: `axiom_experience_level`

Pass this value to the edge function with every chat request so the AI knows which mode to use.

---

### Section 3: PROJECT PROFILES

Label: **PROJECT PROFILES**
Subtitle: "Save your project context once. Use it every time."

#### Empty State:
```
No projects saved yet.
Tap + to add your first project profile.
```
Small gold "+" button top right of the section.

#### Add/Edit Profile Sheet:
When "+" is tapped, a focused form slides up:

**Fields:**
- **Project Name** — text input (e.g., "Atlas", "CoinsBloom")
- **Builder** — same dropdown selector
- **Tech Stack** — multiline text area
  - Placeholder: "React + Vite, TailwindCSS, Express backend, Postgres + Drizzle ORM"
- **File Structure** — multiline text area
  - Placeholder: "- Frontend: artifacts/atlas/src/components/\n- Backend: artifacts/api-server/src/routes/\n- DB: lib/db/"
- **Notes** — optional text area
  - Placeholder: "Any additional context Axiom should always know about this project..."

**Save button:** Full-width Luxury Gold
**Cancel:** Muted text link

#### Saved Profile Cards:
Each saved profile displays as an Obsidian tile with gold border:

```
┌─────────────────────────────────────┐
│  Atlas                    [Edit] [✕]│
│  Replit · React + Express           │
│  Last used: 2h ago                  │
└─────────────────────────────────────┘
```

- Project name: white, bold
- Builder + stack summary: muted silver, small
- Last used timestamp: muted silver, small
- Edit button: gold text
- ✕ delete button: muted, confirms before deleting

#### Using a Profile in Quick Prompt:
In `src/components/axiom/QuickPrompt.tsx`:

Add a **"Load Project"** button above the Project Context text area:

```
PROJECT CONTEXT
[Load Project ▼]  or paste manually below...
[text area]
```

Tapping "Load Project" shows a mini picker with saved profile names. Selecting one populates the Project Context field with that profile's stack + file structure + notes combined.

The builder dropdown also auto-switches to that profile's saved builder.

---

### Section 4: HAPTICS & SOUND

Label: **FEEDBACK**
Subtitle: "Cinematic sensory feedback"

Two toggles:

**Haptic Feedback**
- Toggle on/off
- Default: on
- Save to localStorage: `axiom_haptics_enabled`

**Sound Effects**
- Toggle on/off  
- Default: on
- Save to localStorage: `axiom_sounds_enabled`

Style: iOS-style toggle switches but themed — track color gold when on, muted when off.

---

### Section 5: ABOUT

Small section at the bottom:

```
AXIOM
Structural Specification Engine
Version 1.0 — Into Innovations

Built to eliminate the do-over tax.
```

Text: muted silver, centered, small.

---

## Part 3: Wire Settings to AI Calls

In `supabase/functions/axiom-chat/index.ts`:

Update the request body to accept `experienceLevel`:

```javascript
const { messages, builder, mode, images, experienceLevel } = await req.json();
```

Append to the system prompt based on level:

```javascript
if (experienceLevel === 'architect') {
  systemContent += '\n\nUSER LEVEL: ARCHITECT. Output is 90% code, 10% context. No tutorials. Drop the diff and the logic note. They know where to paste it.';
} else if (experienceLevel === 'foundation') {
  systemContent += '\n\nUSER LEVEL: FOUNDATION. Step-by-step guidance. Explain every concept when it appears. Tell them which file to open, where to paste, what to run.';
} else {
  systemContent += '\n\nUSER LEVEL: BUILDER. Include the why inline. Show reasoning but keep momentum.';
}
```

---

## Part 4: Send Settings With Every Request

In `src/components/axiom/ChatHook.tsx` and `src/components/axiom/QuickPrompt.tsx`:

Read from localStorage and include in every API call:

```javascript
const experienceLevel = localStorage.getItem('axiom_experience_level') || 'builder';
const defaultBuilder = localStorage.getItem('axiom_default_builder') || null;

// Include in supabase.functions.invoke body
{ messages, builder: detectedBuilder || defaultBuilder, mode, images, experienceLevel }
```

---

## After Building

1. Restart dev server
2. Tap the gear icon in the AXIOM header
3. Confirm settings panel slides up
4. Set Experience Level to ARCHITECT — confirm it saves
5. Add a Project Profile for "Atlas" with file structure
6. Open Quick Prompt → tap "Load Project" → select Atlas → confirm context populates
7. Generate a prompt — confirm it references the Atlas file paths
8. Toggle haptics off — confirm no vibration on next node tap
9. Report what works and what doesn't

---

## Scope

- `src/components/axiom/AxiomLayout.tsx` — add gear icon
- `src/components/axiom/Settings.tsx` — new file (full settings panel)
- `src/components/axiom/ProjectProfiles.tsx` — new file (profile management)
- `src/components/axiom/QuickPrompt.tsx` — add Load Project button
- `supabase/functions/axiom-chat/index.ts` — accept and use experienceLevel
- `src/components/axiom/ChatHook.tsx` — send experienceLevel with requests

Do not touch the System Map.
Do not touch the footer.
Do not touch the floating panel logic.
Do not change any existing component behavior.
