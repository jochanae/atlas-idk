# Axiom — Replit Agent Prompt: Builder Dropdown in Quick Prompt

## One File Only. One Change Only.

---

## The Change

In `src/components/axiom/QuickPrompt.tsx`:

Replace the three fixed pill buttons (Lovable / Cursor / Atlas/Replit) with a **dropdown selector** that includes all major builders plus an Other option.

---

## The Dropdown

Replace the current builder selector UI with a styled select dropdown:

**Dropdown options (in this order):**
```
Select your builder...  ← default placeholder, not selectable
Lovable
Cursor
Replit
Bolt
Windsurf
v0 by Vercel
Bubble
FlutterFlow
GitHub Copilot
Other
```

**When "Other" is selected:**
A small text input appears directly below the dropdown:
- Placeholder: "Type your builder name..."
- Style: same glassmorphic style as the main input field
- The value typed here becomes the builder name passed to the AI
- Label above: "BUILDER NAME" in small gold caps

**Dropdown Style:**
```
Background: rgba(20, 18, 14, 0.95) — deep obsidian
Border: 1px solid rgba(212, 175, 55, 0.3) — subtle gold
Border radius: 8px
Text color: rgba(255, 255, 255, 0.87)
Padding: 12px 14px
Width: 100%
Font size: 14px
Selected state: border brightens to rgba(212, 175, 55, 0.6)
Arrow icon: Luxury Gold chevron down
```

**On selection:**
- The dropdown shows the selected builder name
- If "Other" is selected, the text input appears below
- The selected builder is passed to the AI as the `builder` value
- If "Other" with a custom name typed — pass the custom name

---

## Update the Label

Change the label above the dropdown from:
`TARGET BUILDER`

To:
`WHERE ARE YOU BUILDING?`

In small gold caps, same style as existing labels.

---

## Update the AI Call

When passing the builder to the edge function, use the custom name if Other is selected:

```javascript
const effectiveBuilder = selectedBuilder === 'Other' 
  ? customBuilderName || 'Other'
  : selectedBuilder;
```

Pass `effectiveBuilder` as the `builder` value in the API call.

---

## Remove

Remove the old three-button pill selector entirely. Replace with just the dropdown.

---

## Do Not Break

- Quick Prompt generation
- Image attachment (paperclip)
- Generate Prompt button
- Copy Prompt and Regenerate buttons
- The Gold Container output display
- SPEC tab behavior
- Panel open/close

---

## After Building

1. Restart dev server
2. Open the floating panel → QUICK tab
3. Confirm dropdown appears with "Select your builder..." placeholder
4. Select "Bolt" — confirm it selects correctly
5. Select "Other" — confirm text input appears below
6. Type "Windsurf" in the custom field
7. Type a task and hit Generate
8. Confirm output says "PROMPT FOR WINDSURF" and is formatted generically
9. Report what works and what doesn't

---

## Scope

**`src/components/axiom/QuickPrompt.tsx` only.**
Do not touch any other files.
Do not change anything else in the component.
