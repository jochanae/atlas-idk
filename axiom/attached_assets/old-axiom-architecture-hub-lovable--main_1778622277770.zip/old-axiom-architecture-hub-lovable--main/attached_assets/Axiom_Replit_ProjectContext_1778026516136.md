# Axiom — Replit Agent Prompt: Project Context Field in Quick Prompt

## One File. One Addition. Read Before Touching Anything.

---

## The Problem

Quick Prompt generates prompts based on plain language descriptions only. It has no knowledge of the user's actual codebase — so it makes generic assumptions about file locations and structure that may not match the real project. This produces prompts that target the wrong files.

---

## What To Build

In `src/components/axiom/QuickPrompt.tsx`:

Add an optional **"Project Context"** collapsible field between the builder dropdown and the main input field.

---

## The UI

A slim collapsible section labeled **"PROJECT CONTEXT"** in small gold caps:

**Collapsed state (default):**
```
+ Add project context (optional)
```
Small text, muted silver, tappable to expand.

**Expanded state:**
A text area with placeholder:
```
Paste your file structure, tech stack, or key file paths...

Example:
- Frontend: src/components/ (React + Tailwind)
- Backend: api/routes/ (Express)
- Database: Postgres + Drizzle ORM
- Auth: Not yet implemented
```

Style:
- Same glassmorphic style as the main input
- Height: 100px (scrollable if more text)
- Gold border when focused
- Small "Clear" link bottom-right to reset it
- Placeholder text in muted silver

---

## How It Affects the AI Call

When Project Context has content, append it to the user's description before sending to the AI:

```javascript
const fullDescription = projectContext.trim()
  ? `${userInput}\n\nProject context:\n${projectContext}`
  : userInput;
```

Pass `fullDescription` as the message content instead of just `userInput`.

This means the AI receives both:
1. What the user wants to do
2. The actual file structure and stack

And generates a prompt that targets the correct files.

---

## Updated Quick Prompt System Prompt Addition

In `supabase/functions/axiom-chat/index.ts`:

Add this to the end of `QUICK_PROMPT_SYSTEM`:

```
If the user provides "Project context:" in their message, use those file paths and stack details to make the prompt precise. Reference the exact file names and paths provided. Never guess file locations when actual paths are given.
```

---

## The Full Quick Prompt Layout After This Change

```
WHERE ARE YOU BUILDING?
[Lovable] [Cursor] [Replit] [Bolt] ... dropdown

+ Add project context (optional)
↓ (expands to text area when tapped)

WHAT DO YOU NEED TO DO?
[main input field with paperclip]

[example chips]

[Generate Prompt →]
```

---

## Do Not Break

- Builder dropdown
- Main input field
- Image attachment (paperclip)
- Example chips
- Generate Prompt button
- Gold Container output
- Copy Prompt and Regenerate buttons

---

## After Building

1. Restart dev server
2. Open floating panel → QUICK tab
3. Tap "+ Add project context" — confirm it expands
4. Paste a file structure
5. Type a task description
6. Select Cursor
7. Tap Generate
8. Confirm the output references the actual file paths from the context
9. Report what works and what doesn't

---

## Scope

**Two files only:**
- `src/components/axiom/QuickPrompt.tsx`
- `supabase/functions/axiom-chat/index.ts`

Do not touch any other files.
Do not change any other part of the Quick Prompt interface.
