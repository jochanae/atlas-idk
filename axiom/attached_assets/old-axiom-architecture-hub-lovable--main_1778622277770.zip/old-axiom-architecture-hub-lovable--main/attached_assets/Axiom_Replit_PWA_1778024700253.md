# Axiom — Replit Agent Prompt: PWA Install Support

## Make Axiom Installable on Mobile and Desktop

---

## What To Build

Add Progressive Web App (PWA) support so users can install Axiom on their home screen (mobile) or desktop. When installed it opens as a standalone app — no browser chrome, no URL bar. Just Axiom.

---

## Step 1: Create the Logo Files

Create the file `public/axiom-logo.svg` with this exact content:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <defs>
    <radialGradient id="purpleGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#5B21B6" stop-opacity="0.35"/>
      <stop offset="60%" stop-color="#3B0764" stop-opacity="0.15"/>
      <stop offset="100%" stop-color="#0D0B09" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="goldSheen" cx="50%" cy="40%" r="50%">
      <stop offset="0%" stop-color="#F5D97A" stop-opacity="1"/>
      <stop offset="50%" stop-color="#D4AF37" stop-opacity="1"/>
      <stop offset="100%" stop-color="#A07820" stop-opacity="1"/>
    </radialGradient>
  </defs>
  <rect x="0" y="0" width="512" height="512" rx="90" ry="90" fill="#0D0B09"/>
  <rect x="0" y="0" width="512" height="512" rx="90" ry="90" fill="url(#purpleGlow)"/>
  <rect x="0" y="0" width="512" height="512" rx="90" ry="90" fill="none" stroke="#D4AF37" stroke-width="2" stroke-opacity="0.3"/>
  <polygon points="256,110 170,402 212,402 274,172" fill="url(#goldSheen)"/>
  <polygon points="256,110 342,402 300,402 238,172" fill="url(#goldSheen)"/>
  <rect x="180" y="282" width="152" height="34" rx="5" fill="url(#goldSheen)"/>
  <polygon points="256,100 270,126 256,118 242,126" fill="#F5D97A"/>
</svg>
```

Also create `public/axiom-logo-192.png` and `public/axiom-logo-512.png` by referencing the SVG — or use the SVG directly in the manifest if PNG generation is not available.

---

## Step 2: Create the Web App Manifest

Create `public/manifest.json`:

```json
{
  "name": "Axiom — Specification Engine",
  "short_name": "Axiom",
  "description": "Run it through Axiom before you build. The structural specification engine that eliminates the do-over tax.",
  "start_url": "/",
  "display": "standalone",
  "orientation": "any",
  "background_color": "#0D0B09",
  "theme_color": "#D4AF37",
  "icons": [
    {
      "src": "/axiom-logo.svg",
      "sizes": "any",
      "type": "image/svg+xml",
      "purpose": "any maskable"
    }
  ],
  "categories": ["productivity", "utilities", "developer"],
  "screenshots": []
}
```

---

## Step 3: Link the Manifest in the HTML

In `index.html`, add these tags inside `<head>`:

```html
<link rel="manifest" href="/manifest.json" />
<link rel="apple-touch-icon" href="/axiom-logo.svg" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="apple-mobile-web-app-title" content="Axiom" />
<meta name="theme-color" content="#D4AF37" />
<meta name="mobile-web-app-capable" content="yes" />
```

---

## Step 4: Add Install Prompt Component

Create `src/components/axiom/InstallPrompt.tsx`:

```typescript
import { useState, useEffect } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function InstallPrompt() {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!installEvent || dismissed) return null;

  const handleInstall = async () => {
    await installEvent.prompt();
    const { outcome } = await installEvent.userChoice;
    if (outcome === "accepted") {
      setInstallEvent(null);
    }
    setDismissed(true);
  };

  return (
    <div
      style={{
        position: "fixed",
        bottom: "80px",
        left: "50%",
        transform: "translateX(-50%)",
        background: "rgba(13, 11, 9, 0.96)",
        border: "1px solid rgba(212, 175, 55, 0.4)",
        borderRadius: "12px",
        padding: "12px 16px",
        display: "flex",
        alignItems: "center",
        gap: "12px",
        zIndex: 9998,
        maxWidth: "320px",
        width: "calc(100% - 40px)",
        backdropFilter: "blur(12px)",
      }}
    >
      <div style={{ flex: 1 }}>
        <div style={{ color: "#D4AF37", fontSize: "13px", fontWeight: 500 }}>
          Install Axiom
        </div>
        <div style={{ color: "rgba(255,255,255,0.5)", fontSize: "11px", marginTop: "2px" }}>
          Add to home screen for instant access
        </div>
      </div>
      <button
        onClick={handleInstall}
        style={{
          background: "#D4AF37",
          color: "#0D0B09",
          border: "none",
          borderRadius: "8px",
          padding: "8px 14px",
          fontSize: "12px",
          fontWeight: 600,
          cursor: "pointer",
          whiteSpace: "nowrap",
        }}
      >
        Install
      </button>
      <button
        onClick={() => setDismissed(true)}
        style={{
          background: "transparent",
          border: "none",
          color: "rgba(255,255,255,0.4)",
          cursor: "pointer",
          fontSize: "16px",
          padding: "4px",
          lineHeight: 1,
        }}
      >
        ✕
      </button>
    </div>
  );
}
```

---

## Step 5: Add InstallPrompt to AxiomLayout

In `src/components/axiom/AxiomLayout.tsx`:

Import and add `<InstallPrompt />` at the bottom of the main layout render, just before the closing tag:

```typescript
import { InstallPrompt } from "./InstallPrompt";

// Inside the return, before closing:
<InstallPrompt />
```

---

## Step 6: Register Service Worker

Create `public/sw.js`:

```javascript
const CACHE = "axiom-v1";
const ASSETS = ["/", "/index.html", "/manifest.json", "/axiom-logo.svg"];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS))
  );
});

self.addEventListener("fetch", (e) => {
  e.respondWith(
    caches.match(e.request).then((r) => r || fetch(e.request))
  );
});
```

Register the service worker in `index.html` before `</body>`:

```html
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js');
    });
  }
</script>
```

---

## After Building

1. Restart the dev server
2. Open Axiom in Chrome on mobile
3. Tap the browser menu → confirm "Add to Home Screen" option appears
4. On desktop Chrome → confirm install icon appears in the address bar
5. Install it — confirm it opens as standalone app with the gold "A" icon
6. Confirm the install prompt banner appears at the bottom of Axiom on first visit

---

## Scope

- `public/manifest.json` — new file
- `public/axiom-logo.svg` — new file
- `public/sw.js` — new file
- `index.html` — add manifest link tags + service worker registration
- `src/components/axiom/InstallPrompt.tsx` — new file
- `src/components/axiom/AxiomLayout.tsx` — add InstallPrompt

Do not touch any other files.
