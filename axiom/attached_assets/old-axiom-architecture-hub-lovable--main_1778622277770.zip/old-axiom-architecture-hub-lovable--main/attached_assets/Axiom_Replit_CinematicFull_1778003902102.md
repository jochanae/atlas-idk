# Axiom — Replit Agent Prompt: Cinematic Mode + Haptics + Sound + Vault Access + Autosave + Help

## Six Updates. Read Every Section Before Writing Any Code.

---

## Update 1: Remove Atmosphere Selector — Cinematic Is Permanent

In `src/components/axiom/CockpitBar.tsx`:

Remove the Stealth / Cinematic / Studio selector buttons entirely.

Cinematic mode is now the permanent default. No toggle. No options. Clean.

The space freed up in the Cockpit Bar should give the Readiness section and Export button more breathing room. Adjust spacing accordingly.

Do not remove the atmosphere state from the store — other components may reference it. Just set it permanently to "cinematic" and remove the UI selector.

---

## Update 2: Haptic Feedback — Vibration API

Create a new utility file: `src/lib/haptics.ts`

```typescript
// Axiom Haptic Feedback — Cinematic Mode
// Uses browser Vibration API — works on Android, silently fails on unsupported devices

const supported = typeof navigator !== 'undefined' && 'vibrate' in navigator;

export const haptics = {
  // Node turns gold — short crisp confirmation
  nodeResolved: () => {
    if (supported) navigator.vibrate(50);
  },

  // Sprint card answer confirmed — double pulse like a lock engaging
  cardConfirmed: () => {
    if (supported) navigator.vibrate([50, 40, 50]);
  },

  // Golden Specification ready — three ascending pulses, ceremonial
  specComplete: () => {
    if (supported) navigator.vibrate([60, 50, 80, 50, 120]);
  },

  // Context Shift detected — two sharp warning pulses
  contextShift: () => {
    if (supported) navigator.vibrate([80, 60, 80]);
  },

  // New session cleared — single long fade pulse
  sessionCleared: () => {
    if (supported) navigator.vibrate(200);
  },

  // Export triggered — single decisive pulse
  exported: () => {
    if (supported) navigator.vibrate(100);
  },

  // Tap confirmation — lightest touch
  tap: () => {
    if (supported) navigator.vibrate(30);
  },
};
```

**Wire haptics to these events:**

| Event | Haptic |
|---|---|
| System Map node resolves to gold | `haptics.nodeResolved()` |
| Sprint card answer confirmed | `haptics.cardConfirmed()` |
| AI response contains "Golden Specification" | `haptics.specComplete()` |
| AI response contains "Context Shift" | `haptics.contextShift()` |
| New Session confirmed | `haptics.sessionCleared()` |
| Export button tapped | `haptics.exported()` |
| Any card or keyword tapped | `haptics.tap()` |

Import `haptics` in `ChatHook.tsx`, `SystemMap.tsx`, and `CockpitBar.tsx` as needed.

---

## Update 3: Cinematic Sound — Web Audio API

Create a new utility file: `src/lib/sounds.ts`

Use the Web Audio API to generate tones programmatically — no audio files needed.

```typescript
// Axiom Sound Design — Cinematic Mode
// Generated via Web Audio API — no external files required

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

function playTone(
  frequency: number,
  duration: number,
  volume: number = 0.15,
  type: OscillatorType = 'sine',
  fadeOut: boolean = true
) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const oscillator = ctx.createOscillator();
  const gainNode = ctx.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(ctx.destination);

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);

  gainNode.gain.setValueAtTime(volume, ctx.currentTime);
  if (fadeOut) {
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
  }

  oscillator.start(ctx.currentTime);
  oscillator.stop(ctx.currentTime + duration);
}

export const sounds = {
  // Node resolves — soft metallic ping
  nodeResolved: () => {
    playTone(880, 0.3, 0.12, 'sine');
  },

  // Card confirmed — warm confirmation chime
  cardConfirmed: () => {
    playTone(660, 0.2, 0.1, 'sine');
    setTimeout(() => playTone(880, 0.3, 0.08, 'sine'), 100);
  },

  // Golden Specification — ceremonial ascending chord
  specComplete: () => {
    playTone(440, 0.4, 0.12, 'sine');
    setTimeout(() => playTone(550, 0.4, 0.1, 'sine'), 150);
    setTimeout(() => playTone(660, 0.6, 0.12, 'sine'), 300);
    setTimeout(() => playTone(880, 0.8, 0.1, 'sine'), 500);
  },

  // Context shift — low warning tone
  contextShift: () => {
    playTone(220, 0.4, 0.15, 'triangle');
    setTimeout(() => playTone(196, 0.5, 0.12, 'triangle'), 200);
  },

  // Session cleared — clean sweep tone
  sessionCleared: () => {
    playTone(440, 0.5, 0.08, 'sine');
  },

  // Export — single deep confirmation
  exported: () => {
    playTone(330, 0.6, 0.15, 'sine');
    setTimeout(() => playTone(440, 0.4, 0.1, 'sine'), 200);
  },

  // Tap — barely-there click
  tap: () => {
    playTone(1200, 0.05, 0.05, 'sine', false);
  },
};
```

**Wire sounds to the same events as haptics** — they always fire together:

```javascript
// Example: when a node resolves
haptics.nodeResolved();
sounds.nodeResolved();
```

**Important:** Audio context requires a user gesture to initialize on mobile. The first time any sound plays, if the audio context is suspended, resume it first:

```javascript
if (audioCtx?.state === 'suspended') {
  audioCtx.resume();
}
```

This automatically handles itself after the first user interaction (tap/type).

---

## Update 4: Folder Icon in Header → Vault Access

In `src/components/axiom/AxiomLayout.tsx` (or wherever the header is defined):

Add a **folder icon button** to the top left of the header, left of the "AXIOM" wordmark.

- Icon: folder or archive icon (from lucide-react: `FolderOpen` or `Archive`)
- Size: 20px
- Color: Luxury Gold `#D4AF37`
- On tap: navigate to `/vault`
- Tooltip/label on long press: "The Vault"
- Tap triggers `haptics.tap()` and `sounds.tap()`

Header layout after this change:
```
[Folder Icon]  AXIOM  [spacer]  0%  [New Session]
```

---

## Update 5: Autosave Sessions to Vault

In `src/components/axiom/ChatHook.tsx`:

After every AI response that contains Sprint-related content (detected by presence of "Sprint", "Architecture Locked", "Schema", or "Golden Specification"):

Automatically save to the `legacy_log` table in Supabase:

```javascript
await supabase.from('legacy_log').upsert({
  id: sessionId, // use a consistent session ID stored in component state
  prompt_output: fullConversationText, // all messages compiled
  builder: detectedBuilder,
  compatibility_score: readinessScore,
  updated_at: new Date().toISOString(),
});
```

Generate `sessionId` once when the component mounts using `crypto.randomUUID()` and store in state. This way each session has one record that gets updated rather than creating duplicate entries.

If Supabase save fails — fail silently. Log the error to console but do not show any error to the user.

---

## Update 6: Help Button for New Users

In the Tactical Cockpit Bar (`src/components/axiom/CockpitBar.tsx`):

Add a small **"?"** help button to the left side of the cockpit bar.

When tapped, show an inline help card that slides up from the cockpit bar:

```
┌─────────────────────────────────────┐
│  What is Axiom?                     │
│                                     │
│  Axiom is your specification engine.│
│  Before you spend a dollar in any   │
│  builder, Axiom makes sure you know │
│  exactly what you're building.      │
│                                     │
│  How it works:                      │
│  1. Describe your idea              │
│  2. Answer the Sprint questions     │
│  3. Watch the map fill with gold    │
│  4. Export your Blueprint           │
│  5. Build with zero guesswork       │
│                                     │
│  Tap any gold word to learn what    │
│  it means. Tap any node on the map  │
│  to see its status.                 │
│                            [Got it] │
└─────────────────────────────────────┘
```

**Style:**
- Background: Obsidian `oklch(0.15 0.01 60)`
- Border: 1px solid `rgba(212, 175, 55, 0.3)`
- Border radius: 12px top corners, 0 bottom (connects to cockpit bar)
- Slides up from the cockpit bar with smooth animation (200ms)
- "Got it" button: Luxury Gold, dismisses the card
- Tapping anywhere outside also dismisses it

**"?" button style:**
- Small circle, 28px
- Gold border, transparent background
- Gold "?" text
- Sits left of READINESS label in the cockpit bar

---

## Do Not Break

- Tap-to-answer Sprint cards (just built)
- Copy button on messages
- Tappable keyword definitions
- New Session button and confirmation
- Export / Blueprint download
- System Map node taps and info cards
- Chat send on Enter
- Typing indicator

---

## After Building

1. Restart dev server
2. Tap any node — confirm you feel a haptic pulse and hear a soft ping
3. Type a message and confirm a card answer — confirm double haptic pulse and chime
4. Tap the folder icon — confirm it navigates to /vault
5. Tap the "?" button — confirm help card slides up
6. Tap "Got it" — confirm it dismisses
7. Report what works and what doesn't

---

## Scope

- `src/lib/haptics.ts` — new file
- `src/lib/sounds.ts` — new file
- `src/components/axiom/CockpitBar.tsx` — remove atmosphere selector, add help button
- `src/components/axiom/AxiomLayout.tsx` — add folder icon to header
- `src/components/axiom/ChatHook.tsx` — wire haptics, sounds, autosave
- `src/components/axiom/SystemMap.tsx` — wire haptics and sounds to node resolution

Do not touch any other files.
