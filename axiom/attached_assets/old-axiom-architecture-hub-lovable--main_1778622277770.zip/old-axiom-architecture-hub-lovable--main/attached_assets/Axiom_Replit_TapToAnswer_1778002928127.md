# Axiom — Replit Agent Prompt: Tap-to-Answer Sprint Cards + Real-Time Node Updates

## This is a significant ChatHook upgrade. Read every section before touching any code.

---

## What We Are Building

When Axiom asks a Sprint question group, instead of rendering the questions as static text in a chat bubble, each question becomes a **tappable answer card**. The user taps a card, types a short answer, hits Next, moves to the next card. When all cards are answered, the answers compile into the input field for a final review before sending.

As each answer is confirmed, the corresponding System Map node updates to gold in real time.

---

## Step 1: Sprint Question Detection

In `src/components/axiom/ChatHook.tsx`:

After receiving an AI response, scan the message content to detect if it contains Sprint questions.

A message contains Sprint questions if it includes ANY of these patterns:
- The text "Sprint 1", "Sprint 2", or "Sprint 3" followed by questions
- A numbered list (1. 2. 3.) where items end with "?"
- Bold terms followed by ":" followed by a question (e.g., "**Users**: Who creates tasks?")

If Sprint questions are detected:
- Parse the message to extract each individual question
- Render the message in **Sprint Card Mode** instead of the normal chat bubble
- Each question becomes its own answer card

If NO Sprint questions are detected:
- Render normally as a standard chat bubble (existing behavior unchanged)

---

## Step 2: Sprint Card Mode Rendering

When a message is in Sprint Card Mode, render it as:

**Header section** (normal chat bubble style):
- The intro text before the questions (e.g., "Let's define your foundation. Answer these as a group:")
- Sprint label if present (e.g., "SPRINT 1 — THE CORE (ACCESS & DATA)")

**Question Cards** (below the header):
Each question renders as a card with:
- The bold keyword/label in Luxury Gold (e.g., "Users", "Auth Method")
- The question text below it in normal color
- A status indicator: empty circle when unanswered, gold checkmark when answered
- The card is tappable to open the answer input

**Card Style:**
```
Background: rgba(212, 175, 55, 0.06)
Border: 1px solid rgba(212, 175, 55, 0.2)
Border radius: 10px
Padding: 12px 14px
Margin: 6px 0
Tap state: border brightens to rgba(212, 175, 55, 0.5)
Answered state: left border 3px solid #D4AF37, subtle gold background
```

---

## Step 3: The Answer Input Flow

When a card is tapped:

1. A **focused input area** expands inline below that card (not a modal, not a separate screen)
2. Input field style: glassmorphic, same style as the main chat input
3. Placeholder text: "Your answer..."
4. Below the input: two buttons side by side:
   - **"Confirm"** (gold, filled) — saves the answer and collapses the input
   - **"Skip"** (muted, outlined) — marks card as skipped and moves to next
5. After Confirm: the card shows the answered state (gold left border, checkmark, answer text preview in small muted text below the question)
6. The input auto-closes after confirming

**Only one card input open at a time.** Tapping a different card closes the current input first.

---

## Step 4: The Compile & Send Flow

Once all cards have been answered (or skipped):

A **"Send All Answers"** button appears below the last card:
- Style: full width, Luxury Gold background, dark text, bold
- Label: **"Send All Answers →"**

When tapped:
1. Compile all answers into a structured message in this format:
```
[Question Label]: [Answer]
[Question Label]: [Answer]
[Question Label]: [Answer]
```
Example:
```
Users: Multi-tenant workspaces — teams of 2-10 people
Auth Method: Google OAuth primary, Magic Link fallback
Task Entity: Title, description, due date, priority, status, tags
Relationships: Tasks belong to Projects, Projects belong to Workspaces
Privacy Model: Tasks visible to workspace members, private override per task
```

2. Auto-populate the main chat input field with this compiled text
3. Scroll to the input field and focus it
4. Show the compiled text so the user can review and edit before sending
5. User hits the send button (or Enter) to actually submit

**Do NOT auto-send.** Always give the user the final review moment.

---

## Step 5: Real-Time Node Updates

As each card answer is confirmed (not when the full message is sent — when each individual card is confirmed):

Map the question card's keyword to a System Map node and resolve it immediately:

```javascript
const CARD_TO_NODE_MAP = {
  "users": "auth",
  "auth method": "auth",
  "auth": "auth",
  "task entity": "db",
  "entity": "db",
  "database": "db",
  "schema": "db",
  "relationships": "db",
  "privacy model": "db",
  "primary user action": "logic",
  "core loop": "logic",
  "edge cases": "logic",
  "payment layer": "logic",
  "revenue": "logic",
  "triggered events": "api",
  "webhooks": "api",
  "notifications": "api",
  "protected routes": "api",
  "api routes": "api",
  "responsive layout": "ui",
  "layout": "ui",
  "screens": "ui",
  "deployment": "api",
  "integrations": "api",
};
```

When a card is confirmed:
- Look up the card's label in `CARD_TO_NODE_MAP`
- If a matching node is found → call `resolveNode(nodeId)`
- The System Map node turns gold immediately
- Trigger the existing gold pulse animation on that node

---

## Step 6: Preserve All Existing Functionality

These must still work exactly as before:
- Copy button on every AI message
- Tappable keyword definitions
- New Session button
- Export button
- Normal (non-Sprint) AI messages render as standard chat bubbles
- Typing indicator during AI response
- Send on Enter for the main input
- System Map node tap info cards
- Readiness score updates

---

## Implementation Notes

- Parse questions by looking for the pattern: bold text + colon + question text
- Regex suggestion: `/\*\*([^*]+)\*\*:\s*([^?]+\?)/g`
- Store card answers in local component state: `Record<string, string>`
- The Sprint card mode only applies to AI messages — never to user messages
- If question parsing fails for any reason, fall back to normal bubble rendering

---

## After Building

1. Restart dev server
2. Type: "I'm building a task manager app for teams, taking it to Atlas"
3. When Sprint 1 cards appear — confirm:
   - Each question is a separate tappable card
   - Tapping a card opens an inline input
   - Confirming an answer updates the card and turns the corresponding map node gold
   - After all cards answered, "Send All Answers" button appears
   - Tapping it populates the input field for final review
4. Report what works and what doesn't — do not mark complete until all 5 behaviors are confirmed

---

## Scope

**`src/components/axiom/ChatHook.tsx` primarily.**
**`src/components/axiom/SystemMap.tsx`** only if node pulse animation needs to be triggered externally.
Do not touch any other files.
Do not change colors, layout, or any other component.
Do not auto-send — always require the user to hit send after review.
