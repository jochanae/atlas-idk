# Axiom — Replit Agent Prompt: Image Attachments (Chat Hook + Quick Prompt)

## Image Support in Both Chat Modes. Read Every Section Before Writing Any Code.

---

## What We Are Building

Add the ability to attach up to 10 images per message in both:
1. The main Chat Hook (full spec mode)
2. The Quick Prompt mode (floating panel)

Claude (claude-sonnet-4-5) natively supports image inputs via the Anthropic API. Images are sent as base64 alongside the text message. No external service needed.

---

## The User Experience

### Attachment Flow
- A paperclip icon sits in the input area of both Chat Hook and Quick Prompt
- Tapping it opens the device image picker (camera roll / file browser)
- User can select up to 10 images
- Selected images appear as small thumbnails in a horizontal row above the input field
- Each thumbnail has a small ✕ to remove it before sending
- When the user sends — images + text go together to Claude
- Claude sees the images and responds based on what it sees

### Thumbnail Row Style
- Horizontal scrollable row above the input
- Each thumbnail: 60px × 60px, rounded corners (8px), gold border (1px)
- ✕ remove button: small, top-right corner of each thumbnail, gold
- Row only appears when at least one image is attached
- Row disappears after message is sent

### Paperclip Button Style
- Same style as existing action buttons in the input area
- Icon: paperclip (from lucide-react: `Paperclip`)
- Color: muted silver by default, Luxury Gold when images are attached
- Position: left side of input area, next to existing buttons
- Shows a small count badge when images are attached (e.g., "2" in gold)

---

## The Technical Implementation

### Step 1: Image Selection

In both `src/components/axiom/ChatHook.tsx` and `src/components/axiom/QuickPrompt.tsx`:

Add a hidden file input that accepts images:
```jsx
<input
  type="file"
  accept="image/*"
  multiple
  max={10}
  ref={fileInputRef}
  onChange={handleImageSelect}
  style={{ display: 'none' }}
/>
```

Handle image selection:
```javascript
const handleImageSelect = async (e) => {
  const files = Array.from(e.target.files).slice(0, 10);
  const imageData = await Promise.all(
    files.map(async (file) => {
      const base64 = await fileToBase64(file);
      return {
        id: crypto.randomUUID(),
        base64: base64.split(',')[1], // strip the data:image/... prefix
        mediaType: file.type, // e.g., "image/jpeg", "image/png"
        preview: base64, // full data URL for thumbnail display
        name: file.name,
      };
    })
  );
  setAttachedImages(prev => [...prev, ...imageData].slice(0, 10));
};

const fileToBase64 = (file) => new Promise((resolve) => {
  const reader = new FileReader();
  reader.onload = () => resolve(reader.result);
  reader.readAsDataURL(file);
});
```

Store attached images in component state:
```javascript
const [attachedImages, setAttachedImages] = useState([]);
```

### Step 2: Update the API Call

In `supabase/functions/axiom-chat/index.ts`:

Update the request body to accept images:
```javascript
const { messages, builder, mode, images } = await req.json();
```

When building the messages array for Claude, if images are present on the last user message, format that message as a multi-part content array:

```javascript
// If the last message has images, convert it to multi-part format
const formattedMessages = messages.map((msg, index) => {
  const isLastUserMessage = index === messages.length - 1 && msg.role === 'user';
  
  if (isLastUserMessage && images && images.length > 0) {
    return {
      role: 'user',
      content: [
        // Add each image first
        ...images.map(img => ({
          type: 'image',
          source: {
            type: 'base64',
            media_type: img.mediaType,
            data: img.base64,
          },
        })),
        // Then the text
        {
          type: 'text',
          text: msg.content,
        },
      ],
    };
  }
  
  return msg;
});
```

Update the Anthropic API call to use `formattedMessages` instead of `messages`.

### Step 3: Send Images with Message

When the user sends a message with attachments:

```javascript
const handleSend = async () => {
  if (!input.trim() && attachedImages.length === 0) return;
  
  const content = input.trim() || 'Please analyze the attached image(s).';
  
  // Add message to chat with image previews
  addMessage({
    id: crypto.randomUUID(),
    role: 'user',
    content,
    images: attachedImages.map(img => img.preview), // for display
    timestamp: Date.now(),
  });
  
  setInput('');
  
  // Call AI with images
  await callAxiomAI(content, attachedImages);
  
  // Clear attachments after sending
  setAttachedImages([]);
};
```

### Step 4: Display Sent Images in Chat

In the message bubble for user messages that have images:

Show a horizontal row of image thumbnails above the message text:
- Each image: 80px × 80px, rounded, gold border
- Tapping an image expands it to full screen (lightbox)
- Simple lightbox: dark overlay, full-size image, tap outside to close

### Step 5: Update callAxiomAI to Accept Images

```javascript
const callAxiomAI = async (userContent, images = []) => {
  setIsTyping(true);
  try {
    const apiMessages = messages
      .filter(m => m.id !== 'welcome')
      .map(m => ({
        role: m.role === 'system' ? 'assistant' : 'user',
        content: m.content,
      }));
    
    apiMessages.push({ role: 'user', content: userContent });

    const { data, error } = await supabase.functions.invoke('axiom-chat', {
      body: { 
        messages: apiMessages, 
        builder: detectedBuilder,
        mode: activeMode, // 'spec' or 'quick'
        images: images.map(img => ({ // send image data to edge function
          base64: img.base64,
          mediaType: img.mediaType,
        })),
      },
    });
    // ... rest of existing handler
  }
};
```

---

## Quick Prompt Mode — Same Implementation

Apply the identical attachment system to `src/components/axiom/QuickPrompt.tsx`:

- Paperclip icon in the Quick Prompt input area
- Same thumbnail row above input
- When generating — images go with the text to Claude
- Claude analyzes the screenshot and generates the prompt based on what it sees

**Quick Prompt with image example:**
User attaches a screenshot of a broken dropdown, types "fix this", selects Cursor — Axiom sees the screenshot, understands the visual issue, outputs a precise Cursor prompt targeting the specific component causing the problem.

---

## Image Size Limits

Before converting to base64, check file size:
```javascript
const MAX_SIZE_MB = 5;
if (file.size > MAX_SIZE_MB * 1024 * 1024) {
  // Show toast: "Image too large. Maximum 5MB per image."
  return null;
}
```

Filter out null values after the check.

---

## Haptics

- Images attached → `haptics.tap()`
- Image removed → `haptics.tap()`
- Message with images sent → `haptics.cardConfirmed()`

---

## Do Not Break

- All existing chat functionality
- Sprint card tap-to-answer flow
- Copy buttons and keyword definitions
- Quick Prompt generation
- Export Blueprint
- New Session (clears attached images too)
- Vault autosave

---

## Files To Update

- `src/components/axiom/ChatHook.tsx` — add attachment UI + logic
- `src/components/axiom/QuickPrompt.tsx` — add attachment UI + logic
- `supabase/functions/axiom-chat/index.ts` — handle images in API call

---

## After Building

1. Restart dev server
2. In Chat Hook — tap paperclip, select an image, confirm thumbnail appears
3. Type "What's wrong with this UI?" and send
4. Confirm Claude responds describing what it sees in the image
5. In Quick Prompt — attach a screenshot of a broken component
6. Select Cursor, type "fix this", tap Generate
7. Confirm Axiom outputs a targeted Cursor prompt based on the screenshot
8. Confirm images display as thumbnails in sent messages
9. Confirm tapping a thumbnail expands it

Report what works and what doesn't.

---

## Scope

Three files only:
- `src/components/axiom/ChatHook.tsx`
- `src/components/axiom/QuickPrompt.tsx`
- `supabase/functions/axiom-chat/index.ts`

Do not touch any other files.
Do not change any layout or styling outside the attachment UI elements.
