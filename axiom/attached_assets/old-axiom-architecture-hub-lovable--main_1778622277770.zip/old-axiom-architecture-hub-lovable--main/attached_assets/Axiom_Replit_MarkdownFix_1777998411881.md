# Axiom — Replit Agent Prompt: Render Markdown in Chat Messages

## The Problem

AI responses in the Chat Hook are displaying raw markdown syntax:
- `**bold**` showing as literal asterisks instead of bold text
- `##` showing as literal hash symbols instead of headers
- `---` showing as literal dashes instead of dividers
- Numbered lists showing correctly but without proper spacing

## What To Fix

In `src/components/axiom/ChatHook.tsx`:

Find the `renderContent` function. Currently it only highlights gold keywords. It needs to also parse and render markdown.

### The Fix

Install the `react-markdown` package:
```
npm install react-markdown
```

Then update the `renderContent` function to use ReactMarkdown for AI messages (role: "system") while keeping the gold keyword highlighting for user messages (role: "user").

Replace the existing `renderContent` function with this approach:

For **AI messages** (system role) — render using ReactMarkdown with these style overrides to match the Axiom aesthetic:

```javascript
// Strong/bold → Luxury Gold text
// h2/h3 headers → Luxury Gold, slightly larger, uppercase tracking
// hr dividers → thin gold line (1px, 20% gold opacity)
// Lists → proper spacing, gold bullet points
// Paragraphs → normal text color, proper line height
// Code blocks → obsidian background, gold text, monospace font
```

For **user messages** — keep the existing plain text render with gold keyword highlighting.

### Specific Style Requirements

All markdown elements must match the Axiom aesthetic:

```css
strong/bold: color #D4AF37 (Luxury Gold)
h2, h3: color #D4AF37, font-size slightly larger, letter-spacing 0.05em
hr: border-color rgba(212, 175, 55, 0.2), margin 8px 0
ul/ol: padding-left 1.25rem, space between items
li: color inherit, line-height 1.6
p: margin-bottom 0.5rem, line-height 1.6
code: background rgba(212, 175, 55, 0.1), color #D4AF37, padding 2px 6px, border-radius 4px
pre: background rgba(0,0,0,0.3), padding 12px, border-radius 8px, border 1px solid rgba(212,175,55,0.2)
```

### Do Not Break

- Gold keyword highlighting on user messages must still work
- Typing indicator must still work
- Message bubble layout must not change
- Send on Enter must still work
- The input field must not be affected

## After Making Changes

1. Save the file
2. Restart the dev server
3. Open the app and type: **"I'm building a booking app and taking it to Lovable"**
4. Confirm the response renders with:
   - Bold text in gold
   - Section headers visible and styled
   - Clean numbered list with proper spacing
   - No raw asterisks or hash symbols visible

## Scope

**`src/components/axiom/ChatHook.tsx` only.**
Install `react-markdown` if not already present.
Do not change any other files.
Do not change any layout or styling outside the message bubble content.
