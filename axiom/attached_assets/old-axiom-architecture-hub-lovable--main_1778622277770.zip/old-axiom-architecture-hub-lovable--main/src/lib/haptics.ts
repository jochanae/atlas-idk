// Axiom Haptic Feedback — Cinematic Mode
// Uses browser Vibration API — works on Android, silently fails on unsupported devices

const supported = typeof navigator !== "undefined" && "vibrate" in navigator;

function isEnabled(): boolean {
  try { return localStorage.getItem("axiom_haptics_enabled") !== "false"; } catch { return true; }
}

export const haptics = {
  // Node turns gold — short crisp confirmation
  nodeResolved: () => {
    if (supported && isEnabled()) navigator.vibrate(50);
  },

  // Sprint card answer confirmed — double pulse like a lock engaging
  cardConfirmed: () => {
    if (supported && isEnabled()) navigator.vibrate([50, 40, 50]);
  },

  // Golden Specification ready — three ascending pulses, ceremonial
  specComplete: () => {
    if (supported && isEnabled()) navigator.vibrate([60, 50, 80, 50, 120]);
  },

  // Context Shift detected — two sharp warning pulses
  contextShift: () => {
    if (supported && isEnabled()) navigator.vibrate([80, 60, 80]);
  },

  // New session cleared — single long fade pulse
  sessionCleared: () => {
    if (supported && isEnabled()) navigator.vibrate(200);
  },

  // Export triggered — single decisive pulse
  exported: () => {
    if (supported && isEnabled()) navigator.vibrate(100);
  },

  // Tap confirmation — lightest touch
  tap: () => {
    if (supported && isEnabled()) navigator.vibrate(30);
  },
};
