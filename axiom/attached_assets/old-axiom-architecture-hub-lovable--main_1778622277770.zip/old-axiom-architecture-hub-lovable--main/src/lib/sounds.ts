// Axiom Sound Design — Cinematic Mode
// Generated via Web Audio API — no external files required

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  // Resume if suspended (required after first user gesture on mobile)
  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

function isSoundsEnabled(): boolean {
  try { return localStorage.getItem("axiom_sounds_enabled") !== "false"; } catch { return true; }
}

function playTone(
  frequency: number,
  duration: number,
  volume: number = 0.15,
  type: OscillatorType = "sine",
  fadeOut: boolean = true
) {
  if (!isSoundsEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const oscillator = ctx.createOscillator();
  const gainNode = ctx.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(ctx.destination);

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);

  gainNode.gain.setValueAtTime(volume, ctx.currentTime);
  if (fadeOut) {
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
  }

  oscillator.start(ctx.currentTime);
  oscillator.stop(ctx.currentTime + duration);
}

export const sounds = {
  // Node resolves — soft metallic ping
  nodeResolved: () => {
    playTone(880, 0.3, 0.12, "sine");
  },

  // Card confirmed — warm confirmation chime
  cardConfirmed: () => {
    playTone(660, 0.2, 0.1, "sine");
    setTimeout(() => playTone(880, 0.3, 0.08, "sine"), 100);
  },

  // Golden Specification — ceremonial ascending chord
  specComplete: () => {
    playTone(440, 0.4, 0.12, "sine");
    setTimeout(() => playTone(550, 0.4, 0.1, "sine"), 150);
    setTimeout(() => playTone(660, 0.6, 0.12, "sine"), 300);
    setTimeout(() => playTone(880, 0.8, 0.1, "sine"), 500);
  },

  // Context shift — low warning tone
  contextShift: () => {
    playTone(220, 0.4, 0.15, "triangle");
    setTimeout(() => playTone(196, 0.5, 0.12, "triangle"), 200);
  },

  // Session cleared — clean sweep tone
  sessionCleared: () => {
    playTone(440, 0.5, 0.08, "sine");
  },

  // Export — single deep confirmation
  exported: () => {
    playTone(330, 0.6, 0.15, "sine");
    setTimeout(() => playTone(440, 0.4, 0.1, "sine"), 200);
  },

  // Tap — barely-there click
  tap: () => {
    playTone(1200, 0.05, 0.05, "sine", false);
  },
};
