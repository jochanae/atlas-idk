import { useState, useEffect } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function InstallPrompt() {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!installEvent || dismissed) return null;

  const handleInstall = async () => {
    await installEvent.prompt();
    const { outcome } = await installEvent.userChoice;
    if (outcome === "accepted") {
      setInstallEvent(null);
    }
    setDismissed(true);
  };

  return (
    <div
      style={{
        position: "fixed",
        bottom: "80px",
        left: "50%",
        transform: "translateX(-50%)",
        background: "rgba(13, 11, 9, 0.96)",
        border: "1px solid rgba(212, 175, 55, 0.4)",
        borderRadius: "12px",
        padding: "12px 16px",
        display: "flex",
        alignItems: "center",
        gap: "12px",
        zIndex: 9998,
        maxWidth: "320px",
        width: "calc(100% - 40px)",
        backdropFilter: "blur(12px)",
      }}
    >
      <div style={{ flex: 1 }}>
        <div style={{ color: "#D4AF37", fontSize: "13px", fontWeight: 500 }}>
          Install Axiom
        </div>
        <div style={{ color: "rgba(255,255,255,0.5)", fontSize: "11px", marginTop: "2px" }}>
          Add to home screen for instant access
        </div>
      </div>
      <button
        onClick={handleInstall}
        style={{
          background: "#D4AF37",
          color: "#0D0B09",
          border: "none",
          borderRadius: "8px",
          padding: "8px 14px",
          fontSize: "12px",
          fontWeight: 600,
          cursor: "pointer",
          whiteSpace: "nowrap",
        }}
      >
        Install
      </button>
      <button
        onClick={() => setDismissed(true)}
        style={{
          background: "transparent",
          border: "none",
          color: "rgba(255,255,255,0.4)",
          cursor: "pointer",
          fontSize: "16px",
          padding: "4px",
          lineHeight: 1,
        }}
      >
        ✕
      </button>
    </div>
  );
}
