import { useState, useRef, useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { ProjectProfiles } from "./ProjectProfiles";
import { UpgradeModal } from "./UpgradeModal";
import { useSubscription } from "@/hooks/use-subscription";
import { createPortalSession } from "@/utils/payments.functions";
import { getStripeEnvironment } from "@/lib/stripe";
import { supabase } from "@/integrations/supabase/client";

const BUILDER_OPTIONS = [
  "Lovable", "Cursor", "Replit", "Bolt", "Windsurf",
  "v0 by Vercel", "Bubble", "FlutterFlow", "GitHub Copilot", "Other",
];

const EXPERIENCE_LEVELS = [
  {
    id: "architect",
    title: "ARCHITECT",
    description: "90% code, 10% context.\nDrop the diff. Skip the tutorial.",
  },
  {
    id: "builder",
    title: "BUILDER",
    description: "Code with the \"why\" included.\nI'm building actively but still learning.",
  },
  {
    id: "foundation",
    title: "FOUNDATION",
    description: "Step-by-step guidance.\nExplain concepts as they appear.",
  },
];

const LS_DEFAULT_BUILDER = "axiom_default_builder";
const LS_EXPERIENCE = "axiom_experience_level";
const LS_HAPTICS = "axiom_haptics_enabled";
const LS_SOUNDS = "axiom_sounds_enabled";
const LS_THEME = "axiom_theme";
const LS_GITHUB_TOKEN = "axiom_github_token";

function lsGet(key: string, fallback: string): string {
  try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
}
function lsSet(key: string, value: string) {
  try { localStorage.setItem(key, value); } catch {}
}

interface SettingsProps {
  open: boolean;
  onClose: () => void;
}

export function Settings({ open, onClose }: SettingsProps) {
  const [defaultBuilder, setDefaultBuilder] = useState(() => lsGet(LS_DEFAULT_BUILDER, ""));
  const [showBuilderDd, setShowBuilderDd] = useState(false);
  const [experienceLevel, setExperienceLevel] = useState(() => lsGet(LS_EXPERIENCE, "builder"));
  const [hapticsOn, setHapticsOn] = useState(() => lsGet(LS_HAPTICS, "true") !== "false");
  const [soundsOn, setSoundsOn] = useState(() => lsGet(LS_SOUNDS, "true") !== "false");
  const [theme, setTheme] = useState(() => lsGet(LS_THEME, "dark"));
  const [toast, setToast] = useState<string | null>(null);
  const [githubToken, setGithubToken] = useState(() => lsGet(LS_GITHUB_TOKEN, ""));
  const [showToken, setShowToken] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const builderDdRef = useRef<HTMLDivElement>(null);
  const [userAvatar, setUserAvatar] = useState<string | null>(null);
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [showUpgrade, setShowUpgrade] = useState(false);
  const { status: subStatus, monthlyUsage, currentPeriodEnd, cancelAtPeriodEnd } = useSubscription();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const u = data?.user;
      if (u) {
        setUserAvatar(u.user_metadata?.avatar_url || u.user_metadata?.picture || null);
        setUserName(u.user_metadata?.full_name || u.user_metadata?.name || "");
        setUserEmail(u.email || "");
      }
    });
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  useEffect(() => {
    if (!open) return;
    setDefaultBuilder(lsGet(LS_DEFAULT_BUILDER, ""));
    setExperienceLevel(lsGet(LS_EXPERIENCE, "builder"));
    setHapticsOn(lsGet(LS_HAPTICS, "true") !== "false");
    setSoundsOn(lsGet(LS_SOUNDS, "true") !== "false");
    setTheme(lsGet(LS_THEME, "dark"));
  }, [open]);

  useEffect(() => {
    if (!showBuilderDd) return;
    const h = (e: MouseEvent) => {
      if (builderDdRef.current && !builderDdRef.current.contains(e.target as Node)) setShowBuilderDd(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [showBuilderDd]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  };

  const handleBuilderSelect = (b: string) => {
    setDefaultBuilder(b);
    setShowBuilderDd(false);
    lsSet(LS_DEFAULT_BUILDER, b);
    showToast("Default builder saved.");
  };

  const handleExperience = (level: string) => {
    setExperienceLevel(level);
    lsSet(LS_EXPERIENCE, level);
    showToast("Experience level saved.");
  };

  const handleTheme = (t: string) => {
    setTheme(t);
    lsSet(LS_THEME, t);
    if (t === "light") {
      document.documentElement.setAttribute("data-theme", "light");
    } else {
      document.documentElement.removeAttribute("data-theme");
    }
  };

  const handleHaptics = () => {
    const next = !hapticsOn;
    setHapticsOn(next);
    lsSet(LS_HAPTICS, next ? "true" : "false");
  };

  const handleSounds = () => {
    const next = !soundsOn;
    setSoundsOn(next);
    lsSet(LS_SOUNDS, next ? "true" : "false");
  };

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "fixed", inset: 0, zIndex: 10000,
          background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)",
          WebkitBackdropFilter: "blur(4px)",
        }}
      />

      {/* Bottom sheet */}
      <div
        style={{
          position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10001,
          height: "80dvh", background: "#0D0B09",
          borderTop: "1px solid rgba(212,175,55,0.3)",
          borderRadius: "18px 18px 0 0",
          display: "flex", flexDirection: "column",
          boxShadow: "0 -8px 48px rgba(0,0,0,0.7)",
        }}
      >
        {/* Handle */}
        <div style={{ display: "flex", justifyContent: "center", padding: "10px 0 4px" }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(212,175,55,0.3)" }} />
        </div>

        {/* Header */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "6px 20px 12px", borderBottom: "1px solid rgba(212,175,55,0.1)",
        }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.12em" }}>
            SETTINGS
          </span>
          <button onClick={onClose}
            style={{
              background: "none", border: "none", cursor: "pointer",
              color: "rgba(156,163,175,0.55)", fontSize: 18, lineHeight: 1,
              display: "flex", alignItems: "center", justifyContent: "center",
              width: 32, height: 32,
            }}>
            ✕
          </button>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 48px" }}>

          {/* ── PROFILE ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 14,
              padding: "12px 14px", borderRadius: 12,
              background: "rgba(212,175,55,0.06)",
              border: "1px solid rgba(212,175,55,0.12)",
            }}>
              {userAvatar ? (
                <img
                  src={userAvatar}
                  alt={userName}
                  referrerPolicy="no-referrer"
                  style={{ width: 44, height: 44, borderRadius: "22%", objectFit: "cover", border: "1.5px solid rgba(212,175,55,0.4)", flexShrink: 0 }}
                />
              ) : (
                <div style={{
                  width: 44, height: 44, borderRadius: "22%", background: "#0D0B09",
                  border: "1.5px solid #D4AF37", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                }}>
                  <span style={{ fontSize: 18, fontWeight: 700, color: "#D4AF37" }}>{userName?.[0]?.toUpperCase() || "?"}</span>
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#e8dcc8", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {userName || "User"}
                </div>
                <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {userEmail}
                </div>
              </div>
              <button
                onClick={handleSignOut}
                style={{
                  padding: "6px 14px", borderRadius: 8, fontSize: 11, fontWeight: 600,
                  color: "rgba(239,68,68,0.8)", background: "rgba(239,68,68,0.08)",
                  border: "1px solid rgba(239,68,68,0.2)", cursor: "pointer",
                  flexShrink: 0, transition: "all 150ms",
                }}
              >
                Sign Out
              </button>
            </div>
          </section>

          {/* ── BILLING ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Billing
              </div>
            </div>

            {subStatus === "loading" ? (
              <div style={{ fontSize: 12, color: "rgba(156,163,175,0.4)" }}>Loading...</div>
            ) : subStatus === "pro" ? (
              <div style={{
                padding: "14px", borderRadius: 12,
                background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.25)",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <span style={{ color: "#D4AF37", fontSize: 10 }}>◆</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.08em" }}>PRO PLAN</span>
                </div>
                {currentPeriodEnd && (
                  <div style={{ fontSize: 11, color: "rgba(156,163,175,0.6)", marginBottom: 10 }}>
                    {cancelAtPeriodEnd ? "Cancels" : "Renews"} {new Date(currentPeriodEnd).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                  </div>
                )}
                <button
                  onClick={async () => {
                    try {
                      const url = await createPortalSession({ data: { returnUrl: window.location.href, environment: getStripeEnvironment() } });
                      window.open(url, "_blank");
                    } catch (e) {
                      console.error("Portal error:", e);
                    }
                  }}
                  style={{
                    width: "100%", padding: "10px", borderRadius: 8,
                    background: "transparent", border: "1px solid rgba(212,175,55,0.4)",
                    color: "#D4AF37", fontSize: 12, fontWeight: 600, cursor: "pointer",
                  }}
                >
                  Manage Subscription →
                </button>
              </div>
            ) : (
              <div style={{
                padding: "14px", borderRadius: 12,
                background: "rgba(212,175,55,0.03)", border: "1px solid rgba(212,175,55,0.15)",
              }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: "rgba(212,175,55,0.5)", letterSpacing: "0.06em", marginBottom: 10 }}>
                  FREE PLAN
                </div>
                {/* Usage bar */}
                <div style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                    <span style={{ fontSize: 11, color: "rgba(156,163,175,0.6)" }}>AI calls this month</span>
                    <span style={{ fontSize: 11, fontWeight: 600, color: monthlyUsage >= 7 ? "rgba(245,158,11,0.9)" : "rgba(212,175,55,0.8)" }}>
                      {monthlyUsage}/10
                    </span>
                  </div>
                  <div style={{ height: 6, borderRadius: 3, background: "rgba(212,175,55,0.1)", overflow: "hidden" }}>
                    <div style={{
                      height: "100%", borderRadius: 3,
                      width: `${Math.min(100, (monthlyUsage / 10) * 100)}%`,
                      background: monthlyUsage >= 7 ? "rgba(245,158,11,0.8)" : "#D4AF37",
                      transition: "width 300ms ease",
                    }} />
                  </div>
                </div>
                <button onClick={() => setShowUpgrade(true)}
                  style={{
                    width: "100%", padding: "10px", borderRadius: 8,
                    background: "transparent", border: "1px solid rgba(212,175,55,0.4)",
                    color: "#D4AF37", fontSize: 12, fontWeight: 600, cursor: "pointer",
                  }}
                >
                  Upgrade to Pro →
                </button>
              </div>
            )}
          </section>

          {/* ── DEFAULT BUILDER ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Default Builder
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginTop: 3 }}>
                Pre-selected every time you open Quick Prompt
              </div>
            </div>
            <div ref={builderDdRef} style={{ position: "relative" }}>
              <button type="button" onClick={() => setShowBuilderDd(v => !v)}
                style={{
                  width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                  background: "#0D0B09",
                  border: `1px solid ${showBuilderDd || defaultBuilder ? "rgba(212,175,55,0.5)" : "rgba(212,175,55,0.3)"}`,
                  borderRadius: 8, padding: "11px 14px", cursor: "pointer", transition: "border-color 180ms",
                }}>
                <span style={{ fontSize: 14, color: defaultBuilder ? "rgba(255,255,255,0.87)" : "rgba(255,255,255,0.35)" }}>
                  {defaultBuilder || "Select default builder..."}
                </span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#D4AF37"
                  strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
                  style={{ flexShrink: 0, transform: showBuilderDd ? "rotate(180deg)" : "rotate(0)", transition: "transform 180ms" }}>
                  <polyline points="6 9 12 15 18 9" />
                </svg>
              </button>
              {showBuilderDd && (
                <div style={{
                  position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 10050,
                  background: "#0D0B09", border: "1px solid rgba(212,175,55,0.3)", borderRadius: 10,
                  overflow: "hidden", boxShadow: "0 8px 32px rgba(0,0,0,0.7)",
                  maxHeight: 220, overflowY: "auto",
                }}>
                  {BUILDER_OPTIONS.map(b => {
                    const isSel = b === defaultBuilder;
                    return (
                      <button key={b} type="button" onClick={() => handleBuilderSelect(b)}
                        style={{
                          width: "100%", display: "flex", alignItems: "center", gap: 8,
                          padding: "10px 14px",
                          background: isSel ? "rgba(212,175,55,0.12)" : "transparent",
                          border: "none", cursor: "pointer", textAlign: "left",
                        }}
                        onMouseEnter={e => { if (!isSel) (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.04)"; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = isSel ? "rgba(212,175,55,0.12)" : "transparent"; }}
                      >
                        <span style={{ fontSize: 13, color: isSel ? "#D4AF37" : "rgba(255,255,255,0.87)", fontWeight: isSel ? 600 : 400 }}>
                          {b}
                        </span>
                        {isSel && (
                          <svg style={{ marginLeft: "auto" }} width="12" height="12" viewBox="0 0 24 24"
                            fill="none" stroke="#D4AF37" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </section>

          {/* ── EXPERIENCE LEVEL ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Experience Level
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginTop: 3 }}>
                Axiom adapts its responses to match your level
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {EXPERIENCE_LEVELS.map(lvl => {
                const selected = experienceLevel === lvl.id;
                return (
                  <button key={lvl.id} type="button" onClick={() => handleExperience(lvl.id)}
                    style={{
                      display: "flex", alignItems: "flex-start", gap: 12, padding: "14px",
                      background: selected ? "rgba(212,175,55,0.07)" : "#0D0B09",
                      border: `1px solid ${selected ? "rgba(212,175,55,0.6)" : "rgba(212,175,55,0.18)"}`,
                      borderRadius: 10, cursor: "pointer", textAlign: "left",
                      transition: "border-color 180ms, background 180ms", width: "100%",
                    }}>
                    <div style={{
                      width: 16, height: 16, borderRadius: "50%", flexShrink: 0, marginTop: 2,
                      border: `2px solid ${selected ? "#D4AF37" : "rgba(212,175,55,0.35)"}`,
                      background: selected ? "#D4AF37" : "transparent",
                      boxShadow: selected ? "0 0 6px rgba(212,175,55,0.4)" : "none",
                      transition: "all 180ms",
                    }} />
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.06em", marginBottom: 4, color: selected ? "#D4AF37" : "rgba(255,255,255,0.87)" }}>
                        {lvl.title}
                      </div>
                      <div style={{ fontSize: 11, color: "rgba(156,163,175,0.65)", lineHeight: 1.55, whiteSpace: "pre-line" }}>
                        {lvl.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* ── PROJECT PROFILES ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Project Profiles
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginTop: 3 }}>
                Save your project context once. Use it every time.
              </div>
            </div>
            <ProjectProfiles />
          </section>

          {/* ── GITHUB ACCESS ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em",
              color: "#D4AF37", marginBottom: 4, textTransform: "uppercase" }}>
              GITHUB ACCESS
            </div>
            <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginBottom: 12 }}>
              Required for private repo access. Stored locally, never sent to any server.
            </div>

            {githubToken ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.2)",
                  borderRadius: 10, padding: "10px 12px"
                }}>
                  <span style={{ fontSize: 12, color: "rgba(229,231,235,0.7)",
                    fontFamily: "monospace", flex: 1 }}>
                    {showToken ? githubToken : "•".repeat(Math.min(githubToken.length, 24))}
                  </span>
                  <button
                    onClick={() => setShowToken(!showToken)}
                    style={{ fontSize: 10, color: "#D4AF37", background: "none",
                      border: "none", cursor: "pointer", marginLeft: 8 }}>
                    {showToken ? "Hide" : "Show"}
                  </button>
                </div>

                {!showDeleteConfirm ? (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    style={{ fontSize: 11, color: "rgba(239,68,68,0.7)", background: "none",
                      border: "1px solid rgba(239,68,68,0.2)", borderRadius: 8,
                      padding: "8px 12px", cursor: "pointer", textAlign: "left" }}>
                    Remove token
                  </button>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 6,
                    background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.2)",
                    borderRadius: 10, padding: 12 }}>
                    <span style={{ fontSize: 11, color: "rgba(229,231,235,0.7)" }}>
                      Remove your GitHub token? This cannot be undone.
                    </span>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button
                        onClick={() => {
                          lsSet(LS_GITHUB_TOKEN, "");
                          setGithubToken("");
                          setShowDeleteConfirm(false);
                          setShowToken(false);
                        }}
                        style={{ flex: 1, padding: "8px 0", borderRadius: 8,
                          background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)",
                          color: "rgba(239,68,68,0.9)", fontSize: 11,
                          fontWeight: 700, cursor: "pointer" }}>
                        Yes, remove it
                      </button>
                      <button
                        onClick={() => setShowDeleteConfirm(false)}
                        style={{ flex: 1, padding: "8px 0", borderRadius: 8,
                          background: "transparent", border: "1px solid rgba(212,175,55,0.2)",
                          color: "rgba(212,175,55,0.6)", fontSize: 11, cursor: "pointer" }}>
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                  value={githubToken}
                  onChange={(e) => setGithubToken(e.target.value)}
                  style={{
                    width: "100%", padding: "10px 12px", borderRadius: 10,
                    background: "rgba(13,11,9,0.6)", fontSize: 12,
                    border: "1px solid rgba(212,175,55,0.2)", color: "rgba(229,231,235,0.9)",
                    fontFamily: "monospace", outline: "none",
                    boxSizing: "border-box"
                  }}
                />
                <button
                  onClick={() => {
                    if (githubToken.trim()) {
                      lsSet(LS_GITHUB_TOKEN, githubToken.trim());
                      setGithubToken(githubToken.trim());
                    }
                  }}
                  disabled={!githubToken.trim()}
                  style={{ padding: "10px 0", borderRadius: 10, fontSize: 12,
                    fontWeight: 700, cursor: "pointer", transition: "all 150ms",
                    background: githubToken.trim() ? "rgba(212,175,55,0.15)" : "transparent",
                    border: githubToken.trim() ? "1px solid rgba(212,175,55,0.4)"
                      : "1px solid rgba(212,175,55,0.1)",
                    color: githubToken.trim() ? "#D4AF37" : "rgba(212,175,55,0.3)" }}>
                  Save Token
                </button>
              </div>
            )}
          </section>

          {/* ── APPEARANCE ── */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em",
              color: "#D4AF37", marginBottom: 12, textTransform: "uppercase" }}>
              APPEARANCE
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {(["dark", "light"] as const).map((t) => {
                const active = (lsGet("axiom_theme", "dark")) === t;
                return (
                  <button
                    key={t}
                    onClick={() => {
                      lsSet("axiom_theme", t);
                      window.dispatchEvent(new Event("axiom-theme-change"));
                    }}
                    style={{
                      flex: 1,
                      padding: "10px 0",
                      borderRadius: 10,
                      border: active ? "1px solid #D4AF37" : "1px solid rgba(212,175,55,0.2)",
                      background: active ? "rgba(212,175,55,0.12)" : "transparent",
                      color: active ? "#D4AF37" : "rgba(156,163,175,0.6)",
                      fontSize: 12,
                      fontWeight: 700,
                      textTransform: "uppercase",
                      letterSpacing: "0.08em",
                      cursor: "pointer",
                      transition: "all 150ms",
                    }}
                  >
                    {t === "dark" ? "◆ Dark" : "◇ Light"}
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── HAPTICS & SOUND ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Feedback
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginTop: 3 }}>
                Cinematic sensory feedback
              </div>
            </div>
            <div>
              {/* Haptics */}
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "14px 0", borderBottom: "1px solid rgba(212,175,55,0.07)",
              }}>
                <div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.87)", fontWeight: 500 }}>Haptic Feedback</div>
                  <div style={{ fontSize: 11, color: "rgba(156,163,175,0.45)", marginTop: 2 }}>Vibration on key actions</div>
                </div>
                <button type="button" onClick={handleHaptics}
                  style={{ background: "none", border: "none", cursor: "pointer", padding: 0, flexShrink: 0 }}>
                  <div style={{
                    width: 44, height: 26, borderRadius: 13, position: "relative",
                    background: hapticsOn ? "#D4AF37" : "rgba(107,114,128,0.35)",
                    transition: "background 200ms",
                  }}>
                    <div style={{
                      position: "absolute", top: 3,
                      left: hapticsOn ? 21 : 3,
                      width: 20, height: 20, borderRadius: "50%",
                      background: hapticsOn ? "#0D0B09" : "rgba(255,255,255,0.65)",
                      transition: "left 200ms",
                    }} />
                  </div>
                </button>
              </div>
              {/* Sounds */}
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "14px 0",
              }}>
                <div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.87)", fontWeight: 500 }}>Sound Effects</div>
                  <div style={{ fontSize: 11, color: "rgba(156,163,175,0.45)", marginTop: 2 }}>Cinematic audio cues</div>
                </div>
                <button type="button" onClick={handleSounds}
                  style={{ background: "none", border: "none", cursor: "pointer", padding: 0, flexShrink: 0 }}>
                  <div style={{
                    width: 44, height: 26, borderRadius: 13, position: "relative",
                    background: soundsOn ? "#D4AF37" : "rgba(107,114,128,0.35)",
                    transition: "background 200ms",
                  }}>
                    <div style={{
                      position: "absolute", top: 3,
                      left: soundsOn ? 21 : 3,
                      width: 20, height: 20, borderRadius: "50%",
                      background: soundsOn ? "#0D0B09" : "rgba(255,255,255,0.65)",
                      transition: "left 200ms",
                    }} />
                  </div>
                </button>
              </div>
            </div>
          </section>

          {/* ── ABOUT ── */}
          <section>
            <div style={{
              textAlign: "center", padding: "20px 0",
              borderTop: "1px solid rgba(212,175,55,0.1)",
            }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(212,175,55,0.75)", letterSpacing: "0.12em", marginBottom: 5 }}>
                AXIOM
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginBottom: 2 }}>
                Structural Specification Engine
              </div>
              <div style={{ fontSize: 10, color: "rgba(156,163,175,0.4)", marginBottom: 12 }}>
                Version 1.0 — Into Innovations
              </div>
              <div style={{ fontSize: 11, color: "rgba(156,163,175,0.38)", fontStyle: "italic" }}>
                The intelligence layer before the first line of code.
              </div>
            </div>
          </section>

          {/* ── LINKS ── */}
          <section style={{ marginBottom: 32 }}>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "12px 20px", justifyContent: "center" }}>
              <Link to="/terms" style={{ fontSize: 11, fontWeight: 600, color: "rgba(212,175,55,0.6)", textDecoration: "underline", textUnderlineOffset: 3 }}>Terms</Link>
              <Link to="/privacy" style={{ fontSize: 11, fontWeight: 600, color: "rgba(212,175,55,0.6)", textDecoration: "underline", textUnderlineOffset: 3 }}>Privacy</Link>
              <Link to="/help" style={{ fontSize: 11, fontWeight: 600, color: "rgba(212,175,55,0.6)", textDecoration: "underline", textUnderlineOffset: 3 }}>Help &amp; FAQ</Link>
              <Link to="/admin" style={{ fontSize: 11, fontWeight: 600, color: "#805AD5", textDecoration: "underline", textUnderlineOffset: 3 }}>Admin Hub</Link>
            </div>
          </section>

        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", bottom: 88, left: "50%", transform: "translateX(-50%)",
          zIndex: 10200, background: "rgba(13,11,9,0.92)",
          border: "1px solid rgba(212,175,55,0.5)", borderRadius: 8,
          padding: "8px 18px", fontSize: 12, fontWeight: 600, color: "#D4AF37",
          backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
          whiteSpace: "nowrap", boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
          pointerEvents: "none",
        }}>
          {toast}
        </div>
      )}
      <UpgradeModal open={showUpgrade} onClose={() => setShowUpgrade(false)} />
    </>
  );
}
