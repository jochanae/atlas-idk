import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Link, useNavigate } from "@tanstack/react-router";

const LS_INJECT = "axiom_inject_spec";

function getDnaPills(text: string): { label: string; count: number }[] {
  const t = text.toLowerCase();
  return [
    { label: "DB",   count: (t.match(/database/g) || []).length },
    { label: "API",  count: (t.match(/\bapi\b|\broute/g) || []).length },
    { label: "Auth", count: (t.match(/auth/g) || []).length },
  ].filter((p) => p.count > 0);
}

interface LegacyLogItem {
  id: string;
  prompt_output: string | null;
  builder: string | null;
  compatibility_score: number | null;
  created_at: string | null;
}

function formatDate(iso: string | null): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) +
      " · " + d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  } catch {
    return iso;
  }
}

export function VaultGrid() {
  const navigate = useNavigate();
  const [items, setItems] = useState<LegacyLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [loadedId, setLoadedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2000);
  };

  const handleLoad = (item: LegacyLogItem) => {
    try { localStorage.setItem(LS_INJECT, item.prompt_output || ""); } catch {}
    setLoadedId(item.id);
    setTimeout(() => navigate({ to: "/" }), 300);
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("legacy_log")
          .select("id, prompt_output, builder, compatibility_score, created_at")
          .order("created_at", { ascending: false });
        if (!error && data) setItems(data as LegacyLogItem[]);
      } catch (e) {
        console.error("Vault load failed:", e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleCopy = async (item: LegacyLogItem) => {
    const text = item.prompt_output || "";
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await supabase.from("legacy_log").delete().eq("id", id);
      setItems((prev) => prev.filter((i) => i.id !== id));
      showToast("Deleted from Vault");
    } catch (e) {
      console.error("Delete failed:", e);
      showToast("Delete failed. Try again.");
    } finally {
      setDeletingId(null);
      setConfirmDeleteId(null);
    }
  };

  const filtered = items.filter((item) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (item.prompt_output?.toLowerCase().includes(q) ?? false) ||
      (item.builder?.toLowerCase().includes(q) ?? false)
    );
  });

  return (
    <div className="p-6 min-h-full" style={{ paddingBottom: "calc(40px + env(safe-area-inset-bottom, 0px))" }}>
      {/* Toast */}
      {toast && (
        <div
          style={{
            position: "fixed", top: 24, left: "50%", transform: "translateX(-50%)",
            zIndex: 99999, background: "rgba(13,11,9,0.97)",
            border: "1px solid rgba(212,175,55,0.5)", borderRadius: 10,
            padding: "10px 20px", color: "#D4AF37", fontSize: 13, fontWeight: 700,
            boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
          }}
        >
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-bold text-gold" style={{ fontSize: 22, letterSpacing: "0.12em" }}>THE VAULT</h1>
          <p className="text-xs text-silver-muted mt-1">Legacy Log — Saved Specifications.</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="glass rounded-lg px-3 py-1.5">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search specs..."
              className="bg-transparent text-xs text-foreground placeholder:text-muted-foreground outline-none w-40"
            />
          </div>
          <Link
            to="/"
            className="rounded-lg border border-gold/30 bg-gold/10 px-3 py-1.5 text-xs font-semibold text-gold hover:bg-gold/20 transition-all"
          >
            ← Back to Axiom
          </Link>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "0ms" }} />
            <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "150ms" }} />
            <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "300ms" }} />
          </div>
        </div>
      )}

      {/* Empty state */}
      {!loading && filtered.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="text-3xl mb-4 opacity-30" style={{ color: "#D4AF37" }}>◆</div>
          <p className="text-sm font-semibold text-silver-muted mb-1">
            {items.length === 0 ? "No specs saved yet." : "No specs match your search."}
          </p>
          {items.length === 0 && (
            <p className="text-xs text-silver-muted max-w-xs" style={{ opacity: 0.6 }}>
              Save a prompt from Quick Prompt or your Chat sessions to build your architecture library.
            </p>
          )}
        </div>
      )}

      {/* Grid */}
      {!loading && filtered.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              style={{
                background: "rgba(13, 11, 9, 0.95)",
                border: "1px solid rgba(212, 175, 55, 0.3)",
                borderRadius: 12,
                padding: 16,
                display: "flex",
                flexDirection: "column",
                gap: 10,
                transition: "border-color 200ms, box-shadow 200ms",
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(212,175,55,0.6)"; (e.currentTarget as HTMLDivElement).style.boxShadow = "0 0 24px rgba(212,175,55,0.12)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(212,175,55,0.3)"; (e.currentTarget as HTMLDivElement).style.boxShadow = "none"; }}
            >
              {/* Top row: builder badge + date */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                {item.builder ? (
                  <span style={{
                    fontSize: 10, fontWeight: 700, letterSpacing: "0.08em",
                    color: "#D4AF37", border: "1px solid rgba(212,175,55,0.4)",
                    borderRadius: 20, padding: "2px 9px", background: "rgba(212,175,55,0.08)",
                    textTransform: "uppercase", whiteSpace: "nowrap",
                  }}>
                    {item.builder}
                  </span>
                ) : <span />}
                <span style={{ fontSize: 10, color: "rgba(156,163,175,0.55)", textAlign: "right", flexShrink: 0 }}>
                  {formatDate(item.created_at)}
                </span>
              </div>

              {/* Preview text */}
              <p style={{
                fontSize: 13, color: "rgba(229,231,235,0.87)", lineHeight: 1.55,
                overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 3,
                WebkitBoxOrient: "vertical",
              }}>
                {(item.prompt_output || "").slice(0, 240)}
              </p>

              {/* Technical DNA Stamp */}
              {(() => {
                const text = item.prompt_output || "";
                const pills = getDnaPills(text);
                const hasScore = item.compatibility_score != null;
                if (!hasScore && pills.length === 0) return null;
                return (
                  <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 5 }}>
                    {hasScore && (
                      <span style={{ fontSize: 10, fontWeight: 700, color: "#D4AF37" }}>
                        ◆ {item.compatibility_score}% Readiness
                      </span>
                    )}
                    {pills.map((p) => (
                      <span
                        key={p.label}
                        style={{
                          fontSize: 9, border: "1px solid rgba(212,175,55,0.2)",
                          borderRadius: 20, padding: "1px 6px",
                          color: "rgba(212,175,55,0.5)",
                        }}
                      >
                        {p.label} {p.count}
                      </span>
                    ))}
                  </div>
                );
              })()}

              {/* Action buttons */}
              <div style={{ display: "flex", gap: 8, marginTop: 2 }}>
                <button
                  onClick={() => handleCopy(item)}
                  style={{
                    flex: 1, borderRadius: 8, padding: "7px 0", fontSize: 11, fontWeight: 700,
                    border: "1px solid rgba(212,175,55,0.35)",
                    background: copiedId === item.id ? "rgba(212,175,55,0.18)" : "rgba(212,175,55,0.08)",
                    color: "#D4AF37", cursor: "pointer", transition: "all 150ms",
                  }}
                >
                  {copiedId === item.id ? "Copied ✓" : "Copy"}
                </button>
                <button
                  onClick={() => handleLoad(item)}
                  style={{
                    flex: 1, borderRadius: 8, padding: "7px 0", fontSize: 11, fontWeight: 700,
                    border: "1px solid rgba(212,175,55,0.35)",
                    background: loadedId === item.id ? "rgba(212,175,55,0.18)" : "rgba(212,175,55,0.08)",
                    color: "#D4AF37", cursor: "pointer", transition: "all 150ms",
                  }}
                >
                  {loadedId === item.id ? "Loading…" : "⟳ Load"}
                </button>
                {confirmDeleteId === item.id ? (
                  <div style={{ display: "flex", gap: 5 }}>
                    <button
                      onClick={() => handleDelete(item.id)}
                      disabled={deletingId === item.id}
                      style={{
                        borderRadius: 8, padding: "7px 10px", fontSize: 11, fontWeight: 700,
                        border: "1px solid rgba(239,68,68,0.5)", background: "rgba(239,68,68,0.12)",
                        color: "rgba(239,68,68,0.9)", cursor: "pointer",
                      }}
                    >
                      {deletingId === item.id ? "..." : "Delete"}
                    </button>
                    <button
                      onClick={() => setConfirmDeleteId(null)}
                      style={{
                        borderRadius: 8, padding: "7px 10px", fontSize: 11,
                        border: "1px solid rgba(107,114,128,0.3)", background: "transparent",
                        color: "rgba(156,163,175,0.7)", cursor: "pointer",
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDeleteId(item.id)}
                    style={{
                      borderRadius: 8, padding: "7px 10px", fontSize: 11,
                      border: "1px solid rgba(107,114,128,0.3)", background: "transparent",
                      color: "rgba(156,163,175,0.55)", cursor: "pointer", transition: "all 150ms",
                    }}
                    onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = "rgba(239,68,68,0.8)"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(239,68,68,0.4)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = "rgba(156,163,175,0.55)"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(107,114,128,0.3)"; }}
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
