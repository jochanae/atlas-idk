import { useState, useEffect, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";
import { loadProfilesAsync, type ProjectProfile } from "./ProjectProfiles";
import { supabase } from "@/integrations/supabase/client";
import { useUpgradeGate } from "@/hooks/use-upgrade-gate";
import { useSubscription } from "@/hooks/use-subscription";

const LS_VAULT_CACHE = "axiom_vault_cache";
const LS_ACTIVE_PROJECT = "axiom_active_project";

interface VaultEntry {
  builder: string;
  prompt_output: string;
  saved_at: string;
}

function loadVaultCache(): VaultEntry[] {
  try {
    const r = localStorage.getItem(LS_VAULT_CACHE);
    return r ? JSON.parse(r) : [];
  } catch { return []; }
}

async function saveProfileToDB(profile: ProjectProfile) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from("projects").insert({
    name: profile.name,
    builder: profile.builder || null,
    tech_stack: profile.techStack,
    file_structure: profile.fileStructure,
    notes: profile.notes,
    user_id: user.id,
  });
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    const diff = Date.now() - d.getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
  } catch { return ""; }
}

const BUILDER_OPTIONS = [
  "Lovable", "Cursor", "Replit", "Bolt", "Windsurf",
  "v0 by Vercel", "Bubble", "FlutterFlow", "GitHub Copilot", "Other",
];

interface FolderPanelProps {
  open: boolean;
  onClose: () => void;
}

export function FolderPanel({ open, onClose }: FolderPanelProps) {
  const navigate = useNavigate();
  const { openUpgrade } = useUpgradeGate();
  const { status: subStatus } = useSubscription();
  const [profiles, setProfiles] = useState<ProjectProfile[]>([]);
  const [vaultEntries, setVaultEntries] = useState<VaultEntry[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newBuilder, setNewBuilder] = useState("");
  const [newNotes, setNewNotes] = useState("");
  const [loadedId, setLoadedId] = useState<string | null>(null);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(() => {
    try {
      const r = localStorage.getItem("axiom_active_project");
      return r ? JSON.parse(r).id : null;
    } catch { return null; }
  });
  const [codebaseMode, setCodebaseMode] = useState<"idle"|"url"|"zip">("idle");
  const [repoUrl, setRepoUrl] = useState("");
  const [repoLoading, setRepoLoading] = useState(false);
  const [repoError, setRepoError] = useState("");
  const [repoSuccess, setRepoSuccess] = useState("");
  const [zipLoading, setZipLoading] = useState(false);
  const [zipError, setZipError] = useState("");
  const [zipSuccess, setZipSuccess] = useState("");
  const zipInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    loadProfilesAsync().then(setProfiles);
    setVaultEntries(loadVaultCache().slice(-3).reverse());
    setShowAddForm(false);
    setNewName("");
    setNewBuilder("");
    setNewNotes("");
    setLoadedId(null);
  }, [open]);

  const handleAddProfile = async () => {
    if (!newName.trim()) return;
    const profile: ProjectProfile = {
      id: crypto.randomUUID(),
      name: newName.trim(),
      builder: newBuilder,
      techStack: "",
      fileStructure: "",
      notes: newNotes.trim(),
      lastUsed: null,
    };
    await saveProfileToDB(profile);
    const updated = await loadProfilesAsync();
    setProfiles(updated);
    setShowAddForm(false);
    setNewName("");
    setNewBuilder("");
    setNewNotes("");
  };

  const handleLoadProfile = (profile: ProjectProfile) => {
    try {
      localStorage.setItem(LS_ACTIVE_PROJECT, JSON.stringify(profile));
    } catch {}
    setLoadedId(profile.id);
    setActiveProjectId(profile.id);
    window.dispatchEvent(new Event("axiom-project-change"));
    setTimeout(() => {
      setLoadedId(null);
      onClose();
    }, 800);
  };

  const handleDeactivate = () => {
    try { localStorage.removeItem("axiom_active_project"); } catch {}
    setActiveProjectId(null);
    window.dispatchEvent(new Event("axiom-project-change"));
  };

  const handleOpenVault = () => {
    onClose();
    navigate({ to: "/vault" });
  };

  const handleRepoConnect = async () => {
    if (!repoUrl.trim()) return;
    setRepoLoading(true);
    setRepoError("");
    setRepoSuccess("");
    try {
      const raw = repoUrl.trim()
        .replace("https://github.com/", "")
        .replace(/\/$/, "");
      const token = localStorage.getItem("axiom_github_token");
      const headers: Record<string, string> = { Accept: "application/vnd.github+json" };
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const res = await fetch(`https://api.github.com/repos/${raw}/contents`, { headers });
      if (!res.ok) {
        if (res.status === 404) throw new Error("Repo not found. Check the URL.");
        if (res.status === 401) throw new Error("Private repo — add your GitHub token in Settings.");
        throw new Error(`GitHub error: ${res.status}`);
      }
      const files = await res.json();
      const tree = files
        .map((f: { name: string; type: string }) =>
          `${f.type === "dir" ? "📁" : "📄"} ${f.name}`)
        .join("\n");
      const context = `GitHub Repo: ${raw}\n\nRoot file tree:\n${tree}`;
      localStorage.setItem("axiom_codebase_context", context);
      setRepoSuccess(`Connected — ${files.length} items in root`);
      setRepoUrl("");
    } catch (e: unknown) {
      setRepoError(e instanceof Error ? e.message : "Connection failed");
    } finally {
      setRepoLoading(false);
    }
  };

  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setZipLoading(true);
    setZipError("");
    setZipSuccess("");
    try {
      const JSZip = (await import("jszip")).default;
      const zip = await JSZip.loadAsync(file);
      const paths: string[] = [];
      zip.forEach((relativePath) => { paths.push(relativePath); });
      const tree = paths
        .filter(p => !p.includes("node_modules") && !p.includes(".git"))
        .slice(0, 200)
        .join("\n");
      const context = `ZIP Upload: ${file.name}\n\nFile tree:\n${tree}`;
      localStorage.setItem("axiom_codebase_context", context);
      setZipSuccess(`Scanned — ${paths.length} files indexed`);
    } catch {
      setZipError("Could not read ZIP file");
    } finally {
      setZipLoading(false);
      e.target.value = "";
    }
  };

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "fixed", inset: 0, zIndex: 10000,
          background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)",
          WebkitBackdropFilter: "blur(4px)",
        }}
      />

      {/* Bottom sheet */}
      <div
        style={{
          position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10001,
          height: "80dvh", background: "#0D0B09",
          borderTop: "1px solid rgba(212,175,55,0.3)",
          borderRadius: "18px 18px 0 0",
          display: "flex", flexDirection: "column",
          boxShadow: "0 -8px 48px rgba(0,0,0,0.7)",
        }}
      >
        {/* Drag handle */}
        <div style={{ display: "flex", justifyContent: "center", padding: "10px 0 4px" }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(212,175,55,0.3)" }} />
        </div>

        {/* Header */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "6px 20px 12px", borderBottom: "1px solid rgba(212,175,55,0.1)",
        }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.12em" }}>
            PROJECTS
          </span>
          <button
            onClick={onClose}
            style={{
              background: "none", border: "none", cursor: "pointer",
              color: "rgba(156,163,175,0.55)", fontSize: 18, lineHeight: 1,
              display: "flex", alignItems: "center", justifyContent: "center",
              width: 32, height: 32,
            }}
          >
            ✕
          </button>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 48px" }}>

          {/* ── PROJECT PROFILES ── */}
          <section style={{ marginBottom: 36 }}>
            <div style={{
              fontSize: 11, fontWeight: 700, color: "#D4AF37",
              letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 14,
            }}>
              Project Profiles
            </div>

            {profiles.length === 0 && !showAddForm ? (
              <div style={{
                display: "flex", flexDirection: "column", alignItems: "center",
                padding: "28px 16px", gap: 10,
                border: "1px dashed rgba(212,175,55,0.2)", borderRadius: 12,
              }}>
                {/* Gold diamond */}
                <span style={{ fontSize: 22, color: "#D4AF37", lineHeight: 1 }}>◆</span>
                <span style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", fontWeight: 500 }}>
                  No projects saved yet.
                </span>
                <span style={{ fontSize: 11, color: "rgba(156,163,175,0.45)", textAlign: "center" }}>
                  Save a project profile to load context instantly.
                </span>
                <button
                  onClick={() => setShowAddForm(true)}
                  style={{
                    marginTop: 6,
                    background: "transparent",
                    border: "1px solid rgba(212,175,55,0.5)",
                    borderRadius: 8,
                    padding: "8px 16px",
                    fontSize: 12,
                    fontWeight: 700,
                    color: "#D4AF37",
                    cursor: "pointer",
                    letterSpacing: "0.04em",
                  }}
                >
                  + Start Your First Project
                </button>
              </div>
            ) : (
              <>
                {profiles.map((p) => (
                  <div
                    key={p.id}
                    style={{
                      display: "flex", alignItems: "center", justifyContent: "space-between",
                      background: "rgba(212,175,55,0.05)",
                      border: activeProjectId === p.id ? "1px solid rgba(212,175,55,0.5)" : "1px solid rgba(212,175,55,0.15)",
                      borderRadius: 10, padding: "10px 14px", marginBottom: 8,
                    }}
                  >
                    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.87)" }}>
                        {p.name}
                      </span>
                      {p.builder && (
                        <span style={{
                          fontSize: 10, fontWeight: 700, color: "#D4AF37",
                          background: "rgba(212,175,55,0.1)",
                          border: "0.5px solid rgba(212,175,55,0.3)",
                          borderRadius: 4, padding: "1px 6px",
                          alignSelf: "flex-start", letterSpacing: "0.06em",
                          textTransform: "uppercase",
                        }}>
                          {p.builder}
                        </span>
                      )}
                    </div>
                    {activeProjectId === p.id ? (
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                        <span style={{
                          fontSize: 10, fontWeight: 700, color: "#D4AF37",
                          background: "rgba(212,175,55,0.1)",
                          border: "1px solid rgba(212,175,55,0.3)",
                          borderRadius: 6, padding: "3px 10px",
                          letterSpacing: "0.06em",
                        }}>
                          ◆ Active
                        </span>
                        <button
                          onClick={handleDeactivate}
                          style={{
                            fontSize: 10, color: "rgba(239,68,68,0.6)",
                            background: "none", border: "none",
                            cursor: "pointer", padding: 0,
                          }}
                        >
                          Deactivate
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleLoadProfile(p)}
                        style={{
                          fontSize: 11, fontWeight: 700,
                          color: loadedId === p.id ? "rgba(212,175,55,0.5)" : "#D4AF37",
                          background: loadedId === p.id ? "rgba(212,175,55,0.05)" : "rgba(212,175,55,0.1)",
                          border: "1px solid rgba(212,175,55,0.3)",
                          borderRadius: 6, padding: "5px 12px", cursor: "pointer",
                          transition: "all 200ms",
                          letterSpacing: "0.04em",
                        }}
                      >
                        {loadedId === p.id ? "Loaded ✓" : "Load"}
                      </button>
                    )}
                  </div>
                ))}

                {!showAddForm && (
                  <button
                    onClick={() => setShowAddForm(true)}
                    style={{
                      width: "100%", marginTop: 4,
                      background: "transparent",
                      border: "1px dashed rgba(212,175,55,0.3)",
                      borderRadius: 8, padding: "8px 0",
                      fontSize: 12, fontWeight: 600, color: "rgba(212,175,55,0.6)",
                      cursor: "pointer",
                    }}
                  >
                    + Add Profile
                  </button>
                )}
              </>
            )}

            {/* Inline add form */}
            {showAddForm && (
              <div style={{
                background: "rgba(212,175,55,0.04)",
                border: "1px solid rgba(212,175,55,0.2)",
                borderRadius: 10, padding: 14, marginTop: 8,
                display: "flex", flexDirection: "column", gap: 10,
              }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.08em" }}>
                  NEW PROFILE
                </span>

                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Project name *"
                  style={{
                    background: "#0D0B09", border: "1px solid rgba(212,175,55,0.25)",
                    borderRadius: 7, padding: "8px 12px", fontSize: 13,
                    color: "rgba(229,231,235,0.9)", outline: "none",
                    fontFamily: "inherit",
                  }}
                />

                {/* Builder select */}
                <select
                  value={newBuilder}
                  onChange={(e) => setNewBuilder(e.target.value)}
                  style={{
                    background: "#0D0B09", border: "1px solid rgba(212,175,55,0.25)",
                    borderRadius: 7, padding: "8px 12px", fontSize: 13,
                    color: newBuilder ? "rgba(229,231,235,0.9)" : "rgba(156,163,175,0.5)",
                    outline: "none", cursor: "pointer", fontFamily: "inherit",
                  }}
                >
                  <option value="" disabled>Select builder (optional)</option>
                  {BUILDER_OPTIONS.map((b) => (
                    <option key={b} value={b} style={{ color: "rgba(229,231,235,0.9)", background: "#0D0B09" }}>
                      {b}
                    </option>
                  ))}
                </select>

                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Notes (optional)"
                  rows={2}
                  style={{
                    background: "#0D0B09", border: "1px solid rgba(212,175,55,0.25)",
                    borderRadius: 7, padding: "8px 12px", fontSize: 12,
                    color: "rgba(229,231,235,0.9)", outline: "none", resize: "none",
                    fontFamily: "inherit",
                  }}
                />

                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={handleAddProfile}
                    disabled={!newName.trim()}
                    style={{
                      flex: 1, background: "#D4AF37", border: "none",
                      borderRadius: 7, padding: "8px 0",
                      fontSize: 12, fontWeight: 700, color: "#0D0B09",
                      cursor: newName.trim() ? "pointer" : "not-allowed",
                      opacity: newName.trim() ? 1 : 0.4,
                    }}
                  >
                    Save Profile
                  </button>
                  <button
                    onClick={() => { setShowAddForm(false); setNewName(""); setNewBuilder(""); setNewNotes(""); }}
                    style={{
                      flex: 1, background: "transparent",
                      border: "1px solid rgba(212,175,55,0.25)",
                      borderRadius: 7, padding: "8px 0",
                      fontSize: 12, fontWeight: 600, color: "rgba(156,163,175,0.6)",
                      cursor: "pointer",
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </section>

          {/* ── RECENT VAULT ── */}
          <section style={{ marginBottom: 24 }}>
            <div style={{
              fontSize: 11, fontWeight: 700, color: "#D4AF37",
              letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 14,
            }}>
              Recent Vault
            </div>

            {vaultEntries.length === 0 ? (
              <p style={{ fontSize: 12, color: "rgba(156,163,175,0.45)", padding: "8px 0" }}>
                No saved specs yet.
              </p>
            ) : (
              vaultEntries.map((entry, i) => (
                <div
                  key={i}
                  style={{
                    background: "rgba(212,175,55,0.04)",
                    border: "1px solid rgba(212,175,55,0.12)",
                    borderRadius: 10, padding: "10px 14px", marginBottom: 8,
                    display: "flex", flexDirection: "column", gap: 6,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    {entry.builder && (
                      <span style={{
                        fontSize: 10, fontWeight: 700, color: "#D4AF37",
                        background: "rgba(212,175,55,0.1)",
                        border: "0.5px solid rgba(212,175,55,0.3)",
                        borderRadius: 4, padding: "1px 6px",
                        letterSpacing: "0.06em", textTransform: "uppercase",
                      }}>
                        {entry.builder}
                      </span>
                    )}
                    <span style={{ fontSize: 10, color: "rgba(156,163,175,0.45)", marginLeft: "auto" }}>
                      {formatDate(entry.saved_at)}
                    </span>
                  </div>
                  <p style={{
                    fontSize: 12, color: "rgba(229,231,235,0.6)",
                    lineHeight: 1.5, margin: 0,
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  }}>
                    {entry.prompt_output.slice(0, 60)}{entry.prompt_output.length > 60 ? "…" : ""}
                  </p>
                </div>
              ))
            )}

            <button
              onClick={handleOpenVault}
              style={{
                background: "none", border: "none", cursor: "pointer",
                fontSize: 12, fontWeight: 600, color: "rgba(212,175,55,0.7)",
                padding: "6px 0", letterSpacing: "0.03em",
                textDecoration: "underline", textDecorationColor: "rgba(212,175,55,0.3)",
              }}
            >
              Open Full Vault →
            </button>
          </section>

          {/* ── CODEBASE CONTEXT ── */}
          <div style={{ borderTop: "1px solid rgba(212,175,55,0.1)",
            paddingTop: 20, marginTop: 4 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em",
              color: "#D4AF37", marginBottom: 4, textTransform: "uppercase" }}>
              CODEBASE CONTEXT
            </div>
            <div style={{ fontSize: 11, color: "rgba(156,163,175,0.5)", marginBottom: 12 }}>
              Connect your codebase so Axiom understands what's already built.
            </div>

            {localStorage.getItem("axiom_codebase_context") ? (
              <div style={{ display: "flex", alignItems: "center",
                justifyContent: "space-between", marginBottom: 12,
                background: "rgba(212,175,55,0.06)",
                border: "1px solid rgba(212,175,55,0.2)",
                borderRadius: 10, padding: "8px 12px" }}>
                <span style={{ fontSize: 11, color: "rgba(212,175,55,0.8)" }}>
                  ◆ Codebase connected
                </span>
                <button
                  onClick={() => {
                    localStorage.removeItem("axiom_codebase_context");
                    setRepoSuccess("");
                    setZipSuccess("");
                  }}
                  style={{ fontSize: 10, color: "rgba(156,163,175,0.5)",
                    background: "none", border: "none", cursor: "pointer" }}>
                  Disconnect
                </button>
              </div>
            ) : null}

            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              <button
                onClick={() => {
                  if (subStatus === "free") { openUpgrade("Codebase intake requires Pro"); return; }
                  setCodebaseMode(codebaseMode === "url" ? "idle" : "url");
                }}
                style={{
                  flex: 1, padding: "9px 0", borderRadius: 10, fontSize: 11,
                  fontWeight: 700, cursor: "pointer", transition: "all 150ms",
                  background: codebaseMode === "url"
                    ? "rgba(212,175,55,0.15)" : "transparent",
                  border: codebaseMode === "url"
                    ? "1px solid rgba(212,175,55,0.4)"
                    : "1px solid rgba(212,175,55,0.15)",
                  color: codebaseMode === "url"
                    ? "#D4AF37" : "rgba(156,163,175,0.5)",
                }}>
                GitHub URL
              </button>
              <button
                onClick={() => {
                  if (subStatus === "free") { openUpgrade("Codebase intake requires Pro"); return; }
                  setCodebaseMode(codebaseMode === "zip" ? "idle" : "zip");
                }}
                style={{
                  flex: 1, padding: "9px 0", borderRadius: 10, fontSize: 11,
                  fontWeight: 700, cursor: "pointer", transition: "all 150ms",
                  background: codebaseMode === "zip"
                    ? "rgba(212,175,55,0.15)" : "transparent",
                  border: codebaseMode === "zip"
                    ? "1px solid rgba(212,175,55,0.4)"
                    : "1px solid rgba(212,175,55,0.15)",
                  color: codebaseMode === "zip"
                    ? "#D4AF37" : "rgba(156,163,175,0.5)",
                }}>
                Upload ZIP
              </button>
            </div>

            {codebaseMode === "url" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <input
                  type="url"
                  placeholder="https://github.com/username/repo"
                  value={repoUrl}
                  onChange={(e) => setRepoUrl(e.target.value)}
                  style={{
                    width: "100%", padding: "10px 12px", borderRadius: 10,
                    background: "rgba(13,11,9,0.6)", fontSize: 12,
                    border: "1px solid rgba(212,175,55,0.2)",
                    color: "rgba(229,231,235,0.9)", outline: "none",
                    boxSizing: "border-box"
                  }}
                />
                {repoError && (
                  <span style={{ fontSize: 11, color: "rgba(239,68,68,0.8)" }}>
                    {repoError}
                  </span>
                )}
                {repoSuccess && (
                  <span style={{ fontSize: 11, color: "rgba(212,175,55,0.8)" }}>
                    ✓ {repoSuccess}
                  </span>
                )}
                <button
                  onClick={handleRepoConnect}
                  disabled={!repoUrl.trim() || repoLoading}
                  style={{
                    padding: "10px 0", borderRadius: 10, fontSize: 12,
                    fontWeight: 700, cursor: "pointer",
                    background: "rgba(212,175,55,0.12)",
                    border: "1px solid rgba(212,175,55,0.3)",
                    color: "#D4AF37", transition: "all 150ms"
                  }}>
                  {repoLoading ? "Connecting..." : "Connect Repo"}
                </button>
              </div>
            )}

            {codebaseMode === "zip" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <button
                  onClick={() => zipInputRef.current?.click()}
                  disabled={zipLoading}
                  style={{
                    padding: "14px 0", borderRadius: 10, fontSize: 12,
                    fontWeight: 700, cursor: "pointer", transition: "all 150ms",
                    background: "rgba(212,175,55,0.06)",
                    border: "1px dashed rgba(212,175,55,0.3)",
                    color: "rgba(212,175,55,0.7)",
                  }}>
                  {zipLoading ? "Scanning..." : "📁 Tap to upload ZIP"}
                </button>
                {zipError && (
                  <span style={{ fontSize: 11, color: "rgba(239,68,68,0.8)" }}>
                    {zipError}
                  </span>
                )}
                {zipSuccess && (
                  <span style={{ fontSize: 11, color: "rgba(212,175,55,0.8)" }}>
                    ✓ {zipSuccess}
                  </span>
                )}
                <input
                  ref={zipInputRef}
                  type="file"
                  accept=".zip"
                  onChange={handleZipUpload}
                  style={{ display: "none" }}
                />
              </div>
            )}
          </div>

        </div>

        {/* Footer */}
        <div style={{
          padding: "12px 20px max(env(safe-area-inset-bottom), 16px)",
          borderTop: "1px solid rgba(212,175,55,0.1)",
          display: "flex", justifyContent: "center",
        }}>
          <button
            onClick={handleOpenVault}
            style={{
              background: "none", border: "none", cursor: "pointer",
              fontSize: 12, fontWeight: 700, color: "rgba(212,175,55,0.7)",
              letterSpacing: "0.04em",
              textDecoration: "underline", textDecorationColor: "rgba(212,175,55,0.3)",
            }}
          >
            Open Full Vault →
          </button>
        </div>
      </div>
    </>
  );
}
