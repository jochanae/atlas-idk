import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

type AuthMode = "signin" | "signup" | "forgot";

export function AuthScreen() {
  const [mode, setMode] = useState<AuthMode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [forgotSent, setForgotSent] = useState(false);

  const reset = () => {
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setError("");
    setForgotSent(false);
  };

  const handleSignIn = async () => {
    setError("");
    setLoading(true);
    const { error: err } = await supabase.auth.signInWithPassword({ email, password });
    if (err) setError(err.message);
    setLoading(false);
  };

  const handleSignUp = async () => {
    setError("");
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    const { error: err } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin },
    });
    if (err) setError(err.message);
    else setError("Check your email to confirm your account.");
    setLoading(false);
  };

  const handleForgotPassword = async () => {
    setError("");
    setLoading(true);
    const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (err) setError(err.message);
    else setForgotSent(true);
    setLoading(false);
  };

  const handleOAuth = async (provider: "google" | "apple") => {
    setError("");
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError(result.error.message || "OAuth sign in failed");
    }
    setLoading(false);
  };

  const inputStyle =
    "w-full px-4 py-3 rounded-lg bg-[#1a1714] text-[#e8dcc8] placeholder-[#6b5f50] outline-none transition-all duration-200 border";
  const inputBorder = "border-[rgba(212,175,55,0.2)] focus:border-[rgba(212,175,55,0.5)]";
  const goldBtn =
    "w-full py-3 rounded-lg font-semibold transition-all duration-200 border border-[rgba(212,175,55,0.5)] text-[#D4AF37] hover:bg-[rgba(212,175,55,0.1)] disabled:opacity-50";
  const oauthBtn =
    "w-full py-3 rounded-lg font-medium transition-all duration-200 border border-[rgba(212,175,55,0.3)] text-[#e8dcc8] hover:bg-[rgba(212,175,55,0.08)] flex items-center justify-center gap-3";

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" style={{ background: "#0D0B09" }}>
      {/* Purple ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 70% 60% at 50% 50%, rgba(128,90,213,0.15) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 w-full max-w-sm mx-auto px-6">
        {/* Logo */}
        <div className="text-center mb-8">
          <img
            src="/axiom-logo.svg"
            alt="Axiom"
            width={72}
            height={72}
            className="mx-auto mb-4"
            style={{ borderRadius: 16 }}
          />
          <h1
            className="text-3xl font-bold tracking-[0.3em] mb-2"
            style={{ color: "#D4AF37" }}
          >
            AXIOM
          </h1>
          <p className="text-xs tracking-widest" style={{ color: "#6b5f50" }}>
            The intelligence layer before the first line of code.
          </p>
        </div>

        {/* Card */}
        <div
          className="rounded-2xl p-6"
          style={{
            background: "rgba(26,23,20,0.8)",
            backdropFilter: "blur(16px)",
            border: "1px solid rgba(212,175,55,0.12)",
          }}
        >
          {mode === "forgot" ? (
            <>
              <h2 className="text-lg font-semibold mb-1" style={{ color: "#e8dcc8" }}>
                Reset Password
              </h2>
              <p className="text-xs mb-5" style={{ color: "#6b5f50" }}>
                Enter your email to receive a reset link.
              </p>
              {forgotSent ? (
                <div className="text-center py-4">
                  <p className="text-sm mb-4" style={{ color: "#D4AF37" }}>
                    Check your email for a reset link.
                  </p>
                  <button
                    onClick={() => { reset(); setMode("signin"); }}
                    className="text-xs underline"
                    style={{ color: "#6b5f50" }}
                  >
                    Back to sign in
                  </button>
                </div>
              ) : (
                <>
                  <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`${inputStyle} ${inputBorder} mb-4`}
                  />
                  {error && <p className="text-xs mb-3" style={{ color: "#e85d3a" }}>{error}</p>}
                  <button onClick={handleForgotPassword} disabled={loading} className={`${goldBtn} mb-3`}>
                    {loading ? "Sending…" : "Send Reset Link"}
                  </button>
                  <button
                    onClick={() => { reset(); setMode("signin"); }}
                    className="text-xs underline w-full text-center"
                    style={{ color: "#6b5f50" }}
                  >
                    Back to sign in
                  </button>
                </>
              )}
            </>
          ) : (
            <>
              <h2 className="text-lg font-semibold mb-5" style={{ color: "#e8dcc8" }}>
                {mode === "signin" ? "Sign In" : "Create Account"}
              </h2>

              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`${inputStyle} ${inputBorder} mb-3`}
              />

              <div className="relative mb-3">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`${inputStyle} ${inputBorder} pr-12`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs"
                  style={{ color: "#6b5f50" }}
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>

              {mode === "signup" && (
                <div className="relative mb-3">
                  <input
                    type={showConfirm ? "text" : "password"}
                    placeholder="Confirm Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`${inputStyle} ${inputBorder} pr-12`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs"
                    style={{ color: "#6b5f50" }}
                  >
                    {showConfirm ? "Hide" : "Show"}
                  </button>
                </div>
              )}

              {error && <p className="text-xs mb-3" style={{ color: "#e85d3a" }}>{error}</p>}

              <button
                onClick={mode === "signin" ? handleSignIn : handleSignUp}
                disabled={loading}
                className={`${goldBtn} mb-4`}
              >
                {loading ? "…" : mode === "signin" ? "Sign In" : "Create Account"}
              </button>

              {/* Divider */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 h-px" style={{ background: "rgba(212,175,55,0.15)" }} />
                <span className="text-[10px] tracking-wider" style={{ color: "#6b5f50" }}>OR</span>
                <div className="flex-1 h-px" style={{ background: "rgba(212,175,55,0.15)" }} />
              </div>

              {/* OAuth */}
              <button onClick={() => handleOAuth("google")} disabled={loading} className={`${oauthBtn} mb-3`}>
                <GoogleIcon />
                Continue with Google
              </button>
              <button onClick={() => handleOAuth("apple")} disabled={loading} className={`${oauthBtn} mb-4`}>
                <AppleIcon />
                Continue with Apple
              </button>

              {/* Links */}
              <div className="text-center space-y-2">
                {mode === "signin" && (
                  <button
                    onClick={() => { reset(); setMode("forgot"); }}
                    className="text-xs block w-full"
                    style={{ color: "#6b5f50" }}
                  >
                    Forgot password?
                  </button>
                )}
                <button
                  onClick={() => { reset(); setMode(mode === "signin" ? "signup" : "signin"); }}
                  className="text-xs"
                  style={{ color: "#6b5f50" }}
                >
                  {mode === "signin" ? "Don't have an account? " : "Already have an account? "}
                  <span style={{ color: "#D4AF37" }}>
                    {mode === "signin" ? "Sign up" : "Sign in"}
                  </span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
    </svg>
  );
}
