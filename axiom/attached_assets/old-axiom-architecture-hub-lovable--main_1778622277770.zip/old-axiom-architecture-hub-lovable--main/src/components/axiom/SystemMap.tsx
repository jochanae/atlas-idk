import { useAxiom, type ArchNode, type NodeKind } from "@/hooks/use-axiom-store";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "sonner";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";

// ─── Signal system (visual intelligence) ─────────────────────────────────────
// Gold pulse  = MUST (locked priority, rhythmic)
// Ember glow  = BLOCKER (jagged, static, friction)
// Amber pulse = needs attention (kind set but no strategicAnswer)
// Gold strong = GOAL anchor
// Ember bord  = conflict with decision ledger

const SIGNAL_KEYFRAMES = `
@keyframes edge-flow {
  from { stroke-dashoffset: 0; }
  to   { stroke-dashoffset: -20; }
}
@keyframes axiom-gold-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(212,175,55,0.55), 0 0 18px rgba(212,175,55,0.18); }
  50%      { box-shadow: 0 0 0 8px rgba(212,175,55,0.00), 0 0 28px rgba(212,175,55,0.42); }
}
@keyframes axiom-amber-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(245,158,11,0.45); border-color: rgba(245,158,11,0.55); }
  50%      { box-shadow: 0 0 0 6px rgba(245,158,11,0.00); border-color: rgba(245,158,11,0.95); }
}
@keyframes axiom-ember-static {
  0%   { box-shadow: 0 0 14px 2px rgba(220,53,69,0.55), inset 0 0 6px rgba(220,53,69,0.4); }
  20%  { box-shadow: 0 0 10px 1px rgba(220,53,69,0.35), inset 0 0 4px rgba(220,53,69,0.3); }
  40%  { box-shadow: 0 0 18px 3px rgba(220,53,69,0.65), inset 0 0 8px rgba(220,53,69,0.5); }
  60%  { box-shadow: 0 0 8px  1px rgba(220,53,69,0.30), inset 0 0 3px rgba(220,53,69,0.25); }
  80%  { box-shadow: 0 0 16px 2px rgba(220,53,69,0.60), inset 0 0 7px rgba(220,53,69,0.45); }
  100% { box-shadow: 0 0 12px 2px rgba(220,53,69,0.50), inset 0 0 5px rgba(220,53,69,0.35); }
}
@keyframes axiom-fly-in {
  0%   { opacity: 0; transform: scale(0.3) translate(var(--fly-from-x, 0px), var(--fly-from-y, 0px)); }
  60%  { opacity: 1; transform: scale(1.08) translate(0, 0); }
  100% { opacity: 1; transform: scale(1) translate(0, 0); }
}
@keyframes axiom-conflict-border {
  0%, 100% { border-color: rgba(220,53,69,0.85); }
  50%      { border-color: rgba(255,99,99,1); }
}
`;

const KIND_GLYPH: Record<NodeKind, string> = {
  GOAL: "★",
  MUST: "●",
  SHOULD: "◆",
  COULD: "◇",
  WONT: "✕",
  BLOCKER: "▲",
};

const LEGACY_GLYPH: Record<string, string> = {
  database: "⬡", api: "◈", auth: "◉", state: "◆", logic: "△", ui: "□", decision: "◎",
};

const ZOOM_MIN = 0.5;
const ZOOM_MAX = 2;
const ZOOM_DEFAULT_MOBILE = 0.85;
const ZOOM_DEFAULT_DESKTOP = 1;
const TAP_THRESHOLD = 8;
const CANVAS_PADDING = 80;

/** Has this node been "born" recently enough to deserve fly-in animation? */
function isNewlyBorn(node: ArchNode) {
  return node.bornAt != null && Date.now() - node.bornAt < 1500;
}

/** Decide which signal animation a node should use. */
function nodeSignalClass(node: ArchNode): string {
  if (node.conflictWith && node.conflictWith.length > 0) return "axiom-conflict";
  if (node.kind === "BLOCKER") return "axiom-ember";
  if (node.kind && !node.strategicAnswer && !node.resolved) return "axiom-amber";
  if (node.resolved && (node.kind === "MUST" || node.kind === "GOAL")) return "axiom-gold";
  if (node.kind === "GOAL") return "axiom-gold";
  return "";
}

export function SystemMap() {
  const {
    nodes, edges, detectedBuilder, setFocusedNodeId, atmosphere, addMessage,
    contradictions, decisionLedger, answerStrategicQuestion, resolveContradiction,
    activeGoalId, setActiveGoalId,
  } = useAxiom();
  const isMobile = useIsMobile();

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  const defaultZoom = isMobile ? ZOOM_DEFAULT_MOBILE : ZOOM_DEFAULT_DESKTOP;
  const [zoom, setZoom] = useState(defaultZoom);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [activeCardNodeId, setActiveCardNodeId] = useState<string | null>(null);
  const [answerDraft, setAnswerDraft] = useState("");

  const dragState = useRef({
    dragging: false, startX: 0, startY: 0, startPanX: 0, startPanY: 0,
    moved: false, lastTap: 0, lastNodeTapTime: 0,
    pinchStartDist: 0, pinchStartZoom: 1,
  });

  // ─── Fit map to container ─────────────────────────────────────────────────
  const fitMap = useCallback(() => {
    if (!containerRef.current || nodes.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const minX = Math.min(...nodes.map((n) => n.x)) - 40;
    const maxX = Math.max(...nodes.map((n) => n.x)) + 40;
    const minY = Math.min(...nodes.map((n) => n.y)) - 30;
    const maxY = Math.max(...nodes.map((n) => n.y)) + 60;
    const mapW = maxX - minX + CANVAS_PADDING * 2;
    const mapH = maxY - minY + CANVAS_PADDING * 2;
    const scaleX = rect.width / mapW;
    const scaleY = rect.height / mapH;
    const newZoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, Math.min(scaleX, scaleY)));
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    setZoom(newZoom);
    setPan({
      x: rect.width / 2 / newZoom - centerX,
      y: rect.height / 2 / newZoom - centerY,
    });
  }, [nodes]);

  useEffect(() => {
    fitMap();
    const observer = new ResizeObserver(() => fitMap());
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [fitMap]);

  // Re-fit when new nodes spawn
  useEffect(() => {
    const newest = nodes.reduce((max, n) => (n.bornAt && n.bornAt > max ? n.bornAt : max), 0);
    if (newest > 0 && Date.now() - newest < 1500) {
      const t = setTimeout(fitMap, 800);
      return () => clearTimeout(t);
    }
  }, [nodes.length, fitMap, nodes]);

  const resetView = useCallback(() => {
    fitMap();
    toast("Map Reset", {
      duration: 1000,
      style: { color: "#D4AF37", background: "oklch(0.15 0.01 60)", border: "1px solid oklch(0.76 0.12 85 / 30%)" },
    });
  }, [fitMap]);

  // ─── Pan / zoom handlers (preserved from prior version) ───────────────────
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    const ds = dragState.current;
    ds.dragging = true; ds.startX = e.clientX; ds.startY = e.clientY;
    ds.startPanX = pan.x; ds.startPanY = pan.y; ds.moved = false;
  }, [pan]);
  const onMouseMove = useCallback((e: React.MouseEvent) => {
    const ds = dragState.current;
    if (!ds.dragging) return;
    const dx = e.clientX - ds.startX; const dy = e.clientY - ds.startY;
    if (Math.abs(dx) > TAP_THRESHOLD || Math.abs(dy) > TAP_THRESHOLD) ds.moved = true;
    setPan({ x: ds.startPanX + dx / zoom, y: ds.startPanY + dy / zoom });
  }, [zoom]);
  const onMouseUp = useCallback(() => { dragState.current.dragging = false; }, []);
  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    setZoom((z) => Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, z - e.deltaY * 0.001)));
  }, []);
  const onDoubleClick = useCallback(() => resetView(), [resetView]);
  const onContainerClick = useCallback(() => {
    if (!dragState.current.moved && Date.now() - dragState.current.lastNodeTapTime > 150) {
      setActiveCardNodeId(null);
    }
  }, []);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    const ds = dragState.current;
    if (e.touches.length === 1) {
      ds.dragging = true; ds.startX = e.touches[0].clientX; ds.startY = e.touches[0].clientY;
      ds.startPanX = pan.x; ds.startPanY = pan.y; ds.moved = false;
    } else if (e.touches.length === 2) {
      ds.dragging = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      ds.pinchStartDist = Math.hypot(dx, dy); ds.pinchStartZoom = zoom;
    }
  }, [pan, zoom]);
  const onTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    const ds = dragState.current;
    if (e.touches.length === 1 && ds.dragging) {
      const dx = e.touches[0].clientX - ds.startX; const dy = e.touches[0].clientY - ds.startY;
      if (Math.abs(dx) > TAP_THRESHOLD || Math.abs(dy) > TAP_THRESHOLD) ds.moved = true;
      setPan({ x: ds.startPanX + dx / zoom, y: ds.startPanY + dy / zoom });
    } else if (e.touches.length === 2 && ds.pinchStartDist > 0) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      setZoom(Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, ds.pinchStartZoom * (dist / ds.pinchStartDist))));
    }
  }, [zoom]);
  const onTouchEnd = useCallback((e: React.TouchEvent) => {
    const ds = dragState.current;
    ds.dragging = false;
    if (e.changedTouches.length === 1 && !ds.moved) {
      const now = Date.now();
      if (now - ds.lastTap < 180) { resetView(); ds.lastTap = 0; } else { ds.lastTap = now; }
    }
  }, [resetView]);

  // ─── Tap a node: open the Intelligence Panel ──────────────────────────────
  const handleNodeTap = useCallback((nodeId: string, e: React.MouseEvent | React.TouchEvent) => {
    dragState.current.lastNodeTapTime = Date.now();
    dragState.current.dragging = false;
    if (dragState.current.moved) return;
    e.stopPropagation();
    setFocusedNodeId(nodeId);
    const node = nodes.find((n) => n.id === nodeId);
    if (!node) return;

    if (activeCardNodeId === nodeId) {
      setActiveCardNodeId(null);
      return;
    }
    haptics.tap(); sounds.tap();
    setActiveCardNodeId(nodeId);
    setAnswerDraft(node.strategicAnswer ?? "");

    // GOAL tap = re-anchor the radial layout
    if (node.kind === "GOAL") setActiveGoalId(nodeId);

    // Mirror the strategic question into the chat for context continuity
    if (node.strategicQuestion && !node.strategicAnswer) {
      addMessage({
        id: crypto.randomUUID(),
        role: "system",
        content: `🜸 ${node.label} — ${node.strategicQuestion}`,
        timestamp: Date.now(),
      });
    }
  }, [setFocusedNodeId, activeCardNodeId, nodes, addMessage, setActiveGoalId]);

  // ─── Decision Catch state ────────────────────────────────────────────────
  const unresolvedContradictions = useMemo(
    () => contradictions.filter((c) => !c.resolved),
    [contradictions]
  );
  const hasConflict = unresolvedContradictions.length > 0;
  const activeNode = activeCardNodeId ? nodes.find((n) => n.id === activeCardNodeId) ?? null : null;
  const activeNodeContradiction = activeNode
    ? unresolvedContradictions.find((c) => c.nodeId === activeNode.id) ?? null
    : null;
  const activeNodeConflictDecision = activeNodeContradiction
    ? decisionLedger.find((d) => d.id === activeNodeContradiction.decisionId) ?? null
    : null;

  const builderClass = detectedBuilder === "lovable" ? "pulse-lovable"
    : detectedBuilder === "cursor" ? "pulse-cursor"
    : detectedBuilder === "replit" ? "pulse-replit" : "";

  const strokeWidth = Math.max(1, Math.min(2, 1.5 / zoom));

  // ─── Card position ────────────────────────────────────────────────────────
  let cardLeft = 0; let cardTop = 0;
  const CARD_W = 280;
  if (activeNode) {
    const nodeScreenX = (activeNode.x + pan.x) * zoom;
    const nodeScreenY = (activeNode.y + pan.y) * zoom;
    cardLeft = nodeScreenX - CARD_W / 2;
    cardTop = nodeScreenY - 220;
    const containerW = containerRef.current?.offsetWidth ?? 600;
    cardLeft = Math.max(8, Math.min(cardLeft, containerW - CARD_W - 8));
    if (cardTop < 50) cardTop = nodeScreenY + 70;
  }

  // ─── Submit a strategic answer ───────────────────────────────────────────
  const submitAnswer = () => {
    if (!activeNode || !answerDraft.trim()) return;
    answerStrategicQuestion(activeNode.id, answerDraft.trim());
    haptics.cardConfirmed?.(); sounds.cardConfirmed?.();
    toast(`${activeNode.label} defined`, {
      duration: 1400,
      style: { color: "#D4AF37", background: "oklch(0.15 0.01 60)", border: "1px solid rgba(212,175,55,0.4)" },
    });
    setActiveCardNodeId(null);
  };

  return (
    <div
      ref={containerRef}
      className={`relative h-full w-full overflow-hidden rounded-lg system-map-glow ${builderClass}`}
      style={{
        transition: "box-shadow 1s ease",
        touchAction: "none",
        cursor: dragState.current.dragging ? "grabbing" : "grab",
        outline: hasConflict ? "1.5px solid rgba(220,53,69,0.7)" : "none",
        outlineOffset: -1,
      }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onWheel={onWheel}
      onDoubleClick={onDoubleClick}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onClick={onContainerClick}
    >
      <style>{SIGNAL_KEYFRAMES}</style>

      {/* Grid background */}
      <div className="absolute inset-0" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, oklch(0.30 0.01 60 / 30%) 1px, transparent 0)`,
        backgroundSize: "40px 40px",
      }} />

      {/* Header */}
      <div className="absolute left-4 top-4 z-10 flex flex-col gap-1.5">
        <span className="text-xs font-semibold text-gold">SYSTEM MAP</span>
        <div className="flex items-center gap-2">
          {detectedBuilder && (
            <span className="self-start rounded-full border border-gold/30 bg-obsidian-surface px-2 py-0.5 text-[10px] text-gold-muted">
              {detectedBuilder.toUpperCase()} DETECTED
            </span>
          )}
          {decisionLedger.filter((d) => d.status === "active").length > 0 && (
            <span className="rounded-full border border-gold/20 bg-obsidian-surface px-2 py-0.5 text-[10px] text-gold-muted">
              LEDGER · {decisionLedger.filter((d) => d.status === "active").length}
            </span>
          )}
          {hasConflict && (
            <span
              className="rounded-full px-2 py-0.5 text-[10px] font-semibold text-white"
              style={{ background: "rgba(220,53,69,0.85)", animation: "axiom-conflict-border 1.2s ease-in-out infinite" }}
            >
              CONFLICT · {unresolvedContradictions.length}
            </span>
          )}
        </div>
      </div>

      {/* Transformable canvas */}
      <div
        ref={canvasRef}
        style={{
          position: "absolute", top: 0, left: 0, width: "100%", height: "100%",
          transformOrigin: "0 0",
          transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)`,
        }}
      >
        {/* Edges */}
        <svg className="absolute inset-0 h-full w-full" style={{ overflow: "visible" }}>
          {edges.map((edge) => {
            const fromNode = nodes.find((n) => n.id === edge.from);
            const toNode = nodes.find((n) => n.id === edge.to);
            if (!fromNode || !toNode) return null;
            const bothResolved = fromNode.resolved && toNode.resolved;
            const isConflictEdge =
              (fromNode.conflictWith?.length ?? 0) > 0 || (toNode.conflictWith?.length ?? 0) > 0;
            const stroke = isConflictEdge
              ? "rgba(220,53,69,0.75)"
              : bothResolved
                ? "rgba(212,175,55,0.65)"
                : "oklch(0.35 0.01 60 / 50%)";
            return (
              <line
                key={edge.id}
                x1={fromNode.x} y1={fromNode.y} x2={toNode.x} y2={toNode.y}
                stroke={stroke}
                strokeWidth={strokeWidth}
                strokeDasharray={bothResolved ? "4 4" : "6 4"}
                style={bothResolved && !isConflictEdge ? { animation: "edge-flow 1.5s linear infinite" } : undefined}
              />
            );
          })}
        </svg>

        {/* Nodes */}
        {nodes.map((node) => (
          <NodeComponent
            key={node.id}
            node={node}
            isActiveGoal={node.id === activeGoalId}
            onTap={handleNodeTap}
            atmosphere={atmosphere}
          />
        ))}
      </div>

      {/* ─── Intelligence Panel (the strategic side-pane) ────────────────── */}
      {activeNode && (
        <div
          style={{
            position: "absolute",
            left: cardLeft, top: cardTop, width: CARD_W,
            zIndex: 50,
            background: "rgba(20, 18, 14, 0.97)",
            border: activeNodeContradiction
              ? "1.5px solid rgba(220,53,69,0.85)"
              : activeNode.kind === "BLOCKER"
                ? "1px solid rgba(220,53,69,0.5)"
                : "1px solid rgba(212, 175, 55, 0.4)",
            borderRadius: 12,
            padding: 14,
            boxShadow: activeNodeContradiction
              ? "0 0 24px rgba(220,53,69,0.45), 0 8px 24px rgba(0,0,0,0.6)"
              : "0 4px 24px rgba(0,0,0,0.6)",
            animation: activeNodeContradiction ? "axiom-conflict-border 1.2s ease-in-out infinite" : undefined,
            pointerEvents: "auto",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={(e) => { e.stopPropagation(); setActiveCardNodeId(null); }}
            style={{ position: "absolute", top: 6, right: 8, color: "#9ca3af", background: "none", border: "none", cursor: "pointer", fontSize: 14 }}
            aria-label="Close"
          >✕</button>

          {/* Header: kind chip + label */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, paddingRight: 24 }}>
            {activeNode.kind && (
              <span style={{
                fontSize: 9, fontWeight: 700, letterSpacing: "0.1em",
                padding: "2px 6px", borderRadius: 4,
                color: activeNode.kind === "BLOCKER" ? "#ff8585" : "#D4AF37",
                background: activeNode.kind === "BLOCKER" ? "rgba(220,53,69,0.15)" : "rgba(212,175,55,0.1)",
                border: `1px solid ${activeNode.kind === "BLOCKER" ? "rgba(220,53,69,0.4)" : "rgba(212,175,55,0.3)"}`,
              }}>{activeNode.kind}</span>
            )}
            <span style={{ fontSize: 13, fontWeight: 600, color: "#D4AF37" }}>{activeNode.label}</span>
          </div>

          {/* DECISION CATCH banner */}
          {activeNodeContradiction && activeNodeConflictDecision && (
            <div style={{
              background: "rgba(220,53,69,0.12)", border: "1px solid rgba(220,53,69,0.5)",
              borderRadius: 8, padding: 10, marginBottom: 10,
            }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#ff8585", letterSpacing: "0.08em", marginBottom: 4 }}>
                ⚠ DECISION CATCH
              </div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.85)", lineHeight: 1.5, marginBottom: 6 }}>
                You previously decided: <em style={{ color: "#D4AF37" }}>"{activeNodeConflictDecision.statement}"</em>
              </div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", lineHeight: 1.4, marginBottom: 8 }}>
                {activeNodeContradiction.reason}
              </div>
              <div style={{ fontSize: 11, color: "#ff8585", marginBottom: 8 }}>Which one is the truth?</div>
              <div style={{ display: "flex", gap: 6 }}>
                <button
                  onClick={() => resolveContradiction(activeNodeContradiction.id, "keep-decision")}
                  style={{ flex: 1, fontSize: 11, padding: "6px 8px", background: "rgba(212,175,55,0.15)", color: "#D4AF37", border: "1px solid rgba(212,175,55,0.4)", borderRadius: 6, cursor: "pointer" }}
                >Keep Decision</button>
                <button
                  onClick={() => resolveContradiction(activeNodeContradiction.id, "supersede-decision")}
                  style={{ flex: 1, fontSize: 11, padding: "6px 8px", background: "rgba(220,53,69,0.18)", color: "#ff8585", border: "1px solid rgba(220,53,69,0.5)", borderRadius: 6, cursor: "pointer" }}
                >Use This Node</button>
              </div>
            </div>
          )}

          {/* Strategic Question */}
          {activeNode.strategicQuestion && !activeNodeContradiction && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", color: "rgba(212,175,55,0.7)", marginBottom: 4 }}>
                STRATEGIC QUESTION
              </div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.88)", lineHeight: 1.5, fontStyle: "italic" }}>
                {activeNode.strategicQuestion}
              </div>
            </div>
          )}

          {/* Dead-end warning for under-defined MUSTs */}
          {activeNode.kind === "MUST" && !activeNode.strategicAnswer &&
            (activeNode.dependencies?.length ?? 0) === 0 &&
            !edges.some((e) => e.from === activeNode.id || e.to === activeNode.id) && (
              <div style={{
                fontSize: 10, color: "#F59E0B", padding: "6px 8px",
                background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.3)",
                borderRadius: 6, marginBottom: 10,
              }}>
                Dead end on the map. What's the very first step to move this?
              </div>
            )}

          {/* Answer input */}
          {!activeNodeContradiction && (
            <>
              <textarea
                value={answerDraft}
                onChange={(e) => setAnswerDraft(e.target.value)}
                placeholder={activeNode.strategicAnswer ? "Refine your answer..." : "Type your answer..."}
                rows={3}
                style={{
                  width: "100%", fontSize: 12, lineHeight: 1.5,
                  color: "rgba(255,255,255,0.9)", background: "rgba(13,11,9,0.8)",
                  border: "1px solid rgba(212,175,55,0.25)", borderRadius: 6,
                  padding: 8, outline: "none", resize: "vertical",
                }}
                onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submitAnswer(); }}
              />
              <button
                onClick={submitAnswer}
                disabled={!answerDraft.trim()}
                style={{
                  marginTop: 8, width: "100%", fontSize: 11, fontWeight: 600,
                  padding: "8px 10px", borderRadius: 6, cursor: answerDraft.trim() ? "pointer" : "not-allowed",
                  background: answerDraft.trim() ? "rgba(212,175,55,0.18)" : "rgba(212,175,55,0.06)",
                  color: answerDraft.trim() ? "#D4AF37" : "rgba(212,175,55,0.3)",
                  border: `1px solid ${answerDraft.trim() ? "rgba(212,175,55,0.5)" : "rgba(212,175,55,0.15)"}`,
                  letterSpacing: "0.04em",
                }}
              >Lock In Answer</button>
            </>
          )}

          {/* Existing answer if present */}
          {activeNode.strategicAnswer && !answerDraft && (
            <div style={{ fontSize: 11, color: "rgba(229,231,235,0.7)", marginTop: 8, paddingTop: 8, borderTop: "1px solid rgba(212,175,55,0.15)" }}>
              {activeNode.strategicAnswer}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Node renderer with full signal system ────────────────────────────────
function NodeComponent({
  node,
  isActiveGoal,
  onTap,
}: {
  node: ArchNode;
  isActiveGoal: boolean;
  onTap: (id: string, e: React.MouseEvent | React.TouchEvent) => void;
  atmosphere: string;
}) {
  const signal = nodeSignalClass(node);
  const isGoal = node.kind === "GOAL";
  const isBlocker = node.kind === "BLOCKER";
  const flyIn = isNewlyBorn(node);
  const size = isGoal ? 80 : 64;
  const glyph = node.kind ? KIND_GLYPH[node.kind] : LEGACY_GLYPH[node.type] ?? "●";

  // Signal animation styles
  const signalStyle: React.CSSProperties = {};
  if (signal === "axiom-gold") signalStyle.animation = "axiom-gold-pulse 2.6s ease-in-out infinite";
  else if (signal === "axiom-amber") signalStyle.animation = "axiom-amber-pulse 1.4s ease-in-out infinite";
  else if (signal === "axiom-ember") signalStyle.animation = "axiom-ember-static 0.6s steps(5, end) infinite";
  else if (signal === "axiom-conflict") signalStyle.animation = "axiom-ember-static 0.5s steps(5, end) infinite";

  // Border + colors by kind
  let borderColor = "rgba(212,175,55,0.4)";
  let textColor = "#D4AF37";
  let bgColor = "rgba(212,175,55,0.08)";
  if (isBlocker) {
    borderColor = "rgba(220,53,69,0.6)";
    textColor = "#ff8585";
    bgColor = "rgba(220,53,69,0.1)";
  } else if (signal === "axiom-amber") {
    borderColor = "rgba(245,158,11,0.55)";
    textColor = "#F59E0B";
    bgColor = "rgba(245,158,11,0.06)";
  } else if (signal === "axiom-conflict") {
    borderColor = "rgba(220,53,69,0.85)";
    textColor = "#ff8585";
    bgColor = "rgba(220,53,69,0.12)";
  }
  if (isActiveGoal) {
    borderColor = "rgba(212,175,55,0.95)";
    bgColor = "rgba(212,175,55,0.18)";
  }

  return (
    <button
      onClick={(e) => onTap(node.id, e)}
      onTouchEnd={(e) => { e.preventDefault(); onTap(node.id, e); }}
      className="absolute flex flex-col items-center gap-1 transition-all duration-300"
      style={{
        left: node.x - size / 2,
        top: node.y - size / 2 + 8,
        animation: flyIn ? "axiom-fly-in 600ms cubic-bezier(0.34, 1.56, 0.64, 1)" : undefined,
      }}
    >
      <div
        style={{
          width: size, height: size,
          display: "flex", alignItems: "center", justifyContent: "center",
          borderRadius: isGoal ? 16 : 14,
          border: `${isGoal ? 2 : 1.5}px solid ${borderColor}`,
          background: bgColor,
          color: textColor,
          fontSize: isGoal ? 26 : 20,
          fontWeight: 600,
          ...signalStyle,
        }}
      >
        {glyph}
      </div>
      <span style={{
        fontSize: isGoal ? 11 : 10, fontWeight: isGoal ? 700 : 500,
        whiteSpace: "nowrap",
        color: textColor,
        maxWidth: 120, overflow: "hidden", textOverflow: "ellipsis",
      }}>
        {node.label}
      </span>
      {node.kind && node.strategicAnswer && (
        <span style={{ fontSize: 8, color: "rgba(212,175,55,0.6)", letterSpacing: "0.08em" }}>DEFINED</span>
      )}
    </button>
  );
}
