import { useState } from "react";
import { StripeEmbeddedCheckout } from "@/components/StripeEmbeddedCheckout";
import { supabase } from "@/integrations/supabase/client";

const FEATURES = [
  "Unlimited AI sessions",
  "Full Vault access",
  "Project Profiles",
  "Codebase intake (GitHub + ZIP)",
  "MoSCoW Sprint Plans",
  "Atlas handoff",
  "Priority support",
];

interface UpgradeModalProps {
  open: boolean;
  onClose: () => void;
  message?: string;
}

export function UpgradeModal({ open, onClose, message }: UpgradeModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<"pro_annual" | "pro_monthly">("pro_annual");
  const [showCheckout, setShowCheckout] = useState(false);
  const [userInfo, setUserInfo] = useState<{ email?: string; id?: string }>({});

  const handleUpgrade = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUserInfo({ email: user?.email || undefined, id: user?.id || undefined });
    setShowCheckout(true);
  };

  if (!open) return null;

  if (showCheckout) {
    return (
      <>
        <div onClick={() => { setShowCheckout(false); onClose(); }}
          style={{
            position: "fixed", inset: 0, zIndex: 10500,
            background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)",
          }} />
        <div style={{
          position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10501,
          height: "90dvh", background: "#0D0B09",
          borderRadius: "18px 18px 0 0",
          borderTop: "1px solid rgba(212,175,55,0.3)",
          display: "flex", flexDirection: "column",
          overflow: "hidden",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 20px", borderBottom: "1px solid rgba(212,175,55,0.1)" }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.1em" }}>SECURE CHECKOUT</span>
            <button onClick={() => { setShowCheckout(false); onClose(); }}
              style={{ background: "none", border: "none", color: "rgba(156,163,175,0.6)", fontSize: 18, cursor: "pointer" }}>✕</button>
          </div>
          <div style={{ flex: 1, overflow: "auto", padding: "0" }}>
            <StripeEmbeddedCheckout
              priceId={selectedPlan}
              customerEmail={userInfo.email}
              userId={userInfo.id}
              returnUrl={`${window.location.origin}/pricing?checkout=success&session_id={CHECKOUT_SESSION_ID}`}
            />
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      {/* Backdrop */}
      <div onClick={onClose}
        style={{
          position: "fixed", inset: 0, zIndex: 10500,
          background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)",
          WebkitBackdropFilter: "blur(6px)",
        }} />

      {/* Modal */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10501,
        maxHeight: "88dvh", background: "#0D0B09",
        borderRadius: "18px 18px 0 0",
        borderTop: "1px solid rgba(212,175,55,0.4)",
        display: "flex", flexDirection: "column",
        boxShadow: "0 -12px 60px rgba(212,175,55,0.08), 0 -4px 24px rgba(0,0,0,0.6)",
        animation: "slideUp 300ms ease-out",
      }}>
        {/* Handle + close */}
        <div style={{ display: "flex", justifyContent: "center", padding: "10px 0 4px", position: "relative" }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: "rgba(212,175,55,0.3)" }} />
          <button onClick={onClose}
            style={{
              position: "absolute", right: 16, top: 8,
              background: "none", border: "none", cursor: "pointer",
              color: "rgba(156,163,175,0.55)", fontSize: 18, width: 32, height: 32,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>✕</button>
        </div>

        {/* Scrollable content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "8px 24px 32px" }}>
          {/* Header */}
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#D4AF37", letterSpacing: "0.15em", marginBottom: 6 }}>
              AXIOM PRO
            </div>
            <div style={{ fontSize: 13, color: "rgba(156,163,175,0.7)", fontWeight: 400 }}>
              Unlimited sessions. Every feature. No limits.
            </div>
          </div>

          {/* Context message */}
          {message && (
            <div style={{
              padding: "10px 14px", marginBottom: 16, borderRadius: 10,
              background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.2)",
              fontSize: 12, color: "rgba(212,175,55,0.85)", textAlign: "center",
            }}>
              {message}
            </div>
          )}

          {/* Features */}
          <div style={{ marginBottom: 20 }}>
            {FEATURES.map(f => (
              <div key={f} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0" }}>
                <span style={{ color: "#D4AF37", fontSize: 10 }}>◆</span>
                <span style={{ fontSize: 12, color: "rgba(255,255,255,0.8)" }}>{f}</span>
              </div>
            ))}
          </div>

          {/* Plan cards */}
          <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
            {/* Monthly */}
            <button onClick={() => setSelectedPlan("pro_monthly")}
              style={{
                flex: 1, padding: "16px 12px", borderRadius: 12, cursor: "pointer",
                background: selectedPlan === "pro_monthly" ? "rgba(212,175,55,0.08)" : "transparent",
                border: `1.5px solid ${selectedPlan === "pro_monthly" ? "#D4AF37" : "rgba(212,175,55,0.2)"}`,
                transition: "all 200ms", textAlign: "center",
              }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "rgba(156,163,175,0.6)", letterSpacing: "0.08em", marginBottom: 6 }}>MONTHLY</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: selectedPlan === "pro_monthly" ? "#D4AF37" : "rgba(255,255,255,0.8)" }}>
                $19<span style={{ fontSize: 12, fontWeight: 400 }}>/mo</span>
              </div>
            </button>

            {/* Annual */}
            <button onClick={() => setSelectedPlan("pro_annual")}
              style={{
                flex: 1, padding: "16px 12px", borderRadius: 12, cursor: "pointer",
                background: selectedPlan === "pro_annual" ? "rgba(212,175,55,0.08)" : "transparent",
                border: `1.5px solid ${selectedPlan === "pro_annual" ? "#D4AF37" : "rgba(212,175,55,0.2)"}`,
                transition: "all 200ms", textAlign: "center", position: "relative",
              }}>
              {/* Save badge */}
              <div style={{
                position: "absolute", top: -8, right: 8,
                background: "#D4AF37", color: "#0D0B09",
                fontSize: 9, fontWeight: 800, padding: "2px 7px",
                borderRadius: 6, letterSpacing: "0.02em",
              }}>Save $38</div>
              <div style={{ fontSize: 10, fontWeight: 700, color: "rgba(156,163,175,0.6)", letterSpacing: "0.08em", marginBottom: 6 }}>ANNUAL</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: selectedPlan === "pro_annual" ? "#D4AF37" : "rgba(255,255,255,0.8)" }}>
                $190<span style={{ fontSize: 12, fontWeight: 400 }}>/yr</span>
              </div>
              <div style={{ fontSize: 10, color: "rgba(156,163,175,0.5)", marginTop: 3 }}>$15.83/month</div>
            </button>
          </div>

          {/* CTA */}
          <button onClick={handleUpgrade}
            style={{
              width: "100%", padding: "14px", borderRadius: 12,
              background: "#D4AF37", border: "none",
              fontSize: 14, fontWeight: 800, color: "#0D0B09",
              cursor: "pointer", letterSpacing: "0.04em",
              boxShadow: "0 4px 20px rgba(212,175,55,0.3)",
              transition: "transform 100ms, box-shadow 100ms",
            }}
            onMouseDown={e => (e.currentTarget.style.transform = "scale(0.98)")}
            onMouseUp={e => (e.currentTarget.style.transform = "scale(1)")}
          >
            Upgrade Now →
          </button>

          {/* Fine print */}
          <div style={{ textAlign: "center", marginTop: 12, fontSize: 10, color: "rgba(156,163,175,0.4)" }}>
            Secure payment via Stripe. Cancel anytime.
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
      `}</style>
    </>
  );
}
