import { useState, useRef, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUpgradeGate } from "@/hooks/use-upgrade-gate";
import { useSubscription } from "@/hooks/use-subscription";

const BUILDER_OPTIONS = [
  "Lovable", "Cursor", "Replit", "Bolt", "Windsurf",
  "v0 by Vercel", "Bubble", "FlutterFlow", "GitHub Copilot", "Other",
];

export interface ProjectProfile {
  id: string;
  name: string;
  builder: string;
  techStack: string;
  fileStructure: string;
  notes: string;
  lastUsed: number | null;
}

// ─── DB helpers (exported for use by ChatHook nudge, QuickPrompt, FolderPanel) ─

function rowToProfile(row: any): ProjectProfile {
  return {
    id: row.id,
    name: row.name,
    builder: row.builder || "",
    techStack: row.tech_stack || "",
    fileStructure: row.file_structure || "",
    notes: row.notes || "",
    lastUsed: row.last_used ? new Date(row.last_used).getTime() : null,
  };
}

export async function loadProfilesAsync(): Promise<ProjectProfile[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data, error } = await supabase
    .from("projects")
    .select("*")
    .eq("user_id", user.id)
    .order("updated_at", { ascending: false });
  if (error || !data) return [];
  return data.map(rowToProfile);
}

/** @deprecated — use loadProfilesAsync instead. Kept for sync fallback. */
export function loadProfiles(): ProjectProfile[] {
  // Fallback: return empty — callers should migrate to async
  return [];
}

export async function markProfileUsed(id: string) {
  await supabase
    .from("projects")
    .update({ last_used: new Date().toISOString() })
    .eq("id", id);
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function ProfileBuilderDropdown({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        style={{
          width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
          background: "#0D0B09", border: `1px solid ${open || value ? "rgba(212,175,55,0.5)" : "rgba(212,175,55,0.25)"}`,
          borderRadius: 8, padding: "9px 12px", cursor: "pointer", boxSizing: "border-box",
        }}
      >
        <span style={{ fontSize: 13, color: value ? "rgba(255,255,255,0.87)" : "rgba(255,255,255,0.35)" }}>
          {value || "Select builder..."}
        </span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#D4AF37" strokeWidth="2.5"
          strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: open ? "rotate(180deg)" : "rotate(0)", transition: "transform 180ms" }}>
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 10100,
          background: "#0D0B09", border: "1px solid rgba(212,175,55,0.3)", borderRadius: 8,
          boxShadow: "0 8px 24px rgba(0,0,0,0.7)", maxHeight: 200, overflowY: "auto",
        }}>
          {BUILDER_OPTIONS.map(b => (
            <button key={b} type="button"
              onClick={() => { onChange(b); setOpen(false); }}
              style={{
                width: "100%", display: "flex", alignItems: "center", gap: 8,
                padding: "9px 12px",
                background: b === value ? "rgba(212,175,55,0.12)" : "transparent",
                border: "none", cursor: "pointer", textAlign: "left",
              }}
              onMouseEnter={e => { if (b !== value) (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.04)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = b === value ? "rgba(212,175,55,0.12)" : "transparent"; }}
            >
              <span style={{ fontSize: 13, color: b === value ? "#D4AF37" : "rgba(255,255,255,0.87)", fontWeight: b === value ? 600 : 400 }}>
                {b}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const EMPTY_FORM = { name: "", builder: "", techStack: "", fileStructure: "", notes: "" };

export function ProjectProfiles() {
  const [profiles, setProfiles] = useState<ProjectProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const { openUpgrade } = useUpgradeGate();
  const { status: subStatus } = useSubscription();

  const fetchProfiles = useCallback(async () => {
    setLoading(true);
    const p = await loadProfilesAsync();
    setProfiles(p);
    setLoading(false);
  }, []);

  useEffect(() => { fetchProfiles(); }, [fetchProfiles]);

  const openAdd = () => {
    if (subStatus === "free") {
      openUpgrade("Project Profiles require Pro");
      return;
    }
    setForm({ ...EMPTY_FORM });
    setEditId(null);
    setShowForm(true);
  };

  const openEdit = (p: ProjectProfile) => {
    setForm({ name: p.name, builder: p.builder, techStack: p.techStack, fileStructure: p.fileStructure, notes: p.notes });
    setEditId(p.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || saving) return;
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      if (editId) {
        await supabase.from("projects").update({
          name: form.name.trim(),
          builder: form.builder || null,
          tech_stack: form.techStack,
          file_structure: form.fileStructure,
          notes: form.notes,
        }).eq("id", editId);
      } else {
        await supabase.from("projects").insert({
          name: form.name.trim(),
          builder: form.builder || null,
          tech_stack: form.techStack,
          file_structure: form.fileStructure,
          notes: form.notes,
          user_id: user.id,
        });
      }
      await fetchProfiles();
      setShowForm(false);
      setEditId(null);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    await supabase.from("projects").delete().eq("id", id);
    setConfirmDeleteId(null);
    await fetchProfiles();
  };

  const fieldStyle: React.CSSProperties = {
    width: "100%", background: "#0D0B09",
    border: "1px solid rgba(212,175,55,0.25)", borderRadius: 8,
    padding: "9px 12px", fontSize: 13, color: "rgba(255,255,255,0.87)",
    outline: "none", boxSizing: "border-box", fontFamily: "inherit",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 10, fontWeight: 700, color: "rgba(212,175,55,0.7)",
    letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 5,
  };

  if (showForm) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 2 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.08em", textTransform: "uppercase" }}>
            {editId ? "Edit Profile" : "New Profile"}
          </span>
          <button onClick={() => { setShowForm(false); setEditId(null); }}
            style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(156,163,175,0.65)", fontSize: 12 }}>
            Cancel
          </button>
        </div>

        <div>
          <label style={labelStyle}>Project Name *</label>
          <input type="text" value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="e.g. Atlas, CoinsBloom"
            style={fieldStyle} />
        </div>

        <div>
          <label style={labelStyle}>Builder</label>
          <ProfileBuilderDropdown value={form.builder} onChange={v => setForm(f => ({ ...f, builder: v }))} />
        </div>

        <div>
          <label style={labelStyle}>Tech Stack</label>
          <textarea value={form.techStack}
            onChange={e => setForm(f => ({ ...f, techStack: e.target.value }))}
            placeholder="React + Vite, TailwindCSS, Express backend, Postgres + Drizzle ORM"
            rows={3} style={{ ...fieldStyle, resize: "none" }} />
        </div>

        <div>
          <label style={labelStyle}>File Structure</label>
          <textarea value={form.fileStructure}
            onChange={e => setForm(f => ({ ...f, fileStructure: e.target.value }))}
            placeholder={"- Frontend: artifacts/atlas/src/components/\n- Backend: artifacts/api-server/src/routes/\n- DB: lib/db/"}
            rows={3} style={{ ...fieldStyle, resize: "none" }} />
        </div>

        <div>
          <label style={labelStyle}>
            Notes{" "}
            <span style={{ fontWeight: 400, textTransform: "none", fontSize: 10, color: "rgba(156,163,175,0.45)" }}>
              (optional)
            </span>
          </label>
          <textarea value={form.notes}
            onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            placeholder="Any additional context Axiom should always know about this project..."
            rows={2} style={{ ...fieldStyle, resize: "none" }} />
        </div>

        <button onClick={handleSave} disabled={!form.name.trim() || saving}
          style={{
            width: "100%", background: "#D4AF37", border: "none", borderRadius: 10,
            padding: "12px", fontSize: 13, fontWeight: 700, color: "#0D0B09",
            cursor: form.name.trim() && !saving ? "pointer" : "not-allowed",
            opacity: form.name.trim() && !saving ? 1 : 0.4,
          }}>
          {saving ? "Saving..." : "Save Profile"}
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={{ textAlign: "center", padding: "24px 0", color: "rgba(156,163,175,0.4)", fontSize: 12 }}>
        Loading profiles...
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <span style={{ fontSize: 11, color: "rgba(156,163,175,0.55)" }}>
          {profiles.length === 0 ? "No projects saved yet." : `${profiles.length} profile${profiles.length !== 1 ? "s" : ""} saved`}
        </span>
        <button onClick={openAdd}
          style={{
            display: "flex", alignItems: "center", justifyContent: "center",
            width: 28, height: 28, borderRadius: "50%",
            background: "rgba(212,175,55,0.1)", border: "1px solid rgba(212,175,55,0.4)",
            color: "#D4AF37", fontSize: 18, fontWeight: 700, cursor: "pointer",
          }}>
          +
        </button>
      </div>

      {profiles.length === 0 && (
        <div style={{ textAlign: "center", padding: "16px 0", color: "rgba(156,163,175,0.4)", fontSize: 12 }}>
          Tap + to add your first project profile.
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {profiles.map(p => (
          <div key={p.id} style={{
            background: "#0D0B09", border: "1px solid rgba(212,175,55,0.22)",
            borderRadius: 10, padding: "12px 14px",
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 3 }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.9)" }}>{p.name}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0, marginLeft: 8 }}>
                <button onClick={() => openEdit(p)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#D4AF37", fontSize: 12, fontWeight: 600 }}>
                  Edit
                </button>
                {confirmDeleteId === p.id ? (
                  <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                    <button onClick={() => handleDelete(p.id)}
                      style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(239,68,68,0.8)", fontSize: 11, fontWeight: 700 }}>
                      Delete
                    </button>
                    <button onClick={() => setConfirmDeleteId(null)}
                      style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(156,163,175,0.5)", fontSize: 11 }}>
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button onClick={() => setConfirmDeleteId(p.id)}
                    style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(156,163,175,0.45)", fontSize: 14 }}>
                    ✕
                  </button>
                )}
              </div>
            </div>
            <div style={{ fontSize: 11, color: "rgba(156,163,175,0.65)", marginBottom: p.lastUsed ? 3 : 0 }}>
              {[p.builder, p.techStack ? p.techStack.split(",")[0].trim() : ""].filter(Boolean).join(" · ")}
            </div>
            {p.lastUsed && (
              <div style={{ fontSize: 10, color: "rgba(156,163,175,0.38)" }}>
                Last used: {timeAgo(p.lastUsed)}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
