import { useState, useEffect, useRef } from "react";
import { useAxiom } from "@/hooks/use-axiom-store";
import { supabase } from "@/integrations/supabase/client";

export function GoldContainer() {
  const { nodes, edges, readinessScore, detectedBuilder, messages } = useAxiom();
  const [copied, setCopied] = useState(false);

  const dbTables = nodes.filter((n) => n.type === "database").length;
  const apiRoutes = nodes.filter((n) => n.type === "api").length;
  const logicBlocks = nodes.filter((n) => n.type === "logic").length;
  const resolvedCount = nodes.filter((n) => n.resolved).length;
  const aiScore = Math.round((resolvedCount / Math.max(nodes.length, 1)) * 100);
  const complexity = readinessScore > 80 ? "Standard" : readinessScore > 50 ? "Moderate" : "Complex";

  const stats = [
    { label: "Database Tables", value: dbTables },
    { label: "API Routes", value: apiRoutes },
    { label: "Logic Blocks", value: logicBlocks },
    { label: "AI Compatibility", value: `${aiScore}%` },
    { label: "Complexity", value: complexity },
    { label: "Builder", value: detectedBuilder?.toUpperCase() || "Undetected" },
  ];

  const generateMoscow = () => {
    const resolved = nodes.filter(n => n.resolved);
    const unresolved = nodes.filter(n => !n.resolved);

    const mustHave = resolved
      .filter(n => ["auth", "db"].includes(n.id))
      .map(n => n.label);
    if (mustHave.length === 0) mustHave.push("Core authentication layer", "Primary database schema");

    const shouldHave = resolved
      .filter(n => ["api", "logic"].includes(n.id))
      .map(n => n.label);
    if (shouldHave.length === 0) shouldHave.push("API routes", "Business logic layer");

    const couldHave = resolved
      .filter(n => ["ui", "state"].includes(n.id))
      .map(n => n.label);
    if (couldHave.length === 0) couldHave.push("UI polish", "State optimization");

    const wontHave = unresolved.map(n => `${n.label} (deferred)`);
    if (wontHave.length === 0) wontHave.push("Advanced analytics (v2)", "Team collaboration (v2)");

    return { mustHave, shouldHave, couldHave, wontHave };
  };

  const moscow = generateMoscow();

  const MOSCOW_LANES = [
    {
      key: "M",
      label: "Must Have",
      sublabel: "Launch-critical",
      items: moscow.mustHave,
      color: "#D4AF37",
      bg: "rgba(212,175,55,0.08)",
      border: "rgba(212,175,55,0.3)",
    },
    {
      key: "S",
      label: "Should Have",
      sublabel: "Important, not blocking",
      items: moscow.shouldHave,
      color: "rgba(212,175,55,0.7)",
      bg: "rgba(212,175,55,0.05)",
      border: "rgba(212,175,55,0.2)",
    },
    {
      key: "C",
      label: "Could Have",
      sublabel: "Nice to have",
      items: moscow.couldHave,
      color: "rgba(156,163,175,0.7)",
      bg: "rgba(156,163,175,0.04)",
      border: "rgba(156,163,175,0.15)",
    },
    {
      key: "W",
      label: "Won't Have",
      sublabel: "This version — parked",
      items: moscow.wontHave,
      color: "rgba(156,163,175,0.4)",
      bg: "transparent",
      border: "rgba(156,163,175,0.1)",
    },
  ];

  const generateManifest = () => {
    const resolvedNodes = nodes.filter((n) => n.resolved);
    const unresolvedNodes = nodes.filter((n) => !n.resolved);
    const userMessages = messages.filter((m) => m.role === "user").map((m) => m.content);

    const manifest = [
      "╔══════════════════════════════════════════════╗",
      "║           AXIOM — GOLD CONTAINER             ║",
      "║         Technical Specification Manifest      ║",
      "╚══════════════════════════════════════════════╝",
      "",
      `Generated: ${new Date().toISOString()}`,
      `Builder Target: ${detectedBuilder?.toUpperCase() || "UNDETECTED"}`,
      `Readiness Score: ${readinessScore}%`,
      `AI Compatibility: ${aiScore}%`,
      `Complexity: ${complexity}`,
      "",
      "── ARCHITECTURE OVERVIEW ──",
      `Total Nodes: ${nodes.length}`,
      `Resolved: ${resolvedCount} | Unresolved: ${unresolvedNodes.length}`,
      `Database Tables: ${dbTables}`,
      `API Routes: ${apiRoutes}`,
      `Logic Blocks: ${logicBlocks}`,
      "",
      "── RESOLVED NODES ──",
      ...resolvedNodes.map((n) => `  ✓ [${n.type.toUpperCase()}] ${n.label}${n.details ? ` — ${n.details}` : ""}`),
      "",
      "── UNRESOLVED NODES ──",
      ...unresolvedNodes.map((n) => `  ○ [${n.type.toUpperCase()}] ${n.label}`),
      "",
      "── CONNECTIONS ──",
      ...edges.map((e) => {
        const from = nodes.find((n) => n.id === e.from);
        const to = nodes.find((n) => n.id === e.to);
        return `  ${from?.label || e.from} → ${to?.label || e.to}`;
      }),
      "",
      "── CONVERSATION LOG ──",
      ...userMessages.map((m, i) => `  ${i + 1}. ${m}`),
      "",
      "── MOSCOW SPRINT PLAN ──",
      "M — MUST HAVE (launch-critical):",
      ...moscow.mustHave.map(i => `  ◆ ${i}`),
      "",
      "S — SHOULD HAVE (important, not blocking):",
      ...moscow.shouldHave.map(i => `  ◆ ${i}`),
      "",
      "C — COULD HAVE (nice to have):",
      ...moscow.couldHave.map(i => `  ◆ ${i}`),
      "",
      "W — WON'T HAVE (this version):",
      ...moscow.wontHave.map(i => `  ◆ ${i}`),
      "",
      "── END MANIFEST ──",
      "Built by Into Innovations. Axiom → Atlas → GitHub.",
    ];

    return manifest.join("\n");
  };

  const handleCopy = async () => {
    const manifest = generateManifest();
    try {
      await navigator.clipboard.writeText(manifest);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = manifest;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="mx-auto max-w-2xl p-6">
      {readinessScore < 60 && (
        <div className="mb-4 rounded-lg border border-amber-glow/40 bg-amber-glow/5 px-4 py-2.5 text-xs text-amber-glow">
          ⚠ Architecture is below 60% readiness. Spec may be incomplete.
        </div>
      )}

      <div className="rounded-2xl border-2 p-6"
        style={{
          borderImage: "linear-gradient(135deg, oklch(0.76 0.12 85), oklch(0.60 0.08 75)) 1",
          background: "oklch(0.15 0.01 60)",
        }}>
        <h2 className="mb-1 text-lg font-bold text-gold">Gold Container</h2>
        <p className="mb-6 text-xs text-silver-muted">Technical Manifest</p>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {stats.map((s) => (
            <div key={s.label} className="rounded-xl border border-gold/20 bg-obsidian-light p-3">
              <p className="text-[10px] font-medium text-silver-muted uppercase tracking-wider">{s.label}</p>
              <p className="mt-1 text-xl font-bold text-gold">{s.value}</p>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 24, marginBottom: 8 }}>
          <div style={{
            fontSize: 10, fontWeight: 700, letterSpacing: "0.12em",
            color: "rgba(212,175,55,0.6)", textTransform: "uppercase",
            marginBottom: 12,
          }}>
            MoSCoW Sprint Plan
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {MOSCOW_LANES.map(lane => (
              <div
                key={lane.key}
                style={{
                  borderRadius: 12,
                  border: `1px solid ${lane.border}`,
                  background: lane.bg,
                  padding: "10px 14px",
                }}
              >
                <div style={{
                  display: "flex", alignItems: "center",
                  gap: 8, marginBottom: 6,
                }}>
                  <span style={{
                    width: 22, height: 22, borderRadius: 6,
                    background: lane.bg,
                    border: `1px solid ${lane.border}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 800, color: lane.color,
                    flexShrink: 0,
                  }}>
                    {lane.key}
                  </span>
                  <div>
                    <span style={{ fontSize: 11, fontWeight: 700, color: lane.color }}>
                      {lane.label}
                    </span>
                    <span style={{ fontSize: 9, color: "rgba(156,163,175,0.4)", marginLeft: 6 }}>
                      {lane.sublabel}
                    </span>
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {lane.items.map((item, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 6 }}>
                      <span style={{ color: lane.color, fontSize: 9, marginTop: 2, flexShrink: 0 }}>◆</span>
                      <span style={{ fontSize: 11, color: "rgba(229,231,235,0.7)", lineHeight: 1.5 }}>
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleCopy}
          className={`mt-6 w-full rounded-xl py-3 text-sm font-bold transition-all ${
            copied
              ? "bg-gold/20 text-gold border border-gold/40"
              : "bg-gold text-gold-foreground hover:shadow-gold-intense"
          }`}
        >
          {copied ? "✓ Copied to Clipboard" : "Copy Spec to Clipboard"}
        </button>
      </div>
    </div>
  );
}

// Blueprint export modal — triggered from CockpitBar
export function BlueprintExportModal({ onClose }: { onClose: () => void }) {
  const { nodes, edges, readinessScore, detectedBuilder, messages } = useAxiom();
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const resolvedNodes = nodes.filter((n) => n.resolved);
  const dbTables = nodes.filter((n) => n.type === "database" && n.resolved).length;
  const apiRoutes = nodes.filter((n) => n.type === "api" && n.resolved).length;
  const logicBlocks = nodes.filter((n) => n.type === "logic" && n.resolved).length;
  const complexity = readinessScore > 80 ? "Standard" : readinessScore > 50 ? "Moderate" : "Complex";

  const stats = [
    { label: "Builder", value: detectedBuilder?.toUpperCase() || "Unspecified" },
    { label: "DB Tables", value: dbTables },
    { label: "API Routes", value: apiRoutes },
    { label: "Logic Blocks", value: logicBlocks },
    { label: "Readiness", value: `${readinessScore}%` },
    { label: "Complexity", value: complexity },
  ];

  // Find Master Initialization Prompt from last AI message containing key phrases
  const masterPromptMsg = [...messages].reverse().find(
    (m) => m.role === "system" && (
      m.content.toLowerCase().includes("golden specification") ||
      m.content.toLowerCase().includes("technical manifest") ||
      m.content.toLowerCase().includes("plumbing")
    )
  );
  const masterPrompt = masterPromptMsg?.content ||
    "Complete all three Sprints in Axiom to generate your Master Initialization Prompt.";

  const generateBlueprint = () => {
    const now = new Date();
    const lines = [
      `# Axiom Blueprint`,
      `Generated: ${now.toISOString()}`,
      `Builder: ${detectedBuilder?.toUpperCase() || "Unspecified"}`,
      `Readiness Score: ${readinessScore}%`,
      `AI Compatibility Score: ${readinessScore}%`,
      "",
      "---",
      "",
      "## Technical Manifest — Bill of Materials",
      "",
      "| Component | Detail |",
      "|---|---|",
      `| Platform | ${detectedBuilder?.toUpperCase() || "Unspecified"} |`,
      `| Database Tables | ${dbTables} |`,
      `| API Routes | ${apiRoutes} |`,
      `| Logic Blocks | ${logicBlocks} |`,
      `| Auth Method | ${resolvedNodes.some((n) => n.id === "auth") ? "Configured" : "Unspecified"} |`,
      `| Readiness | ${readinessScore}% |`,
      `| Execution Complexity | ${complexity} |`,
      "",
      "---",
      "",
      "## Architecture Map — Resolved Nodes",
      "",
      ...resolvedNodes.map((n) => `- **[${n.type.toUpperCase()}]** ${n.label}${n.details ? ` — ${n.details}` : ""}`),
      "",
      "---",
      "",
      "## Full Conversation Log",
      "",
      ...messages.filter((m) => m.id !== "welcome").map((m) =>
        `**[${m.role === "user" ? "USER" : "AXIOM"}]:** ${m.content}`
      ),
      "",
      "---",
      "",
      "## Master Initialization Prompt",
      "",
      masterPrompt,
      "",
      "---",
      "",
      "*Built with Axiom — The Specification Engine*",
      "*Into Innovations*",
    ];
    return lines.join("\n");
  };

  const handleDownload = () => {
    const blueprint = generateBlueprint();
    const blob = new Blob([blueprint], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `axiom-blueprint-${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2000);
  };

  const handleCopyMasterPrompt = async () => {
    try {
      await navigator.clipboard.writeText(masterPrompt);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = masterPrompt;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 1500);
  };

  // Save to legacy_log on mount
  const savedRef = useRef(false);
  useEffect(() => {
    if (savedRef.current) return;
    savedRef.current = true;
    (async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from("legacy_log").insert({
            user_id: user.id,
            prompt_output: generateBlueprint(),
            builder: detectedBuilder,
            compatibility_score: readinessScore,
          });
        }
      } catch (e) {
        console.error("Failed to save blueprint to vault:", e);
      }
    })();
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className="glass rounded-2xl border border-gold/30 p-6 w-[90vw] max-w-lg max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-lg font-bold text-gold mb-1">Axiom Blueprint</h2>
        <p className="text-[10px] text-silver-muted mb-4">Export your complete architectural specification</p>

        {/* Stat cards */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {stats.map((s) => (
            <div key={s.label} className="rounded-xl border border-gold/20 bg-obsidian-light p-2 text-center">
              <p className="text-[9px] text-silver-muted uppercase tracking-wider">{s.label}</p>
              <p className="text-sm font-bold text-gold">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2">
          <button
            onClick={handleDownload}
            className={`w-full rounded-xl py-3 text-sm font-bold transition-all ${
              downloaded
                ? "bg-gold/20 text-gold border border-gold/40"
                : "bg-gold text-gold-foreground hover:shadow-gold-intense"
            }`}
          >
            {downloaded ? "✓ Downloaded" : "Download Blueprint"}
          </button>
          <button
            onClick={handleCopyMasterPrompt}
            className={`w-full rounded-xl py-3 text-sm font-bold transition-all border ${
              copiedPrompt
                ? "border-gold/60 bg-gold/20 text-gold"
                : "border-gold/40 bg-gold/10 text-gold hover:bg-gold/20"
            }`}
          >
            {copiedPrompt ? "✓ Copied" : "Copy Master Prompt"}
          </button>
          <button
            onClick={onClose}
            className="w-full rounded-xl py-2.5 text-xs text-silver-muted border border-border/50 hover:text-foreground transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

