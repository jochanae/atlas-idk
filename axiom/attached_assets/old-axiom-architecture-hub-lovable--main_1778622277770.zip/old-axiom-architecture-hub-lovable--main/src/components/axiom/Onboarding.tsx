import { useEffect, useState } from "react";

export function Onboarding() {
  const [shouldShow, setShouldShow] = useState<boolean | null>(null);
  const [line1, setLine1] = useState(false);
  const [line2, setLine2] = useState(false);
  const [line3, setLine3] = useState(false);
  const [line4, setLine4] = useState(false);
  const [overlayOpacity, setOverlayOpacity] = useState(1);
  const [unmounted, setUnmounted] = useState(false);

  const dismiss = () => {
    localStorage.setItem("axiom_onboarded", "true");
    setUnmounted(true);
  };

  useEffect(() => {
    try {
      if (localStorage.getItem("axiom_onboarded")) {
        setShouldShow(false);
        return;
      }
    } catch {
      setShouldShow(false);
      return;
    }

    setShouldShow(true);

    setLine1(true);
    const t1 = setTimeout(() => setLine2(true), 900);
    const t2 = setTimeout(() => setLine3(true), 1800);
    const t3 = setTimeout(() => setLine4(true), 2400);
    const t4 = setTimeout(() => setOverlayOpacity(0), 3600);
    const t5 = setTimeout(() => {
      localStorage.setItem("axiom_onboarded", "true");
      setUnmounted(true);
    }, 4100);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, []);

  if (shouldShow === null || shouldShow === false || unmounted) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(13, 11, 9, 0.97)",
        opacity: overlayOpacity,
        transition: "opacity 500ms ease",
        pointerEvents: overlayOpacity === 0 ? "none" : "auto",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: "radial-gradient(ellipse at center, rgba(88,28,135,0.2) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      <button
        onClick={dismiss}
        style={{
          position: "absolute",
          top: 20,
          right: 20,
          fontSize: 12,
          color: "rgba(156,163,175,0.7)",
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: "8px 12px",
          zIndex: 1,
        }}
      >
        Skip
      </button>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 16,
          position: "relative",
          zIndex: 1,
        }}
      >
        <div
          style={{
            fontSize: 18,
            color: "rgba(255,255,255,0.7)",
            fontWeight: 300,
            opacity: line1 ? 1 : 0,
            transition: "opacity 600ms ease",
          }}
        >
          Before you build.
        </div>
        <div
          style={{
            fontSize: 18,
            color: "rgba(255,255,255,0.7)",
            fontWeight: 300,
            opacity: line2 ? 1 : 0,
            transition: "opacity 600ms ease",
          }}
        >
          Before you spend.
        </div>
        <div
          style={{
            fontSize: 32,
            color: "#D4AF37",
            fontWeight: 700,
            letterSpacing: "0.15em",
            opacity: line3 ? 1 : 0,
            transition: "opacity 600ms ease",
          }}
        >
          Axiom.
        </div>
        <div
          style={{
            opacity: line4 ? 1 : 0,
            transition: "opacity 600ms ease",
            fontSize: 13,
            color: "rgba(212,175,55,0.6)",
            fontWeight: 400,
            letterSpacing: "0.08em",
            marginTop: 12,
            textAlign: "center",
          }}
        >
          The intelligence layer before the first line of code.
        </div>
      </div>
    </div>
  );
}
