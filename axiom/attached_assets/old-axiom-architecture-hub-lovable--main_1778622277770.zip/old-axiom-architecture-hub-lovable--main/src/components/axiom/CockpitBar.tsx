import { useState } from "react";
import { useAxiom } from "@/hooks/use-axiom-store";
import { useIsMobile } from "@/hooks/use-mobile";
import { BlueprintExportModal } from "./GoldContainer";
import { openFloatingPanel } from "./FloatingPanel";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";

// ─── Atlas handoff ───────────────────────────────────────────────────────────

const ATLAS_URL = "https://fee20bc2-8f8b-480d-9a00-8a020487f43d-00-2y5j4gt65umzi.janeway.replit.dev";

async function handoffToAtlas(
  messages: import("@/hooks/use-axiom-store").ChatMessage[],
  nodes: import("@/hooks/use-axiom-store").ArchNode[],
  detectedBuilder: string | null
): Promise<void> {
  const resolvedNodes = nodes.filter(n => n.resolved).map(n => n.id);

  const manifest = messages
    .filter(m => m.role !== "system" || m.id === "welcome")
    .map(m => `${m.role === "user" ? "User" : "Axiom"}: ${m.content}`)
    .join("\n\n");

  const decisions = [
    ...resolvedNodes.map(id => ({
      tier: 1,
      text: `Architecture node resolved: ${id}`
    })),
    ...(detectedBuilder ? [{
      tier: 2,
      text: `Target builder: ${detectedBuilder}`
    }] : []),
  ];

  const payload = {
    project_name: `Axiom Spec — ${new Date().toLocaleDateString()}`,
    builder: detectedBuilder || "unspecified",
    nodes_resolved: resolvedNodes,
    manifest,
    decisions,
  };

  const res = await fetch(`${ATLAS_URL}/api/import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw new Error(`Atlas returned ${res.status}`);
  const { projectId } = await res.json();
  window.open(`${ATLAS_URL}/project/${projectId}?source=axiom`, "_blank");
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function stripMarkdown(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/\*(.+?)\*/g, "$1")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/^---+$/gm, "")
    .replace(/`{3}[\s\S]*?`{3}/g, (m) => m.replace(/`{3}[^\n]*/g, "").trim())
    .replace(/`(.+?)`/g, "$1")
    .replace(/\|/g, " ")
    .replace(/\[(.+?)\]\(.+?\)/g, "$1")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ─── Axiom SVG logo (used inside the raised center button) ───────────────────

function AxiomLogoSVG() {
  return (
    <svg viewBox="0 0 512 512" width="44" height="44">
      <defs>
        <radialGradient id="pg" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#5B21B6" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#0D0B09" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="gs" cx="50%" cy="40%" r="50%">
          <stop offset="0%" stopColor="#F5D97A" />
          <stop offset="50%" stopColor="#D4AF37" />
          <stop offset="100%" stopColor="#A07820" />
        </radialGradient>
      </defs>
      <rect width="512" height="512" rx="90" fill="#0D0B09" />
      <rect width="512" height="512" rx="90" fill="url(#pg)" />
      <polygon points="256,110 170,402 212,402 274,172" fill="url(#gs)" />
      <polygon points="256,110 342,402 300,402 238,172" fill="url(#gs)" />
      <rect x="180" y="282" width="152" height="34" rx="5" fill="url(#gs)" />
    </svg>
  );
}

// ─── CockpitBar ───────────────────────────────────────────────────────────────

export function CockpitBar() {
  const { readinessScore, saveToVault, nodes, messages, detectedBuilder, resetSession } = useAxiom();
  const isMobile = useIsMobile();
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showBlueprint, setShowBlueprint] = useState(false);
  const [showExportSheet, setShowExportSheet] = useState(false);
  const [atlasLoading, setAtlasLoading] = useState(false);
  const [atlasError, setAtlasError] = useState(false);
  const [specName, setSpecName] = useState("");
  const [saved, setSaved] = useState(false);
  const [exportToast, setExportToast] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [copiedSpec, setCopiedSpec] = useState(false);
  const [downloadedTxt, setDownloadedTxt] = useState(false);
  const [downloadedMd, setDownloadedMd] = useState(false);

  const atlasReady = readinessScore >= 80;

  const handleResetSession = () => {
    if (typeof window !== "undefined" && !window.confirm("Reset this session? Map, chat, and decisions will be cleared. Saved specs in your Vault are not affected.")) return;
    haptics.tap();
    sounds.tap();
    resetSession();
  };

  const handleSave = () => {
    if (!specName.trim()) return;
    saveToVault(specName.trim());
    setSpecName("");
    setShowSaveDialog(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const compileBlueprintLines = (): string[] => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const resolvedNodes = nodes.filter((n) => n.resolved);
    const dbCount = nodes.filter((n) => n.type === "database" && n.resolved).length;
    const apiCount = nodes.filter((n) => n.type === "api" && n.resolved).length;
    const logicCount = nodes.filter((n) => n.type === "logic" && n.resolved).length;
    const authResolved = resolvedNodes.some((n) => n.id === "auth");
    const complexity = readinessScore > 80 ? "Standard" : readinessScore > 50 ? "Moderate" : "Complex";
    const builder = detectedBuilder?.toUpperCase() || "Unspecified";

    const masterPromptMsg = [...messages].reverse().find(
      (m) => m.role === "system" && (
        m.content.toLowerCase().includes("golden specification") ||
        m.content.toLowerCase().includes("technical manifest") ||
        m.content.toLowerCase().includes("the plumbing") ||
        m.content.toLowerCase().includes("full spec") ||
        m.content.toLowerCase().includes("sprint 3 complete")
      )
    );
    const masterPrompt = masterPromptMsg?.content ||
      "Complete all three Sprints in Axiom to generate your Master Initialization Prompt.\nReturn to the session and answer all Sprint questions to unlock the full spec.";

    return [
      `# Axiom Blueprint`,
      `Generated: ${now.toLocaleString()}`,
      `Builder: ${builder}`,
      `Readiness Score: ${readinessScore}%`,
      "",
      "---",
      "",
      "## Technical Manifest — Bill of Materials",
      "",
      "| Component | Detail |",
      "|---|---|",
      `| Platform | ${builder} |`,
      `| Database Nodes | ${dbCount} |`,
      `| API Route Nodes | ${apiCount} |`,
      `| Logic Block Nodes | ${logicCount} |`,
      `| Auth Node | ${authResolved ? "Resolved" : "Unresolved"} |`,
      `| Overall Readiness | ${readinessScore}% |`,
      `| Execution Complexity | ${complexity} |`,
      "",
      "---",
      "",
      "## Architecture Map — Node Status",
      "",
      "| Node Name | Type | Status |",
      "|---|---|---|",
      ...nodes.map((n) => `| ${n.label} | ${n.type} | ${n.resolved ? "Resolved" : "Unresolved"} |`),
      "",
      "---",
      "",
      "## Full Conversation Log",
      "",
      ...messages.filter((m) => m.id !== "welcome").map((m) =>
        `**[${m.role === "user" ? "YOU" : "AXIOM"}]:** ${m.content}`
      ),
      "",
      "---",
      "",
      "## Master Initialization Prompt",
      "",
      masterPrompt,
      "",
      "---",
      "",
      "*Built with Axiom — The Specification Engine*",
      "*Into Innovations*",
    ];
  };

  const handleAtlasHandoff = async () => {
    setAtlasLoading(true);
    setAtlasError(false);
    try {
      await handoffToAtlas(messages, nodes, detectedBuilder);
    } catch {
      setAtlasError(true);
      setTimeout(() => setAtlasError(false), 2500);
    } finally {
      setAtlasLoading(false);
    }
  };

  const handleExport = () => {
    haptics.exported();
    sounds.exported();
    setShowExportSheet(true);
  };

  const handleCopyFullSpec = async () => {
    const raw = compileBlueprintLines().join("\n");
    const clean = stripMarkdown(raw);
    try {
      await navigator.clipboard.writeText(clean);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = clean;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    haptics.cardConfirmed();
    sounds.cardConfirmed();
    setCopiedSpec(true);
    setTimeout(() => { setCopiedSpec(false); setShowExportSheet(false); }, 1800);
  };

  const triggerDownload = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadTxt = () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const ts = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
    const raw = compileBlueprintLines().join("\n");
    const clean = stripMarkdown(raw);
    triggerDownload(clean, `axiom-blueprint-${ts}.txt`, "text/plain");
    haptics.nodeResolved();
    sounds.nodeResolved();
    setDownloadedTxt(true);
    setTimeout(() => { setDownloadedTxt(false); setShowExportSheet(false); }, 1800);
  };

  const handleDownloadMd = () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const ts = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
    triggerDownload(compileBlueprintLines().join("\n"), `axiom-blueprint-${ts}.md`, "text/markdown");
    haptics.tap();
    sounds.tap();
    setDownloadedMd(true);
    setTimeout(() => { setDownloadedMd(false); setShowExportSheet(false); }, 1800);
  };

  // Sheet/card positioning — mobile uses 60px curved bar, desktop uses 48px flat bar
  const cockpitH = isMobile ? 60 : 48;

  const hasSession = readinessScore > 0;

  return (
    <>
      <style>{`
        @keyframes axiom-pulse {
          0%, 100% { box-shadow: 0 0 20px rgba(212,175,55,0.3), 0 4px 12px rgba(0,0,0,0.5); }
          50%       { box-shadow: 0 0 35px rgba(212,175,55,0.6), 0 4px 12px rgba(0,0,0,0.5); }
        }
        @keyframes axiomPulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(212,175,55,0.5); }
          50%       { box-shadow: 0 0 0 8px rgba(212,175,55,0); }
        }
        @keyframes slideUpHelp {
          from { transform: translateX(-50%) translateY(16px); opacity: 0; }
          to   { transform: translateX(-50%) translateY(0);   opacity: 1; }
        }
        @keyframes slideUpSheet {
          from { transform: translateY(24px); opacity: 0; }
          to   { transform: translateY(0);    opacity: 1; }
        }
      `}</style>

      {/* ── Help card ────────────────────────────────────────────────────── */}
      {showHelp && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setShowHelp(false)} />
          <div
            className="fixed left-1/2 z-40"
            style={{
              bottom: cockpitH,
              transform: "translateX(-50%)",
              width: "min(90vw, 360px)",
              background: "oklch(0.15 0.01 60)",
              border: "1px solid rgba(212, 175, 55, 0.3)",
              borderRadius: "12px 12px 0 0",
              padding: "20px 20px 16px",
              animation: "slideUpHelp 200ms ease",
            }}
          >
            <p className="text-sm font-bold text-gold mb-2">What is Axiom?</p>
            <p className="text-xs text-silver-muted leading-relaxed mb-4">
              Axiom is your specification engine. Before you spend a dollar in any builder, Axiom makes sure you know exactly what you're building.
            </p>
            <p className="text-[10px] font-semibold text-gold uppercase tracking-widest mb-2">How it works</p>
            <ol className="text-xs text-silver-muted space-y-1 mb-4 list-none">
              {[
                "Describe your idea",
                "Answer the Sprint questions",
                "Watch the map fill with gold",
                "Export your Blueprint",
                "Build with zero guesswork",
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-gold font-bold shrink-0">{i + 1}.</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
            <p className="text-xs text-silver-muted leading-relaxed mb-4">
              Tap any <span className="text-gold underline decoration-gold/40">gold word</span> to learn what it means. Tap any node on the map to see its status.
            </p>
            <div className="flex justify-end">
              <button
                onClick={() => setShowHelp(false)}
                className="rounded-lg bg-gold px-4 py-1.5 text-xs font-bold text-gold-foreground hover:shadow-gold transition-all"
              >
                Got it
              </button>
            </div>
          </div>
        </>
      )}

      {/* ── Export action sheet ───────────────────────────────────────────── */}
      {showExportSheet && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowExportSheet(false)}
          />
          <div
            className="fixed left-0 right-0 z-50"
            style={{
              bottom: cockpitH,
              background: "rgba(13, 11, 9, 0.98)",
              border: "1px solid rgba(212, 175, 55, 0.35)",
              borderRadius: "16px 16px 0 0",
              padding: "20px 20px 24px",
              animation: "slideUpSheet 220ms ease",
            }}
          >
            <p className="text-sm font-bold text-gold mb-1">Export Blueprint</p>
            <p className="text-[10px] text-silver-muted mb-5">Choose how you want to use your spec.</p>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={handleCopyFullSpec}
                className="w-full rounded-xl py-3.5 text-sm font-bold transition-all"
                style={{
                  background: copiedSpec ? "rgba(212,175,55,0.2)" : "#D4AF37",
                  color: copiedSpec ? "#D4AF37" : "#0D0B09",
                  border: copiedSpec ? "1px solid rgba(212,175,55,0.5)" : "none",
                }}
              >
                {copiedSpec ? "✓ Copied to Clipboard" : "Copy Full Spec to Clipboard"}
              </button>

              <button
                onClick={handleDownloadTxt}
                className="w-full rounded-xl py-3 text-sm font-semibold transition-all"
                style={{
                  background: "transparent",
                  border: "1px solid rgba(212,175,55,0.4)",
                  color: downloadedTxt ? "#D4AF37" : "rgba(255,255,255,0.8)",
                }}
              >
                {downloadedTxt ? "✓ Downloaded" : "Download as TXT"}
              </button>

              <button
                onClick={handleDownloadMd}
                className="w-full py-2.5 text-xs font-medium transition-all"
                style={{ color: downloadedMd ? "#D4AF37" : "rgba(255,255,255,0.4)" }}
              >
                {downloadedMd ? "✓ Downloaded" : "Download .md (technical)"}
              </button>

              <button
                onClick={() => setShowExportSheet(false)}
                className="w-full py-2.5 text-xs font-medium"
                style={{ color: "rgba(255,255,255,0.3)" }}
              >
                Cancel
              </button>
            </div>
          </div>
        </>
      )}

      {/* ── Readiness strip — slim bar above the footer ───────────────────── */}
      <div style={{ width: "100%", background: "rgba(13, 11, 9, 0.97)" }}>
        <div style={{ display: "flex", justifyContent: "flex-start", padding: "3px 10px 2px" }}>
          <span style={{ fontSize: 10, fontWeight: 700, color: "#D4AF37", letterSpacing: "0.06em" }}>
            {readinessScore}%
          </span>
        </div>
        <div style={{ height: 3, width: "100%", background: "rgba(212, 175, 55, 0.15)" }}>
          <div
            style={{
              height: "100%",
              width: `${readinessScore}%`,
              background: "#D4AF37",
              transition: "width 700ms ease",
            }}
          />
        </div>
      </div>

      {/* ── Cockpit Bar ───────────────────────────────────────────────────── */}
      {isMobile ? (
        /* ── Mobile: curved arch footer ── */
        <div
          className="relative shrink-0"
          style={{
            height: 72,
            paddingBottom: "max(env(safe-area-inset-bottom), 12px)",
            overflow: "visible",
            zIndex: 20,
            position: "relative",
          }}
        >
          {/* SVG bar with arch cutout */}
          <svg
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "visible" }}
            preserveAspectRatio="none"
            viewBox="0 0 390 60"
          >
            {/* Filled bar shape — dips around center */}
            <path
              d="M0,0 L148,0 C163,0 172,22 195,22 C218,22 227,0 242,0 L390,0 L390,60 L0,60 Z"
              fill="rgba(13, 11, 9, 0.97)"
            />
            {/* Gold border along top edge, tracing the arch */}
            <path
              d="M0,0.5 L148,0.5 C163,0.5 172,22 195,22 C218,22 227,0.5 242,0.5 L390,0.5"
              fill="none"
              stroke="rgba(212, 175, 55, 0.25)"
              strokeWidth="1"
              vectorEffect="non-scaling-stroke"
            />
          </svg>

          {/* Raised center A button */}
          <button
            onClick={() => { haptics.tap(); sounds.tap(); openFloatingPanel(); }}
            title="Open Axiom Panel"
            style={{
              position: "absolute",
              top: -28,
              left: "50%",
              transform: "translateX(-50%)",
              width: 64,
              height: 64,
              borderRadius: "50%",
              background: "#0D0B09",
              border: "2px solid #D4AF37",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 10,
              animation: hasSession ? "axiom-pulse 2s ease-in-out infinite" : "none",
              boxShadow: hasSession ? undefined : "0 0 20px rgba(212,175,55,0.3), 0 4px 12px rgba(0,0,0,0.5)",
              cursor: "pointer",
            }}
          >
            <AxiomLogoSVG />
          </button>

          {/* AXIOM label below center button */}
          <span
            style={{
              position: "absolute",
              top: 38,
              left: "50%",
              transform: "translateX(-50%)",
              fontSize: 9,
              letterSpacing: "0.12em",
              color: "#D4AF37",
              fontWeight: 700,
              whiteSpace: "nowrap",
              zIndex: 10,
              pointerEvents: "none",
            }}
          >
            AXIOM
          </span>

          {/* Left: ? help + ⟳ reset */}
          <div
            style={{
              position: "absolute",
              left: 16,
              top: "50%",
              transform: "translateY(-50%)",
              display: "flex",
              alignItems: "center",
              gap: 6,
              zIndex: 10,
            }}
          >
            <button
              onClick={() => { haptics.tap(); sounds.tap(); setShowHelp((v) => !v); }}
              title="Help"
              style={{
                width: 32, height: 32, borderRadius: "50%",
                border: "1px solid rgba(212,175,55,0.4)",
                background: "transparent", color: "#D4AF37",
                fontSize: 13, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center",
                cursor: "pointer",
              }}
            >
              ?
            </button>
            <button
              onClick={handleResetSession}
              title="Reset session"
              style={{
                width: 40, height: 40, borderRadius: "50%",
                border: "1px solid rgba(212,175,55,0.4)",
                background: "transparent", color: "#D4AF37",
                display: "flex", alignItems: "center", justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="23 4 23 10 17 10" />
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
              </svg>
            </button>
          </div>

          {/* Right: Atlas + Export grouped tight */}
          <div
            style={{
              position: "absolute",
              right: 20,
              top: "50%",
              transform: "translateY(-50%)",
              display: "flex",
              alignItems: "center",
              gap: 6,
              zIndex: 10,
            }}
          >
            <button
              onClick={handleAtlasHandoff}
              disabled={atlasLoading || !atlasReady}
              title={!atlasReady ? `Spec ${readinessScore}% — reach 80% to hand off` : "Compile spec and hand off to Atlas"}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "8px 12px",
                borderRadius: 10,
                background: atlasError
                  ? "rgba(239,68,68,0.15)"
                  : atlasReady ? "rgba(212,175,55,0.1)" : "transparent",
                border: atlasError
                  ? "1px solid rgba(239,68,68,0.3)"
                  : `1px solid rgba(212,175,55,${atlasReady ? 0.25 : 0.15})`,
                color: atlasError ? "rgba(239,68,68,0.8)" : "#D4AF37",
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: "0.06em",
                cursor: atlasLoading ? "wait" : !atlasReady ? "not-allowed" : "pointer",
                transition: "all 150ms",
                opacity: atlasLoading ? 0.6 : !atlasReady ? 0.45 : 1,
              }}
            >
              {atlasError ? "Retry" : atlasLoading ? "..." : "→ Atlas"}
            </button>

            <button
              onClick={handleExport}
              title="Export Blueprint"
              style={{
                display: "flex",
                alignItems: "center",
                background: "transparent",
                border: "1px solid rgba(212,175,55,0.4)",
                borderRadius: 8,
                padding: "7px 9px",
                color: "#D4AF37",
                cursor: "pointer",
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            </button>
          </div>
        </div>
      ) : (
        /* ── Desktop: flat cockpit bar (unchanged) ── */
        <div
          className="flex items-center justify-between border-t h-12 px-4 gap-4"
          style={{ borderColor: "oklch(0.76 0.12 85 / 25%)", background: "oklch(0.13 0.01 60 / 90%)", backdropFilter: "blur(12px)" }}
        >
          {/* Left: Help + Readiness */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => { haptics.tap(); sounds.tap(); setShowHelp((v) => !v); }}
              className="flex h-7 w-7 items-center justify-center rounded-full border border-gold/40 text-gold text-xs font-bold hover:bg-gold/10 transition-colors shrink-0"
              title="Help"
            >
              ?
            </button>
            <button
              onClick={handleResetSession}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/40 text-gold hover:bg-gold/10 transition-colors shrink-0"
              title="Reset session"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="23 4 23 10 17 10" />
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
              </svg>
            </button>
            <span className="text-[10px] font-semibold tracking-widest text-silver-muted uppercase hidden sm:block">Readiness</span>
            <div className="flex items-center gap-2">
              <div className="h-1.5 w-20 rounded-full bg-obsidian-surface overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${readinessScore}%`,
                    background: readinessScore < 60 ? "oklch(0.70 0.15 70)" : "var(--gradient-gold)",
                  }}
                />
              </div>
              <span className={`text-xs font-bold ${readinessScore < 60 ? "text-amber-glow" : "text-gold"}`}>
                {readinessScore}%
              </span>
            </div>
          </div>

          {/* Center: Open Floating Panel */}
          <button
            onClick={() => { haptics.tap(); sounds.tap(); openFloatingPanel(); }}
            title="Open Axiom Panel"
            className="flex items-center justify-center rounded-full transition-transform hover:scale-105 active:scale-95 shrink-0"
            style={{
              width: 40,
              height: 40,
              background: "#D4AF37",
              animation: hasSession ? "axiomPulse 2.2s ease-in-out infinite" : "none",
            }}
          >
            <span style={{ fontSize: 19, fontWeight: 900, color: "#14120e", fontFamily: "serif", letterSpacing: "-0.02em", lineHeight: 1 }}>
              A
            </span>
          </button>

          {/* Right: Atlas + Export */}
          <button
            onClick={handleAtlasHandoff}
            disabled={atlasLoading || !atlasReady}
            title={!atlasReady ? `Spec ${readinessScore}% — reach 80% to hand off` : "Compile spec and hand off to Atlas"}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "8px 14px",
              borderRadius: 10,
              background: atlasError
                ? "rgba(239,68,68,0.15)"
                : atlasReady ? "rgba(212,175,55,0.1)" : "transparent",
              border: atlasError
                ? "1px solid rgba(239,68,68,0.3)"
                : `1px solid rgba(212,175,55,${atlasReady ? 0.25 : 0.15})`,
              color: atlasError ? "rgba(239,68,68,0.8)" : "#D4AF37",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.06em",
              cursor: atlasLoading ? "wait" : !atlasReady ? "not-allowed" : "pointer",
              transition: "all 150ms",
              opacity: atlasLoading ? 0.6 : !atlasReady ? 0.45 : 1,
            }}
          >
            {atlasError ? "Failed — retry" : atlasLoading ? "Sending..." : "Hand Off → Atlas"}
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-all border-gold/40 bg-gold/10 text-gold hover:bg-gold/20 hover:shadow-gold"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Export to Gold Vault
          </button>
        </div>
      )}

      {/* ── Save Dialog ───────────────────────────────────────────────────── */}
      {showSaveDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="glass rounded-2xl border border-gold/30 p-6 w-80">
            <h3 className="text-sm font-bold text-gold mb-1">Save to Vault</h3>
            <p className="text-[10px] text-silver-muted mb-4">Name this specification for the Legacy Log.</p>
            <input
              type="text"
              value={specName}
              onChange={(e) => setSpecName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
              placeholder="e.g. E-Commerce Platform"
              autoFocus
              className="w-full rounded-lg border border-gold/20 bg-obsidian-surface px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-gold/50"
            />
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => setShowSaveDialog(false)}
                className="flex-1 rounded-lg border border-border/50 py-2 text-xs text-silver-muted hover:text-foreground transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={!specName.trim()}
                className="flex-1 rounded-lg bg-gold py-2 text-xs font-bold text-gold-foreground disabled:opacity-30 hover:shadow-gold transition-all"
              >
                Save Spec
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Blueprint Export Modal ────────────────────────────────────────── */}
      {showBlueprint && (
        <BlueprintExportModal onClose={() => setShowBlueprint(false)} />
      )}
    </>
  );
}
