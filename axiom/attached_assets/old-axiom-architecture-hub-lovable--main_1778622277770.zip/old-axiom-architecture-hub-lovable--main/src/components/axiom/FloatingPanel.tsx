import { useState, useRef, useEffect } from "react";
import { useAxiom } from "@/hooks/use-axiom-store";
import { useIsMobile } from "@/hooks/use-mobile";
import { ChatHook } from "./ChatHook";
import { QuickPrompt } from "./QuickPrompt";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";

type PanelTab = "spec" | "quick";

// ─── Sub-components ──────────────────────────────────────────────────────────

function PanelHeader({
  activeTab,
  setActiveTab,
  readinessScore,
  isPinned,
  showPin,
  onPin,
  onClose,
}: {
  activeTab: PanelTab;
  setActiveTab: (t: PanelTab) => void;
  readinessScore: number;
  isPinned: boolean;
  showPin: boolean;
  onPin: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="flex items-center gap-2 px-4 py-2.5 border-b shrink-0"
      style={{ borderColor: "rgba(212,175,55,0.2)" }}
    >
      {/* Logo */}
      <span className="text-xs font-bold text-gold animate-shimmer shrink-0">AXIOM</span>

      {/* Tabs */}
      <div className="flex gap-1 ml-1">
        {(["spec", "quick"] as PanelTab[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`rounded-md px-2.5 py-1 text-[10px] font-semibold tracking-wider uppercase transition-all ${
              activeTab === tab
                ? "bg-gold/15 text-gold border border-gold/30"
                : "text-silver-muted hover:text-silver"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* Readiness */}
        <span className={`text-xs font-bold ${readinessScore < 60 ? "text-amber-glow" : "text-gold"}`}>
          {readinessScore}%
        </span>

        {/* Pin (desktop only) */}
        {showPin && (
          <button
            onClick={onPin}
            title={isPinned ? "Unpin panel" : "Pin panel"}
            className={`flex h-6 w-6 items-center justify-center rounded transition-colors ${
              isPinned ? "text-gold" : "text-silver-muted hover:text-silver"
            }`}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill={isPinned ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2">
              <path d="M12 2l3 7h5l-4 4 1.5 7L12 17l-5.5 3L8 13 4 9h5L12 2z" />
            </svg>
          </button>
        )}

        {/* Close */}
        <button
          onClick={onClose}
          className="flex h-6 w-6 items-center justify-center rounded text-silver-muted hover:text-foreground transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      </div>
    </div>
  );
}

function PanelContent({ activeTab }: { activeTab: PanelTab }) {
  return (
    <div className="flex-1 min-h-0 overflow-hidden">
      {activeTab === "spec" ? (
        <ChatHook />
      ) : (
        <QuickPrompt />
      )}
    </div>
  );
}

// ─── Module-level open handle (lets CockpitBar trigger the panel) ─────────────

let _openHandle: (() => void) | null = null;
export function openFloatingPanel() { _openHandle?.(); }

// ─── FloatingPanel ────────────────────────────────────────────────────────────

export function FloatingPanel() {
  const { readinessScore } = useAxiom();
  const isMobile = useIsMobile();

  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<PanelTab>("quick");
  const [isPinned, setIsPinned] = useState(false);
  const [panelWidth, setPanelWidth] = useState(380);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const dragRef = useRef<{ startY: number } | null>(null);
  const resizeRef = useRef<{ startX: number; startWidth: number } | null>(null);

  const hasSession = readinessScore > 0;

  // Pin effect — push main content aside when pinned on desktop
  useEffect(() => {
    if (!isMobile && isPinned && isOpen) {
      document.documentElement.style.paddingRight = `${panelWidth}px`;
    } else {
      document.documentElement.style.paddingRight = "";
    }
    return () => { document.documentElement.style.paddingRight = ""; };
  }, [isPinned, isOpen, isMobile, panelWidth]);

  const openPanel = () => {
    haptics.tap();
    sounds.tap();
    setIsOpen(true);
    setDragOffset(0);
  };

  // Register module-level handle so CockpitBar can open the panel
  useEffect(() => {
    _openHandle = openPanel;
    return () => { _openHandle = null; };
  });

  const closePanel = () => {
    setIsOpen(false);
    setDragOffset(0);
    setIsDragging(false);
  };

  // Mobile drag-to-dismiss
  const onHandleTouchStart = (e: React.TouchEvent) => {
    dragRef.current = { startY: e.touches[0].clientY };
    setIsDragging(true);
  };

  const onHandleTouchMove = (e: React.TouchEvent) => {
    if (!dragRef.current) return;
    const dy = e.touches[0].clientY - dragRef.current.startY;
    if (dy > 0) setDragOffset(dy);
  };

  const onHandleTouchEnd = () => {
    const panelH = window.innerHeight * 0.7;
    if (dragOffset > panelH * 0.3) {
      closePanel();
    } else {
      setDragOffset(0);
      setIsDragging(false);
    }
    dragRef.current = null;
  };

  // Desktop resize
  const onResizeStart = (e: React.MouseEvent) => {
    e.preventDefault();
    resizeRef.current = { startX: e.clientX, startWidth: panelWidth };
    const onMouseMove = (e: MouseEvent) => {
      if (!resizeRef.current) return;
      const delta = resizeRef.current.startX - e.clientX;
      setPanelWidth(Math.max(300, Math.min(500, resizeRef.current.startWidth + delta)));
    };
    const onMouseUp = () => {
      resizeRef.current = null;
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  };

  const showTrigger = !isOpen || (isMobile ? false : !isPinned);

  return (
    <>
      <style>{`
        @keyframes axiomPulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(212,175,55,0.5); }
          50% { box-shadow: 0 0 0 8px rgba(212,175,55,0); }
        }
        @keyframes slideUpSheet {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        @keyframes slideInSide {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
      `}</style>

      {/* Panel */}
      {isOpen && (
        <>
          {/* Backdrop */}
          {(!isPinned || isMobile) && (
            <div
              className="fixed inset-0 z-[9990] bg-black/40 backdrop-blur-sm"
              onClick={closePanel}
            />
          )}

          {isMobile ? (
            /* ── Mobile bottom sheet ── */
            <div
              className="fixed inset-x-0 bottom-0 z-[9995] flex flex-col rounded-t-2xl overflow-hidden"
              style={{
                height: "70vh",
                background: "oklch(0.13 0.01 60)",
                border: "1px solid rgba(212,175,55,0.25)",
                borderBottom: "none",
                boxShadow: "0 -8px 40px rgba(0,0,0,0.5), 0 0 60px rgba(100,60,180,0.08)",
                transform: `translateY(${dragOffset}px)`,
                transition: isDragging ? "none" : "transform 250ms ease-out",
                animation: dragOffset === 0 && !isDragging ? "slideUpSheet 250ms ease-out" : "none",
              }}
            >
              {/* Handle bar */}
              <div
                className="flex justify-center pt-3 pb-1 shrink-0 touch-none"
                onTouchStart={onHandleTouchStart}
                onTouchMove={onHandleTouchMove}
                onTouchEnd={onHandleTouchEnd}
              >
                <div className="h-1 w-10 rounded-full bg-gold/25" />
              </div>

              <PanelHeader
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                readinessScore={readinessScore}
                isPinned={false}
                showPin={false}
                onPin={() => {}}
                onClose={closePanel}
              />
              <PanelContent activeTab={activeTab} />
            </div>
          ) : (
            /* ── Desktop side panel ── */
            <div
              className="fixed top-0 right-0 bottom-0 z-[9995] flex flex-col overflow-hidden"
              style={{
                width: panelWidth,
                background: "oklch(0.13 0.01 60)",
                borderLeft: "1px solid rgba(212,175,55,0.25)",
                boxShadow: "-8px 0 40px rgba(0,0,0,0.4), 0 0 60px rgba(100,60,180,0.06)",
                animation: "slideInSide 250ms ease-out",
              }}
            >
              {/* Resize handle */}
              <div
                className="absolute left-0 top-0 bottom-0 w-1.5 cursor-col-resize z-10 hover:bg-gold/20 transition-colors"
                onMouseDown={onResizeStart}
              />

              <PanelHeader
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                readinessScore={readinessScore}
                isPinned={isPinned}
                showPin={true}
                onPin={() => setIsPinned((v) => !v)}
                onClose={closePanel}
              />
              <PanelContent activeTab={activeTab} />
            </div>
          )}
        </>
      )}
    </>
  );
}
