/**
 * Axiom V2 — Markup-only sketch.
 * No state. No logic. No data wiring. Pure visual surface so the
 * design weight, glow, and spacing can be reviewed on a Z Fold 6
 * before any components get committed.
 */
import { useState } from "react";

type Mode = "empty" | "populated";

export function SketchShell({ mode }: { mode: Mode }) {
  const [view, setView] = useState<"door" | "workspace">("door");

  return (
    <div className="axiom-v2" style={{ minHeight: "100dvh", position: "relative" }}>
      <SketchTopBar mode={mode} view={view} onView={setView} />
      {view === "door" ? <FrontDoor mode={mode} /> : <Workspace mode={mode} />}
    </div>
  );
}

/* ------------------------------------------------------------ */
/* Top bar — only exists in the sketch so you can flip surfaces */
/* ------------------------------------------------------------ */
function SketchTopBar({
  mode,
  view,
  onView,
}: {
  mode: Mode;
  view: "door" | "workspace";
  onView: (v: "door" | "workspace") => void;
}) {
  return (
    <div
      style={{
        position: "sticky",
        top: 0,
        zIndex: 10,
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 16px",
        background: "rgba(12, 10, 9, 0.85)",
        backdropFilter: "blur(12px)",
        borderBottom: "0.5px solid var(--v2-border)",
      }}
    >
      <span className="v2-mono">SKETCH · {mode === "empty" ? "EMPTY" : "POPULATED"}</span>
      <div style={{ flex: 1 }} />
      <ToggleChip active={view === "door"} onClick={() => onView("door")}>
        Front Door
      </ToggleChip>
      <ToggleChip active={view === "workspace"} onClick={() => onView("workspace")}>
        Workspace
      </ToggleChip>
    </div>
  );
}

function ToggleChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "6px 12px",
        fontSize: 11,
        letterSpacing: "0.18em",
        textTransform: "uppercase",
        background: active ? "rgba(201,162,76,0.10)" : "transparent",
        border: `0.5px solid ${active ? "rgba(201,162,76,0.55)" : "var(--v2-border)"}`,
        color: active ? "var(--v2-gold)" : "var(--v2-muted)",
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}

/* ============================================================ */
/* FRONT DOOR — "Where were we."                                */
/* ============================================================ */
function FrontDoor({ mode }: { mode: Mode }) {
  const projects =
    mode === "populated"
      ? [
          { name: "Axiom", date: "May 9 · today", committed: 14 },
          { name: "Atlas / Founder Intel", date: "May 7", committed: 9 },
          { name: "iEmpowerMe — Lead Funnel", date: "Apr 28", committed: 22 },
        ]
      : [];

  return (
    <div
      className="v2-glow-bg"
      style={{
        position: "relative",
        minHeight: "calc(100dvh - 44px)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "min(14vh, 120px) 24px 64px",
      }}
    >
      <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 720 }}>
        <h1
          className="v2-h"
          style={{
            fontSize: "clamp(36px, 7vw, 64px)",
            lineHeight: 1.05,
            letterSpacing: "0.01em",
            textTransform: "none",
            fontWeight: 300,
            margin: 0,
            textAlign: "center",
            fontFamily: "'Cormorant Garamond', 'Inter', serif",
            color: "var(--v2-text)",
          }}
        >
          Where were we.
        </h1>
        <p
          style={{
            textAlign: "center",
            color: "var(--v2-muted)",
            fontSize: 13,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            marginTop: 18,
          }}
        >
          A strategic thinking partner, not a wizard.
        </p>

        {/* Breathing input */}
        <div
          className="v2-input-breathe"
          style={{
            marginTop: 48,
            padding: "18px 20px",
            background: "rgba(28, 25, 23, 0.55)",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(201,162,76,0.45)",
            borderRadius: 2,
          }}
        >
          <input
            placeholder="What are you building?"
            style={{
              fontSize: 17,
              color: "var(--v2-text)",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
            }}
            readOnly
          />
        </div>

        <div
          style={{
            marginTop: 10,
            display: "flex",
            justifyContent: "space-between",
            color: "var(--v2-muted)",
            fontSize: 10,
            letterSpacing: "0.18em",
            textTransform: "uppercase",
          }}
        >
          <span>↵ Resume last session</span>
          <span>+ New project</span>
        </div>

        {/* Projects */}
        <div style={{ marginTop: 80 }}>
          <div className="v2-mono" style={{ marginBottom: 14 }}>
            Recent · {projects.length}
          </div>
          {projects.length === 0 ? (
            <EmptyProjectsCard />
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {projects.map((p) => (
                <ProjectCard key={p.name} {...p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function EmptyProjectsCard() {
  return (
    <div
      className="v2-glass"
      style={{
        padding: "32px 24px",
        textAlign: "center",
        color: "var(--v2-muted)",
        fontSize: 13,
        letterSpacing: "0.04em",
      }}
    >
      No projects yet. Type above — Axiom will start a new one.
    </div>
  );
}

function ProjectCard({
  name,
  date,
  committed,
}: {
  name: string;
  date: string;
  committed: number;
}) {
  return (
    <div
      className="v2-glass"
      style={{
        padding: "16px 18px",
        display: "flex",
        alignItems: "center",
        gap: 14,
        cursor: "pointer",
      }}
    >
      <div
        style={{
          width: 6,
          height: 6,
          background: "var(--v2-gold)",
          boxShadow: "0 0 10px rgba(201,162,76,0.7)",
        }}
      />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, color: "var(--v2-text)", fontWeight: 500 }}>{name}</div>
        <div style={{ fontSize: 11, color: "var(--v2-muted)", marginTop: 3 }}>{date}</div>
      </div>
      <div className="v2-mono" style={{ color: "var(--v2-gold-dim)" }}>
        {committed} committed
      </div>
    </div>
  );
}

/* ============================================================ */
/* WORKSPACE — split-pane (≥768) / stacked (<768)              */
/* ============================================================ */
function Workspace({ mode }: { mode: Mode }) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "calc(100dvh - 44px)",
        position: "relative",
      }}
    >
      <WorkspaceHeader />

      <div className="v2-workspace-body">
        <div className="v2-pane v2-pane-left v2-glow-bg">
          <ChatPane mode={mode} />
        </div>
        <div className="v2-pane-divider" />
        <div className="v2-pane v2-pane-right">
          <IntelPanel mode={mode} />
        </div>
      </div>

      <CommandDock />

      <style>{`
        .v2-workspace-body {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
        .v2-pane { min-height: 0; position: relative; }
        .v2-pane-left { flex: 1; border-bottom: 0.5px solid var(--v2-border); }
        .v2-pane-right { height: 42dvh; }
        .v2-pane-divider { display: none; }

        @media (min-width: 768px) {
          .v2-workspace-body { flex-direction: row; }
          .v2-pane-left {
            flex: 0 0 auto;
            width: 520px;
            min-width: 380px;
            max-width: 70%;
            border-bottom: 0;
            border-right: 0.5px solid var(--v2-border);
          }
          .v2-pane-right { flex: 1; height: auto; }
          .v2-pane-divider {
            display: block;
            width: 1px;
            background: linear-gradient(to bottom, transparent, rgba(201,162,76,0.25), transparent);
            cursor: col-resize;
          }
        }
      `}</style>
    </div>
  );
}

function WorkspaceHeader() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "12px 18px",
        borderBottom: "0.5px solid var(--v2-border)",
        background: "rgba(12,10,9,0.85)",
      }}
    >
      <div
        style={{
          width: 22,
          height: 22,
          border: "1px solid var(--v2-gold)",
          transform: "rotate(45deg)",
        }}
      />
      <span className="v2-h" style={{ fontSize: 12 }}>
        Axiom
      </span>
      <span style={{ color: "var(--v2-muted)", fontSize: 12 }}>·</span>
      <span style={{ color: "var(--v2-text)", fontSize: 13 }}>Strategic Intelligence</span>
      <div style={{ flex: 1 }} />
      <span
        className="v2-mono"
        style={{
          padding: "4px 10px",
          border: "0.5px solid rgba(201,162,76,0.4)",
          color: "var(--v2-gold)",
        }}
      >
        ● Session active
      </span>
    </div>
  );
}

/* ---------------- LEFT PANE — Chat ---------------- */
function ChatPane({ mode }: { mode: Mode }) {
  const messages =
    mode === "populated"
      ? [
          { role: "system" as const, text: "Welcome back. You committed yesterday to shipping without auth in v1. Where do you want to start?" },
          { role: "user" as const, text: "Actually I'm rethinking — I want to add Google sign-in before launch." },
          { role: "catch" as const },
          { role: "user" as const, text: "You're right. Defer auth. Let's lock the lead-capture form instead." },
        ]
      : [
          { role: "system" as const, text: "Welcome to Axiom. Before we build anything — what are you working on, and what's the real goal?" },
        ];

  return (
    <div style={{ position: "relative", zIndex: 1, height: "100%", display: "flex", flexDirection: "column" }}>
      <div
        style={{
          flex: 1,
          overflow: "auto",
          padding: "20px 18px 80px",
          display: "flex",
          flexDirection: "column",
          gap: 14,
        }}
      >
        {messages.map((m, i) => {
          if (m.role === "catch") return <DecisionCatchCard key={i} />;
          return <ChatBubble key={i} role={m.role} text={m.text} />;
        })}
      </div>
    </div>
  );
}

function ChatBubble({ role, text }: { role: "user" | "system"; text: string }) {
  const isUser = role === "user";
  return (
    <div style={{ display: "flex", justifyContent: isUser ? "flex-end" : "flex-start" }}>
      <div
        style={{
          maxWidth: "82%",
          padding: "12px 16px",
          fontSize: 15,
          lineHeight: 1.55,
          color: "var(--v2-text)",
          background: isUser ? "rgba(201,162,76,0.08)" : "rgba(28,25,23,0.7)",
          border: `0.5px solid ${isUser ? "rgba(201,162,76,0.30)" : "var(--v2-border)"}`,
          backdropFilter: "blur(10px)",
        }}
      >
        {text}
      </div>
    </div>
  );
}

function DecisionCatchCard() {
  return (
    <div
      className="v2-pulse-ember"
      style={{
        padding: "16px 18px",
        background: "rgba(146, 64, 14, 0.12)",
        borderLeft: "2px solid var(--v2-ember)",
        border: "0.5px solid rgba(146,64,14,0.45)",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 14 }}>⚡</span>
        <span
          className="v2-mono"
          style={{ color: "var(--v2-ember)", letterSpacing: "0.22em" }}
        >
          Decision Catch
        </span>
      </div>
      <div style={{ fontSize: 14, lineHeight: 1.55, color: "var(--v2-text)" }}>
        You committed to shipping without auth in v1. This contradicts that.
      </div>
      <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
        <button
          style={{
            padding: "8px 14px",
            fontSize: 12,
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            background: "transparent",
            color: "var(--v2-muted)",
            border: "0.5px solid var(--v2-border)",
            cursor: "pointer",
          }}
        >
          Proceed anyway
        </button>
        <button
          style={{
            padding: "8px 14px",
            fontSize: 12,
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            background: "rgba(201,162,76,0.12)",
            color: "var(--v2-gold)",
            border: "0.5px solid rgba(201,162,76,0.55)",
            cursor: "pointer",
          }}
        >
          Adjust
        </button>
      </div>
    </div>
  );
}

/* ---------------- RIGHT PANE — Intel + Map + Ledger tabs ---------------- */
function IntelPanel({ mode }: { mode: Mode }) {
  const [tab, setTab] = useState<"flow" | "ledger" | "memory">("flow");

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div
        style={{
          display: "flex",
          gap: 0,
          borderBottom: "0.5px solid var(--v2-border)",
        }}
      >
        {(["flow", "ledger", "memory"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              flex: 1,
              padding: "12px 0",
              fontSize: 11,
              letterSpacing: "0.20em",
              textTransform: "uppercase",
              background: "transparent",
              color: tab === t ? "var(--v2-gold)" : "var(--v2-muted)",
              border: 0,
              borderBottom: `1px solid ${tab === t ? "var(--v2-gold)" : "transparent"}`,
              cursor: "pointer",
            }}
          >
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
        {tab === "flow" && <FlowTab mode={mode} />}
        {tab === "ledger" && <LedgerTab mode={mode} />}
        {tab === "memory" && <MemoryTab mode={mode} />}
      </div>
    </div>
  );
}

/* --- Flow tab: the Mission Map --- */
function FlowTab({ mode }: { mode: Mode }) {
  return (
    <div
      className="v2-glow-bg"
      style={{ position: "relative", height: "100%", overflow: "hidden", background: "var(--v2-canvas)" }}
    >
      <MissionCanvas mode={mode} />
    </div>
  );
}

function MissionCanvas({ mode }: { mode: Mode }) {
  // Coordinate space — same for both states; populated overlays nodes
  const W = 600;
  const H = 480;

  const nodes =
    mode === "populated"
      ? [
          { id: "g",  type: "goal" as const,        label: "Ship lead-funnel v1", x: 300, y: 230 },
          { id: "m1", type: "must" as const,        label: "Lead capture form",    x: 130, y: 110 },
          { id: "m2", type: "must" as const,        label: "Email sequence",        x: 470, y: 110 },
          { id: "b",  type: "blocker" as const,     label: "Domain + DNS",          x: 110, y: 360 },
          { id: "d",  type: "decision" as const,    label: "Defer auth to v2",      x: 470, y: 360 },
          { id: "s",  type: "sprint" as const,      label: "Sprint 1 — this week",  x: 300, y: 410 },
        ]
      : [
          { id: "g", type: "goal" as const, label: "Define the goal", x: 300, y: 230 },
        ];

  const edges =
    mode === "populated"
      ? [
          ["g", "m1"], ["g", "m2"], ["g", "b"], ["g", "d"], ["g", "s"],
        ]
      : [];

  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="xMidYMid meet"
      style={{ width: "100%", height: "100%", display: "block", position: "relative", zIndex: 1 }}
    >
      {edges.map(([a, b], i) => (
        <line
          key={i}
          className="v2-edge"
          x1={byId[a].x}
          y1={byId[a].y}
          x2={byId[b].x}
          y2={byId[b].y}
        />
      ))}
      {nodes.map((n) => (
        <NodeOrb key={n.id} {...n} />
      ))}
      {mode === "empty" && (
        <text
          x={W / 2}
          y={H - 40}
          textAnchor="middle"
          fill="var(--v2-muted)"
          fontSize="11"
          letterSpacing="3"
          style={{ textTransform: "uppercase" }}
        >
          Drop a brain dump in the dock — Axiom will populate the map
        </text>
      )}
    </svg>
  );
}

function NodeOrb({
  type,
  label,
  x,
  y,
}: {
  type: "goal" | "must" | "blocker" | "decision" | "sprint";
  label: string;
  x: number;
  y: number;
}) {
  const stroke =
    type === "blocker" ? "#92400E" :
    type === "decision" ? "#B4651A" :
    "#C9A24C";
  const strokeWidth = type === "goal" ? 1.2 : 0.6;
  const fill = "rgba(28,25,23,0.65)";
  const filter =
    type === "goal" ? "drop-shadow(0 0 14px rgba(201,162,76,0.55))" :
    type === "blocker" ? "drop-shadow(0 0 10px rgba(146,64,14,0.65))" :
    type === "must" ? "drop-shadow(0 0 8px rgba(201,162,76,0.35))" :
    "drop-shadow(0 0 6px rgba(168,162,158,0.25))";

  // Shape per spec
  const shape =
    type === "goal" ? <circle cx={x} cy={y} r={42} fill={fill} stroke={stroke} strokeWidth={strokeWidth} /> :
    type === "blocker" ? (
      <polygon
        points={`${x},${y - 28} ${x + 28},${y} ${x},${y + 28} ${x - 28},${y}`}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
      />
    ) :
    type === "decision" ? (
      <polygon
        points={hexPoints(x, y, 26).join(" ")}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
      />
    ) :
    type === "sprint" ? (
      <rect x={x - 50} y={y - 16} width={100} height={32} rx={2} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeDasharray="3 3" />
    ) : (
      <rect x={x - 56} y={y - 20} width={112} height={40} rx={2} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />
    );

  return (
    <g style={{ filter }}>
      {shape}
      <text
        x={x}
        y={y + 4}
        textAnchor="middle"
        fill="#E7E5E4"
        fontSize="11"
        fontFamily="Inter, sans-serif"
        style={{ letterSpacing: "0.04em", pointerEvents: "none" }}
      >
        {label}
      </text>
      {type === "goal" && (
        <text
          x={x}
          y={y - 54}
          textAnchor="middle"
          fill="#C9A24C"
          fontSize="9"
          letterSpacing="3"
          style={{ textTransform: "uppercase" }}
        >
          Goal
        </text>
      )}
    </g>
  );
}

function hexPoints(cx: number, cy: number, r: number) {
  const pts: string[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 3) * i + Math.PI / 6;
    pts.push(`${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`);
  }
  return pts;
}

/* --- Ledger tab --- */
function LedgerTab({ mode }: { mode: Mode }) {
  const entries =
    mode === "populated"
      ? [
          { status: "committed" as const, title: "Ship without auth in v1", date: "May 7", note: "Speed > polish for first 100 users." },
          { status: "tension" as const,   title: "Add Google sign-in",      date: "today", note: "Conflicts with auth-deferral." },
          { status: "overridden" as const,title: "Switch to Postgres",      date: "May 2", note: "Reason: Supabase free tier limits." },
        ]
      : [];

  if (entries.length === 0) {
    return (
      <div style={{ padding: 24, color: "var(--v2-muted)", fontSize: 13 }}>
        Nothing committed yet. Decisions you lock in will live here — and Axiom
        will catch you if you contradict them later.
      </div>
    );
  }

  return (
    <div style={{ padding: "16px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
        {["All", "Committed", "Tension", "Overridden"].map((p, i) => (
          <span
            key={p}
            style={{
              padding: "4px 10px",
              fontSize: 10,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              border: `0.5px solid ${i === 0 ? "rgba(201,162,76,0.55)" : "var(--v2-border)"}`,
              color: i === 0 ? "var(--v2-gold)" : "var(--v2-muted)",
            }}
          >
            {p}
          </span>
        ))}
      </div>
      {entries.map((e, i) => (
        <LedgerEntry key={i} {...e} />
      ))}
    </div>
  );
}

function LedgerEntry({
  status,
  title,
  date,
  note,
}: {
  status: "committed" | "tension" | "overridden";
  title: string;
  date: string;
  note: string;
}) {
  const dot =
    status === "committed" ? "var(--v2-gold)" :
    status === "tension" ? "var(--v2-amber)" :
    "var(--v2-muted)";
  const border =
    status === "committed" ? "rgba(201,162,76,0.55)" :
    status === "tension" ? "rgba(180,101,26,0.55)" :
    "var(--v2-border)";

  return (
    <div
      style={{
        padding: "12px 14px",
        background: "rgba(28,25,23,0.6)",
        borderLeft: `2px solid ${border}`,
        border: "0.5px solid var(--v2-border)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            background: dot,
            boxShadow: `0 0 8px ${dot}`,
          }}
        />
        <span style={{ fontSize: 14, color: "var(--v2-text)", fontWeight: 500, flex: 1 }}>
          {title}
        </span>
        <span className="v2-mono" style={{ color: "var(--v2-muted)" }}>
          {date}
        </span>
      </div>
      <div style={{ fontSize: 12, color: "var(--v2-muted)", marginTop: 6, lineHeight: 1.5 }}>
        {note}
      </div>
    </div>
  );
}

/* --- Memory tab --- */
function MemoryTab({ mode }: { mode: Mode }) {
  const lines =
    mode === "populated"
      ? [
          "Founder ships solo on a Z Fold 6, prefers split-pane UIs.",
          "Backend is Replit + Claude Sonnet via /api/chat.",
          "First 100 users come from a lead funnel, not paid ads.",
          "Auth deferred to v2 — committed May 7.",
          "Stack: React, Express, Postgres on Supabase free tier.",
        ]
      : [];

  return (
    <div style={{ padding: 18 }}>
      <div className="v2-mono" style={{ marginBottom: 14 }}>
        What Axiom remembers
      </div>
      {lines.length === 0 ? (
        <div style={{ color: "var(--v2-muted)", fontSize: 13, lineHeight: 1.6 }}>
          Empty. As you commit decisions and answer strategic questions, Axiom
          will keep a running ledger of facts about this project that persist
          across sessions.
        </div>
      ) : (
        <ul style={{ display: "flex", flexDirection: "column", gap: 10, listStyle: "none", padding: 0, margin: 0 }}>
          {lines.map((l, i) => (
            <li
              key={i}
              style={{
                fontSize: 14,
                color: "var(--v2-text)",
                lineHeight: 1.55,
                paddingLeft: 16,
                borderLeft: "1px solid rgba(201,162,76,0.25)",
              }}
            >
              {l}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------------- Command Dock ---------------- */
function CommandDock() {
  return (
    <div
      style={{
        position: "sticky",
        bottom: 0,
        padding: "12px 14px max(env(safe-area-inset-bottom), 12px)",
        background: "linear-gradient(to top, rgba(12,10,9,0.95), rgba(12,10,9,0.6))",
        borderTop: "0.5px solid var(--v2-border)",
        zIndex: 5,
      }}
    >
      <div
        className="v2-input-breathe"
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "12px 16px",
          background: "rgba(28,25,23,0.7)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(201,162,76,0.45)",
        }}
      >
        <span style={{ color: "var(--v2-gold)", fontSize: 16, fontFamily: "monospace" }}>›</span>
        <input
          placeholder="Type to think · /must  /blocker  /decision  /forge"
          readOnly
        />
      </div>
    </div>
  );
}
