import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  component: TermsPage,
  head: () => ({
    meta: [
      { title: "Terms & Conditions — Axiom" },
      { name: "description", content: "Terms and conditions for using the Axiom Structural Specification Engine." },
    ],
  }),
});

function TermsPage() {
  return (
    <div className="min-h-screen" style={{ background: "#0D0B09", color: "rgba(212,175,55,0.85)" }}>
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link to="/" className="text-xs font-bold tracking-[0.15em] hover:underline" style={{ color: "#D4AF37" }}>
          ← BACK TO AXIOM
        </Link>

        <h1 className="text-3xl font-bold mt-8 mb-2" style={{ color: "#D4AF37" }}>Terms & Conditions</h1>
        <p className="text-xs mb-10" style={{ color: "rgba(212,175,55,0.5)" }}>Last updated: May 6, 2026</p>

        <div className="space-y-8 text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.7)" }}>
          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>1. Acceptance of Terms</h2>
            <p>By accessing or using Axiom, a product of Into Innovations LLC, you agree to be bound by these Terms & Conditions. If you do not agree, do not use the service.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>2. Description of Service</h2>
            <p>Axiom is a Structural Specification Engine that transforms unstructured project ideas into organized, actionable specifications. The service includes AI-assisted chat, system mapping, project profiling, and specification export capabilities.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>3. User Accounts</h2>
            <p>You must create an account to use Axiom. You are responsible for maintaining the confidentiality of your login credentials and for all activities under your account. You must notify us immediately of any unauthorized use.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>4. Acceptable Use</h2>
            <p>You agree not to misuse the service. This includes but is not limited to: attempting to gain unauthorized access, using the service to generate harmful content, reverse-engineering the platform, or violating any applicable laws.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>5. Intellectual Property</h2>
            <p>All specifications, architectures, and outputs you create using Axiom remain your intellectual property. The Axiom platform, its branding, code, and design are the property of Into Innovations LLC.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>6. Subscription & Payments</h2>
            <p>Certain features may require a paid subscription. Pricing, billing cycles, and tier benefits will be communicated at the point of purchase. Refund policies will be outlined in the subscription agreement.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>7. Limitation of Liability</h2>
            <p>Axiom is provided "as is" without warranty of any kind. Into Innovations LLC shall not be liable for any indirect, incidental, or consequential damages arising from your use of the service.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>8. Termination</h2>
            <p>We reserve the right to suspend or terminate your account at our discretion if you violate these terms. You may terminate your account at any time by contacting support.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>9. Changes to Terms</h2>
            <p>We may update these terms from time to time. Continued use of Axiom after changes constitutes acceptance of the updated terms.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>10. Contact</h2>
            <p>For questions regarding these terms, contact us at <a href="mailto:support@intoinnovations.com" className="underline" style={{ color: "#D4AF37" }}>support@intoinnovations.com</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
