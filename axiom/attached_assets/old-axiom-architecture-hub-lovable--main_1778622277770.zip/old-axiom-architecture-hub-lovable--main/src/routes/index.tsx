import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AxiomProvider } from "@/hooks/use-axiom-store";
import { AxiomLayout } from "@/components/axiom/AxiomLayout";
import { AuthScreen } from "@/components/axiom/AuthScreen";
import { LandingPage } from "@/components/axiom/LandingPage";
import { LoadingSpinner } from "@/components/axiom/LoadingSpinner";
import type { Session } from "@supabase/supabase-js";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Axiom — Structural Specification Engine" },
      { name: "description", content: "Run it through Axiom, then send it to Atlas. Turn unstructured ideas into complete architecture." },
    ],
  }),
});

function Index() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWelcome, setShowWelcome] = useState(false);
  const [welcomeName, setWelcomeName] = useState("");
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, newSession) => {
        setSession(newSession);
        setLoading(false);

        if (event === "SIGNED_IN" && newSession) {
          setShowAuth(false);
          const meta = newSession.user;
          const created = new Date(meta.created_at).getTime();
          const lastSignIn = meta.last_sign_in_at
            ? new Date(meta.last_sign_in_at).getTime()
            : created;
          const isNew = Math.abs(lastSignIn - created) < 10000;

          if (isNew) {
            const name =
              meta.user_metadata?.full_name ||
              meta.user_metadata?.name ||
              meta.email?.split("@")[0] ||
              "there";
            setWelcomeName(name);
            setShowWelcome(true);
            setTimeout(() => setShowWelcome(false), 2500);
          }
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0D0B09" }}>
        <LoadingSpinner size="lg" text="Initializing Axiom..." />
      </div>
    );
  }

  if (!session) {
    if (showAuth) {
      return <AuthScreen />;
    }
    return <LandingPage onEnter={() => setShowAuth(true)} />;
  }

  if (showWelcome) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0D0B09" }}>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "radial-gradient(ellipse 70% 60% at 50% 50%, rgba(128,90,213,0.15) 0%, transparent 70%)",
          }}
        />
        <div className="relative z-10 text-center animate-ghost-type">
          <h1 className="text-xl font-semibold" style={{ color: "#D4AF37" }}>
            Welcome to Axiom, {welcomeName}.
          </h1>
        </div>
      </div>
    );
  }

  return (
    <AxiomProvider>
      <AxiomLayout />
    </AxiomProvider>
  );
}
