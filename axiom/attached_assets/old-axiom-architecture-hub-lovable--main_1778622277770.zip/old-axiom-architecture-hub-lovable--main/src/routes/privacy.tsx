import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
  head: () => ({
    meta: [
      { title: "Privacy Policy — Axiom" },
      { name: "description", content: "Privacy policy for the Axiom Structural Specification Engine by Into Innovations." },
    ],
  }),
});

function PrivacyPage() {
  return (
    <div className="min-h-screen" style={{ background: "#0D0B09", color: "rgba(212,175,55,0.85)" }}>
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link to="/" className="text-xs font-bold tracking-[0.15em] hover:underline" style={{ color: "#D4AF37" }}>
          ← BACK TO AXIOM
        </Link>

        <h1 className="text-3xl font-bold mt-8 mb-2" style={{ color: "#D4AF37" }}>Privacy Policy</h1>
        <p className="text-xs mb-10" style={{ color: "rgba(212,175,55,0.5)" }}>Last updated: May 6, 2026</p>

        <div className="space-y-8 text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.7)" }}>
          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>1. Information We Collect</h2>
            <p>We collect information you provide directly: name, email address, and account credentials. We also collect usage data including specifications created, chat interactions, and session metadata to improve the service.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>2. How We Use Your Information</h2>
            <ul className="list-disc list-inside space-y-1">
              <li>To provide and maintain the Axiom service</li>
              <li>To personalize your experience and improve AI-assisted features</li>
              <li>To communicate service updates and support</li>
              <li>To detect and prevent fraud or abuse</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>3. Data Storage & Security</h2>
            <p>Your project data, specifications, and chat history are stored securely using industry-standard encryption. We use authenticated database access with row-level security to ensure only you can access your data.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>4. Third-Party Services</h2>
            <p>Axiom uses third-party AI models to power its specification engine. Your prompts and project context may be processed by these services. We do not sell your personal data to third parties.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>5. Cookies & Analytics</h2>
            <p>We use essential cookies for authentication and session management. We may use analytics to understand usage patterns and improve the platform.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>6. Your Rights</h2>
            <ul className="list-disc list-inside space-y-1">
              <li>Access, update, or delete your personal data</li>
              <li>Export your project specifications at any time</li>
              <li>Request account deletion</li>
              <li>Opt out of non-essential communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>7. Data Retention</h2>
            <p>We retain your data for as long as your account is active. Upon account deletion, your data will be permanently removed within 30 days.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>8. Children's Privacy</h2>
            <p>Axiom is not intended for users under the age of 13. We do not knowingly collect data from children.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>9. Changes to This Policy</h2>
            <p>We may update this policy periodically. We will notify you of significant changes via email or in-app notification.</p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3" style={{ color: "#D4AF37" }}>10. Contact</h2>
            <p>For privacy-related inquiries, contact us at <a href="mailto:privacy@intoinnovations.com" className="underline" style={{ color: "#D4AF37" }}>privacy@intoinnovations.com</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
