import { createFileRoute } from "@tanstack/react-router";
import { AxiomProvider } from "@/hooks/use-axiom-store";
import { VaultGrid } from "@/components/axiom/VaultGrid";

export const Route = createFileRoute("/vault")({
  component: VaultPage,
  head: () => ({
    meta: [
      { title: "The Vault — Axiom Legacy Log" },
      { name: "description", content: "Browse past architectural specifications from the Gold Vault." },
    ],
  }),
});

function VaultPage() {
  return (
    <AxiomProvider>
      <div className="min-h-screen bg-background">
        <VaultGrid />
      </div>
    </AxiomProvider>
  );
}
