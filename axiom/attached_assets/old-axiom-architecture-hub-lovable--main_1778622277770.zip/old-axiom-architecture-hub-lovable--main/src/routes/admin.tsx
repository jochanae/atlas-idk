import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { LoadingSpinner } from "@/components/axiom/LoadingSpinner";
import type { Session } from "@supabase/supabase-js";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
  head: () => ({
    meta: [
      { title: "Admin Hub — Axiom" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
});

interface Stats {
  totalUsers: number;
  totalProjects: number;
  totalArchitectures: number;
  totalLegacyLogs: number;
}

interface UserRow {
  user_id: string;
  email: string;
  created_at: string;
  last_sign_in: string | null;
  project_count: number;
}

function AdminPage() {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"overview" | "users" | "projects" | "settings">("overview");
  const [stats, setStats] = useState<Stats>({ totalUsers: 0, totalProjects: 0, totalArchitectures: 0, totalLegacyLogs: 0 });
  const [users, setUsers] = useState<UserRow[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      if (s) checkAdmin(s.user.id);
      else setLoading(false);
    });
  }, []);

  const checkAdmin = async (userId: string) => {
    try {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin")
        .limit(1);
      const admin = !!(data && data.length > 0);
      setIsAdmin(admin);
      if (admin) {
        await fetchStats();
        await fetchUsers();
      }
    } catch (e) {
      console.error("Admin check error:", e);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    const [proj, arch, logs] = await Promise.all([
      supabase.from("projects").select("id", { count: "exact", head: true }),
      supabase.from("architectures").select("id", { count: "exact", head: true }),
      supabase.from("legacy_log").select("id", { count: "exact", head: true }),
    ]);
    setStats({
      totalUsers: 0, // will be set by user count
      totalProjects: proj.count || 0,
      totalArchitectures: arch.count || 0,
      totalLegacyLogs: logs.count || 0,
    });
  };

  const fetchUsers = async () => {
    // Fetch all projects grouped by user for the user list
    const { data: projects } = await supabase
      .from("projects")
      .select("user_id, created_at")
      .order("created_at", { ascending: false });

    if (projects) {
      const userMap = new Map<string, { count: number; earliest: string }>();
      projects.forEach((p) => {
        const existing = userMap.get(p.user_id);
        if (existing) {
          existing.count++;
        } else {
          userMap.set(p.user_id, { count: 1, earliest: p.created_at });
        }
      });

      const rows: UserRow[] = Array.from(userMap.entries()).map(([uid, info]) => ({
        user_id: uid,
        email: uid.slice(0, 8) + "...",
        created_at: info.earliest,
        last_sign_in: null,
        project_count: info.count,
      }));

      setUsers(rows);
      setStats((s) => ({ ...s, totalUsers: rows.length }));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0D0B09" }}>
        <LoadingSpinner size="lg" text="Verifying access..." />
      </div>
    );
  }

  if (!session || !isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center" style={{ background: "#0D0B09" }}>
        <div className="text-center">
          <div className="text-4xl mb-4">🛡️</div>
          <h2 className="text-xl font-bold mb-2" style={{ color: "#D4AF37" }}>Access Denied</h2>
          <p className="text-sm mb-6" style={{ color: "rgba(255,255,255,0.5)" }}>
            You don't have admin privileges.
          </p>
          <Link to="/" className="text-xs font-bold tracking-[0.15em] underline" style={{ color: "#D4AF37" }}>
            ← BACK TO AXIOM
          </Link>
        </div>
      </div>
    );
  }

  const tabs = [
    { key: "overview" as const, label: "Overview", icon: "◆" },
    { key: "users" as const, label: "Users", icon: "👤" },
    { key: "projects" as const, label: "Projects", icon: "📁" },
    { key: "settings" as const, label: "Settings", icon: "⚙️" },
  ];

  return (
    <div className="min-h-screen" style={{ background: "#0D0B09" }}>
      {/* Header */}
      <div
        className="px-5 pt-6 pb-5"
        style={{
          background: "linear-gradient(135deg, rgba(212,175,55,0.15) 0%, rgba(128,90,213,0.1) 50%, rgba(212,175,55,0.05) 100%)",
          borderBottom: "1px solid rgba(212,175,55,0.2)",
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          <Link to="/" className="text-xs font-bold tracking-[0.15em]" style={{ color: "#D4AF37" }}>
            ← AXIOM
          </Link>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-2xl">🛡️</span>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: "#D4AF37" }}>Admin Hub</h1>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
              Manage users, projects, and platform settings
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b" style={{ borderColor: "rgba(212,175,55,0.15)" }}>
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="flex items-center gap-1.5 px-4 py-3 text-xs font-semibold transition-colors"
            style={{
              color: tab === t.key ? "#D4AF37" : "rgba(255,255,255,0.4)",
              borderBottom: tab === t.key ? "2px solid #D4AF37" : "2px solid transparent",
            }}
          >
            <span>{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="px-5 py-6">
        {tab === "overview" && (
          <div className="space-y-5">
            {/* Stats cards */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "Users", value: stats.totalUsers, icon: "👤", color: "#D4AF37" },
                { label: "Projects", value: stats.totalProjects, icon: "📁", color: "#805AD5" },
                { label: "Architectures", value: stats.totalArchitectures, icon: "🏗️", color: "#D4AF37" },
                { label: "Legacy Logs", value: stats.totalLegacyLogs, icon: "📝", color: "#805AD5" },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-lg p-4"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(212,175,55,0.15)",
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg">{s.icon}</span>
                    <span className="text-xs font-bold" style={{ color: "rgba(255,255,255,0.4)" }}>
                      {s.label}
                    </span>
                  </div>
                  <p className="text-2xl font-bold" style={{ color: s.color }}>
                    {s.value}
                  </p>
                </div>
              ))}
            </div>

            {/* Quick actions */}
            <div>
              <h3 className="text-sm font-semibold mb-3" style={{ color: "#D4AF37" }}>Quick Actions</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "User Monitoring", desc: "View active users", onClick: () => setTab("users") },
                  { label: "Project Data", desc: "Browse all projects", onClick: () => setTab("projects") },
                  { label: "Platform Settings", desc: "Configure Axiom", onClick: () => setTab("settings") },
                  { label: "View Site", desc: "Back to Axiom", onClick: () => navigate({ to: "/" }) },
                ].map((a) => (
                  <button
                    key={a.label}
                    onClick={a.onClick}
                    className="rounded-lg p-4 text-left transition-colors hover:bg-white/5"
                    style={{
                      background: "rgba(255,255,255,0.02)",
                      border: "1px solid rgba(212,175,55,0.1)",
                    }}
                  >
                    <p className="text-sm font-semibold" style={{ color: "#D4AF37" }}>{a.label}</p>
                    <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>{a.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "users" && (
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-lg px-4 py-2.5 text-sm"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(212,175,55,0.2)",
                color: "rgba(255,255,255,0.8)",
                outline: "none",
              }}
            />
            <div className="space-y-2">
              {users
                .filter((u) => u.user_id.includes(searchQuery) || u.email.includes(searchQuery))
                .map((u) => (
                  <div
                    key={u.user_id}
                    className="rounded-lg p-4 flex items-center justify-between"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(212,175,55,0.1)",
                    }}
                  >
                    <div>
                      <p className="text-xs font-mono" style={{ color: "rgba(255,255,255,0.6)" }}>
                        {u.user_id}
                      </p>
                      <p className="text-xs mt-1" style={{ color: "rgba(212,175,55,0.5)" }}>
                        {u.project_count} project{u.project_count !== 1 ? "s" : ""}
                      </p>
                    </div>
                    <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                      {new Date(u.created_at).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              {users.length === 0 && (
                <p className="text-center text-sm py-8" style={{ color: "rgba(255,255,255,0.3)" }}>
                  No user data available
                </p>
              )}
            </div>
          </div>
        )}

        {tab === "projects" && (
          <div className="space-y-3">
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              Total projects across all users: <strong style={{ color: "#D4AF37" }}>{stats.totalProjects}</strong>
            </p>
            <p className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
              Project browsing will be available in a future update. Use the database backend to inspect project data directly.
            </p>
          </div>
        )}

        {tab === "settings" && (
          <div className="space-y-6">
            <div
              className="rounded-lg p-5"
              style={{
                background: "rgba(212,175,55,0.05)",
                border: "1px solid rgba(212,175,55,0.15)",
              }}
            >
              <h3 className="text-sm font-semibold mb-2" style={{ color: "#D4AF37" }}>Platform Info</h3>
              <div className="space-y-2 text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
                <p>Product: <strong style={{ color: "#D4AF37" }}>Axiom</strong> — Structural Specification Engine</p>
                <p>Company: <strong style={{ color: "#D4AF37" }}>Into Innovations LLC</strong></p>
                <p>Super Admin: <strong style={{ color: "#D4AF37" }}>jochanae@gmail.com</strong></p>
              </div>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                background: "rgba(128,90,213,0.05)",
                border: "1px solid rgba(128,90,213,0.15)",
              }}
            >
              <h3 className="text-sm font-semibold mb-2" style={{ color: "#805AD5" }}>Feature Flags</h3>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
                Feature flag management will be available in a future update.
              </p>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <h3 className="text-sm font-semibold mb-2" style={{ color: "#D4AF37" }}>Subscription Tiers</h3>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
                Pricing and subscription management will be configured here once payment integration is enabled.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
