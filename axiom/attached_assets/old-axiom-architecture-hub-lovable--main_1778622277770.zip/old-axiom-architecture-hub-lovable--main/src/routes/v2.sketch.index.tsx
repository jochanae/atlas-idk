import { createFileRoute } from "@tanstack/react-router";
import { SketchShell } from "@/components/axiom-v2/sketch/SketchShell";

export const Route = createFileRoute("/v2/sketch/")({
  head: () => ({
    meta: [
      { title: "Axiom V2 — Sketch (Empty)" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <SketchShell mode="empty" />,
});
