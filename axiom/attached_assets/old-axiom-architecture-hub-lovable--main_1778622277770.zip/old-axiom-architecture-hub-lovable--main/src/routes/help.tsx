import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/help")({
  component: HelpPage,
  head: () => ({
    meta: [
      { title: "Help & FAQ — Axiom" },
      { name: "description", content: "Frequently asked questions and help for the Axiom Structural Specification Engine." },
    ],
  }),
});

const faqs = [
  {
    q: "What is Axiom?",
    a: "Axiom is a Structural Specification Engine by Into Innovations. It transforms unstructured project ideas into complete, organized architectural specifications using AI-assisted conversation.",
  },
  {
    q: "How does the System Map work?",
    a: "The System Map is a real-time visual representation of your project's architecture. As you answer questions and provide details in the chat, nodes appear and connect on the map, showing your project's structure evolve in real time.",
  },
  {
    q: "What is the Readiness Score?",
    a: "The Readiness Score (0–100%) indicates how complete your specification is. It considers factors like tech stack definition, file structure, user flows, and architectural decisions. A higher score means your spec is more ready for development.",
  },
  {
    q: "Can I save and return to a project?",
    a: "Yes! Your projects are saved to your account automatically. Use the folder icon (◆) in the header to access your saved projects and switch between them.",
  },
  {
    q: "What is the Quick Prompt Generator?",
    a: "The Quick Prompt Generator creates structured prompts from your specifications that you can use with AI coding tools like Lovable, Cursor, or Replit to build your project.",
  },
  {
    q: "What builders does Axiom support?",
    a: "Axiom currently supports Lovable, Cursor, and Replit as target builders. Each builder gets a customized prompt format optimized for its platform.",
  },
  {
    q: "How do I export my specification?",
    a: "Open the Cockpit Bar at the bottom of the screen and use the export options. You can copy your spec as text, download it, or generate builder-specific prompts.",
  },
  {
    q: "What is Atlas?",
    a: "Atlas is a companion workspace where you can manage and refine your projects after specification. When your Axiom spec is ready, you can send it to Atlas for the next phase of your workflow.",
  },
  {
    q: "Is my data secure?",
    a: "Yes. All project data is stored with row-level security, meaning only you can access your projects. We use industry-standard encryption and authentication.",
  },
  {
    q: "How do I contact support?",
    a: "Email us at support@intoinnovations.com or reach out through our social channels. We're here to help.",
  },
];

function HelpPage() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <div className="min-h-screen" style={{ background: "#0D0B09", color: "rgba(212,175,55,0.85)" }}>
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link to="/" className="text-xs font-bold tracking-[0.15em] hover:underline" style={{ color: "#D4AF37" }}>
          ← BACK TO AXIOM
        </Link>

        <h1 className="text-3xl font-bold mt-8 mb-2" style={{ color: "#D4AF37" }}>Help & FAQ</h1>
        <p className="text-sm mb-10" style={{ color: "rgba(255,255,255,0.5)" }}>
          Find answers to common questions about using Axiom.
        </p>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-lg overflow-hidden transition-colors"
              style={{
                background: open === i ? "rgba(212,175,55,0.08)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${open === i ? "rgba(212,175,55,0.3)" : "rgba(255,255,255,0.06)"}`,
              }}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full text-left px-5 py-4 flex items-center justify-between gap-4"
              >
                <span className="text-sm font-medium" style={{ color: "#D4AF37" }}>
                  {faq.q}
                </span>
                <span
                  className="text-xs shrink-0 transition-transform"
                  style={{
                    color: "rgba(212,175,55,0.5)",
                    transform: open === i ? "rotate(180deg)" : "rotate(0deg)",
                  }}
                >
                  ▼
                </span>
              </button>
              {open === i && (
                <div className="px-5 pb-4 text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>

        <div
          className="mt-12 rounded-lg p-6 text-center"
          style={{
            background: "rgba(212,175,55,0.06)",
            border: "1px solid rgba(212,175,55,0.2)",
          }}
        >
          <p className="text-sm font-semibold mb-2" style={{ color: "#D4AF37" }}>
            Still need help?
          </p>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
            Contact us at{" "}
            <a href="mailto:support@intoinnovations.com" className="underline" style={{ color: "#D4AF37" }}>
              support@intoinnovations.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
