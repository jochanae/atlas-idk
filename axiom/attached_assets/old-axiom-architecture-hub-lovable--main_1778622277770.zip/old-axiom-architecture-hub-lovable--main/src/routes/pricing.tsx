import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { StripeEmbeddedCheckout } from "@/components/StripeEmbeddedCheckout";
import type { Session } from "@supabase/supabase-js";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Pricing — Axiom Structural Specification Engine" },
      { name: "description", content: "Choose the plan that fits your engineering workflow. From solo builders to enterprise teams." },
    ],
  }),
});

const tiers = [
  {
    name: "Free",
    price: "$0",
    interval: "",
    description: "Explore the engine",
    features: [
      "3 sessions per month",
      "Basic manifest export",
      "Community access",
    ],
    cta: "Get Started",
    priceId: null,
    highlight: false,
  },
  {
    name: "Pro",
    price: "$19",
    interval: "/mo",
    description: "For serious builders",
    features: [
      "Unlimited sessions",
      "Vault saves & versioning",
      "Full manifest export",
      "Priority AI calibration",
      "MoSCoW prioritization",
    ],
    cta: "Upgrade to Pro",
    priceId: "pro_monthly",
    highlight: true,
  },
  {
    name: "Teams",
    price: "$49",
    interval: "/seat/mo",
    description: "For engineering squads",
    features: [
      "Everything in Pro",
      "Shared vaults",
      "Role-based access",
      "Team dashboards",
      "Collaborative specs",
    ],
    cta: "Start with Teams",
    priceId: "teams_monthly",
    highlight: false,
  },
  {
    name: "Enterprise",
    price: "Custom",
    interval: "",
    description: "For organizations at scale",
    features: [
      "Everything in Teams",
      "Private deployment",
      "Custom system prompts",
      "Priority support & SLA",
      "SSO & audit logging",
    ],
    cta: "Contact Us",
    priceId: null,
    highlight: false,
    isEnterprise: true,
  },
];

function PricingPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [checkoutPriceId, setCheckoutPriceId] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => setSession(s));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  const handleSelect = (priceId: string | null, isEnterprise?: boolean) => {
    if (isEnterprise) {
      window.location.href = "mailto:hello@intoinnovations.com?subject=Axiom Enterprise";
      return;
    }
    if (!priceId) {
      window.location.href = "/";
      return;
    }
    if (!session) {
      window.location.href = "/?auth=signup";
      return;
    }
    setCheckoutPriceId(priceId);
  };

  if (checkoutPriceId && session) {
    return (
      <div className="min-h-screen" style={{ background: "#0D0B09" }}>
        <PaymentTestModeBanner />
        <div className="max-w-2xl mx-auto px-4 py-12">
          <button
            onClick={() => setCheckoutPriceId(null)}
            className="mb-8 text-sm flex items-center gap-2 transition-colors"
            style={{ color: "rgba(255,255,255,0.4)" }}
          >
            ← Back to pricing
          </button>
          <StripeEmbeddedCheckout
            priceId={checkoutPriceId}
            customerEmail={session.user.email}
            userId={session.user.id}
            returnUrl={`${typeof window !== "undefined" ? window.location.origin : ""}/checkout/return?session_id={CHECKOUT_SESSION_ID}`}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#0D0B09" }}>
      <PaymentTestModeBanner />

      {/* Subtle grid */}
      <div
        className="fixed inset-0 z-0 pointer-events-none"
        style={{
          opacity: 0.04,
          backgroundImage:
            "linear-gradient(#D4AF37 1px, transparent 1px), linear-gradient(90deg, #D4AF37 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10">
        {/* Header */}
        <nav className="flex items-center justify-between px-6 py-5 max-w-7xl mx-auto">
          <Link to="/" className="text-lg font-semibold tracking-wide" style={{ color: "#D4AF37" }}>
            AXIOM
          </Link>
          <Link to="/" className="text-xs tracking-widest uppercase transition-colors"
            style={{ color: "rgba(255,255,255,0.35)" }}>
            ← Back
          </Link>
        </nav>

        {/* Hero */}
        <div className="text-center pt-16 pb-12 px-4">
          <p className="text-xs tracking-[0.35em] uppercase mb-4" style={{ color: "rgba(212,175,55,0.6)" }}>
            Pricing
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold mb-4" style={{ color: "rgba(255,255,255,0.9)" }}>
            Choose your specification tier
          </h1>
          <p className="text-sm max-w-md mx-auto" style={{ color: "rgba(255,255,255,0.4)" }}>
            From solo architects to enterprise engineering teams.
            Every tier runs on the same structural engine.
          </p>
        </div>

        {/* Tier cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-6xl mx-auto px-6 pb-24">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className="relative rounded-lg p-6 flex flex-col transition-all duration-300"
              style={{
                background: tier.highlight
                  ? "rgba(212, 175, 55, 0.06)"
                  : "rgba(255,255,255,0.02)",
                border: tier.highlight
                  ? "1px solid rgba(212, 175, 55, 0.25)"
                  : "1px solid rgba(255,255,255,0.06)",
              }}
            >
              {tier.highlight && (
                <div
                  className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] tracking-widest uppercase font-medium"
                  style={{
                    background: "rgba(212, 175, 55, 0.15)",
                    border: "1px solid rgba(212, 175, 55, 0.3)",
                    color: "#D4AF37",
                  }}
                >
                  Most Popular
                </div>
              )}

              <h3 className="text-sm font-medium tracking-wide mb-1" style={{ color: "rgba(255,255,255,0.7)" }}>
                {tier.name}
              </h3>
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-3xl font-semibold" style={{ color: tier.highlight ? "#D4AF37" : "rgba(255,255,255,0.85)" }}>
                  {tier.price}
                </span>
                {tier.interval && (
                  <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                    {tier.interval}
                  </span>
                )}
              </div>
              <p className="text-xs mb-5" style={{ color: "rgba(255,255,255,0.35)" }}>
                {tier.description}
              </p>

              <ul className="space-y-2.5 mb-6 flex-1">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>
                    <span style={{ color: "rgba(212, 175, 55, 0.6)" }}>✦</span>
                    {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSelect(tier.priceId, (tier as any).isEnterprise)}
                className="w-full py-2.5 rounded text-xs font-medium tracking-wide uppercase transition-all duration-200"
                style={{
                  background: tier.highlight
                    ? "rgba(212, 175, 55, 0.15)"
                    : "rgba(255,255,255,0.04)",
                  border: tier.highlight
                    ? "1px solid rgba(212, 175, 55, 0.35)"
                    : "1px solid rgba(255,255,255,0.08)",
                  color: tier.highlight ? "#D4AF37" : "rgba(255,255,255,0.5)",
                }}
              >
                {tier.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
