import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/checkout/return")({
  validateSearch: (search: Record<string, unknown>): { session_id?: string } => ({
    session_id: typeof search.session_id === "string" ? search.session_id : undefined,
  }),
  component: CheckoutReturn,
  head: () => ({
    meta: [
      { title: "Payment Complete — Axiom" },
      { name: "description", content: "Your Axiom subscription is being activated." },
    ],
  }),
});

function CheckoutReturn() {
  const { session_id: sessionId } = Route.useSearch();

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0D0B09" }}>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(128,90,213,0.12) 0%, transparent 70%)",
        }}
      />
      <div className="relative z-10 text-center max-w-md mx-auto px-6">
        {sessionId ? (
          <>
            <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center"
              style={{ background: "rgba(212, 175, 55, 0.15)", border: "1px solid rgba(212, 175, 55, 0.3)" }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#D4AF37" strokeWidth="2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <h1 className="text-2xl font-semibold mb-3" style={{ color: "#D4AF37" }}>
              Welcome to Axiom Pro
            </h1>
            <p className="text-sm mb-8" style={{ color: "rgba(255,255,255,0.5)" }}>
              Your subscription is being activated. You'll have full access momentarily.
            </p>
            <a href="/" className="inline-block px-6 py-2.5 rounded text-sm font-medium transition-all"
              style={{
                background: "rgba(212, 175, 55, 0.15)",
                border: "1px solid rgba(212, 175, 55, 0.3)",
                color: "#D4AF37",
              }}>
              Enter Axiom →
            </a>
          </>
        ) : (
          <>
            <h1 className="text-2xl font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>
              No session found
            </h1>
            <a href="/pricing" className="text-sm underline" style={{ color: "#D4AF37" }}>
              Back to pricing
            </a>
          </>
        )}
      </div>
    </div>
  );
}
