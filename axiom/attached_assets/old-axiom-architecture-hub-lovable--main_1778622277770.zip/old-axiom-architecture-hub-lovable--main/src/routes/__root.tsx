import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { useEffect } from "react";
import { UpgradeGateProvider } from "@/hooks/use-upgrade-gate";
import { Toaster } from "@/components/ui/sonner";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Axiom — Structural Specification Engine" },
      { name: "description", content: "Run it through Axiom, then send it to Atlas. Turn unstructured ideas into complete, connected architecture." },
      { name: "author", content: "Into Innovations" },
      { property: "og:title", content: "Axiom — Structural Specification Engine" },
      { property: "og:description", content: "Run it through Axiom, then send it to Atlas. Turn unstructured ideas into complete, connected architecture." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "Axiom" },
      { name: "theme-color", content: "#D4AF37" },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "twitter:title", content: "Axiom — Structural Specification Engine" },
      { name: "twitter:description", content: "Run it through Axiom, then send it to Atlas. Turn unstructured ideas into complete, connected architecture." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/6a62fd84-0bcf-4516-948b-3d7b3d375eff/id-preview-555fe695--b34a5410-cc81-4b18-b211-9f179b72d6ee.lovable.app-1778092822158.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/6a62fd84-0bcf-4516-948b-3d7b3d375eff/id-preview-555fe695--b34a5410-cc81-4b18-b211-9f179b72d6ee.lovable.app-1778092822158.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&family=IBM+Plex+Mono:wght@300;400;500&display=swap" },
      { rel: "manifest", href: "/manifest.json" },
      { rel: "apple-touch-icon", href: "/axiom-logo.svg" },
    ],
    scripts: [
      {
        children: `if ('serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js'); }); }`,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const t = localStorage.getItem('axiom_theme');
                if (t === 'light') document.documentElement.setAttribute('data-theme', 'light');
              } catch(e) {}
            `
          }}
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  useEffect(() => {
    const apply = () => {
      try {
        const t = localStorage.getItem("axiom_theme");
        if (t === "light") {
          document.documentElement.setAttribute("data-theme", "light");
        } else {
          document.documentElement.removeAttribute("data-theme");
        }
      } catch(e) {}
    };
    apply();
    window.addEventListener("axiom-theme-change", apply);
    return () => window.removeEventListener("axiom-theme-change", apply);
  }, []);

  return <UpgradeGateProvider><Outlet /><Toaster /></UpgradeGateProvider>;
}
