import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { UpgradeModal } from "@/components/axiom/UpgradeModal";

interface UpgradeGateCtx {
  openUpgrade: (message?: string) => void;
}

const Ctx = createContext<UpgradeGateCtx>({ openUpgrade: () => {} });

export function useUpgradeGate() {
  return useContext(Ctx);
}

export function UpgradeGateProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState<string | undefined>();

  const openUpgrade = useCallback((msg?: string) => {
    setMessage(msg);
    setOpen(true);
  }, []);

  return (
    <Ctx.Provider value={{ openUpgrade }}>
      {children}
      <UpgradeModal open={open} onClose={() => setOpen(false)} message={message} />
    </Ctx.Provider>
  );
}
