import { useState, useEffect } from "react";

export const useFlexMode = () => {
  const [isFlex, setIsFlex] = useState(false);
  useEffect(() => {
    const handleResize = () => {
      const ratio = window.innerWidth / window.innerHeight;
      setIsFlex(window.innerHeight > 600 && ratio < 1.2 && ratio > 0.8);
    };
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  return isFlex;
};
