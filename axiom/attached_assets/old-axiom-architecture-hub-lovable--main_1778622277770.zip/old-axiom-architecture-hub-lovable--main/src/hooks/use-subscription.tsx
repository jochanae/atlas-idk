import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type SubscriptionStatus = "free" | "pro" | "loading";

interface SubscriptionInfo {
  status: SubscriptionStatus;
  priceId: string | null;
  currentPeriodEnd: string | null;
  cancelAtPeriodEnd: boolean;
}

export function useSubscription() {
  const [info, setInfo] = useState<SubscriptionInfo>({
    status: "loading",
    priceId: null,
    currentPeriodEnd: null,
    cancelAtPeriodEnd: false,
  });
  const [monthlyUsage, setMonthlyUsage] = useState<number>(0);

  const fetchSubscription = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setInfo({ status: "free", priceId: null, currentPeriodEnd: null, cancelAtPeriodEnd: false });
      return;
    }

    const { data: sub } = await supabase
      .from("subscriptions")
      .select("*")
      .eq("user_id", user.id)
      .in("status", ["active", "trialing", "canceled"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (sub && (sub.status === "active" || sub.status === "trialing" ||
      (sub.status === "canceled" && sub.current_period_end && new Date(sub.current_period_end) > new Date()))) {
      setInfo({
        status: "pro",
        priceId: sub.price_id,
        currentPeriodEnd: sub.current_period_end,
        cancelAtPeriodEnd: sub.cancel_at_period_end || false,
      });
    } else {
      setInfo({ status: "free", priceId: null, currentPeriodEnd: null, cancelAtPeriodEnd: false });
    }

    // Fetch monthly usage
    const currentMonth = new Date().toISOString().slice(0, 7);
    const { data: usage } = await supabase
      .from("monthly_usage")
      .select("call_count")
      .eq("user_id", user.id)
      .eq("month", currentMonth)
      .maybeSingle();

    setMonthlyUsage(usage?.call_count || 0);
  }, []);

  useEffect(() => {
    fetchSubscription();
  }, [fetchSubscription]);

  return { ...info, monthlyUsage, refetch: fetchSubscription };
}
