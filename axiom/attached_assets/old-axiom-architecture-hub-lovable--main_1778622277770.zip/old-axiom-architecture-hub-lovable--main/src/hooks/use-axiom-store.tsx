import { useState, useCallback, useEffect, useMemo, createContext, useContext, type ReactNode } from "react";

export type AtmosphereMode = "stealth" | "cinematic" | "studio";
export type BuilderType = "lovable" | "cursor" | "replit" | null;

// ─── Cognitive schema ────────────────────────────────────────────────────────
// MoSCoW priority + special kinds. GOAL anchors a cluster. BLOCKER signals friction.
export type NodeKind = "GOAL" | "MUST" | "SHOULD" | "COULD" | "WONT" | "BLOCKER";

export interface ArchNode {
  id: string;
  label: string;
  /** Legacy architectural type (database/api/auth/...) — kept for backward compat. */
  type: "database" | "api" | "auth" | "state" | "logic" | "ui" | "decision";
  resolved: boolean;
  x: number;
  y: number;
  details?: string;

  // ─── Cognitive fields (optional so legacy nodes still work) ────────────────
  /** MoSCoW + GOAL/BLOCKER. When set, drives signal-system visuals. */
  kind?: NodeKind;
  /** AI-generated question that defines this node. Unanswered = amber pulse. */
  strategicQuestion?: string;
  /** User's answer. Presence flips the node from "needs attention" to defined. */
  strategicAnswer?: string;
  /** IDs of nodes this depends on (used for radial layout + dead-end detection). */
  dependencies?: string[];
  /** Decision IDs that this node contradicts. Triggers ember decision-catch. */
  conflictWith?: string[];
  /** Provenance — where this node came from. */
  spawnedFrom?: "transcript" | "manual" | "seed";
  /** Timestamp for fly-in animation. */
  bornAt?: number;
  /** Anchor GOAL id for radial clustering. */
  parentGoalId?: string;
}

export interface ArchEdge {
  id: string;
  from: string;
  to: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "system";
  content: string;
  timestamp: number;
}

/** A locked decision that future inputs must reconcile against. */
export interface Decision {
  id: string;
  statement: string;
  source: "manual" | "transcript" | "node-resolution";
  timestamp: number;
  status: "active" | "superseded";
  /** Node ids supporting this decision (for traceability). */
  nodeIds?: string[];
}

/** A flagged contradiction awaiting reconciliation. */
export interface Contradiction {
  id: string;
  nodeId: string;
  decisionId: string;
  reason: string;
  timestamp: number;
  resolved: boolean;
}

/** Shape returned by the axiom-chat decompose mode. */
export interface DecompositionResult {
  goals?: { label: string; strategicQuestion?: string }[];
  musts?: { label: string; strategicQuestion?: string; dependsOn?: string[] }[];
  shoulds?: { label: string; strategicQuestion?: string }[];
  coulds?: { label: string; strategicQuestion?: string }[];
  blockers?: { label: string; reason?: string }[];
  /** Statements the AI identified as decisions worth locking into the ledger. */
  newDecisions?: { statement: string }[];
  /** Pre-flagged contradictions: AI noticed these conflict with existing decisions. */
  contradictions?: { nodeLabel: string; decisionStatement: string; reason: string }[];
}

export interface SavedSpec {
  id: string;
  name: string;
  builder: string | null;
  score: number;
  date: string;
  nodes: ArchNode[];
  edges: ArchEdge[];
  messages: ChatMessage[];
  decisionLedger?: Decision[];
}

interface AxiomState {
  atmosphere: AtmosphereMode;
  setAtmosphere: (m: AtmosphereMode) => void;
  detectedBuilder: BuilderType;
  setDetectedBuilder: (b: BuilderType) => void;
  nodes: ArchNode[];
  edges: ArchEdge[];
  addNode: (node: ArchNode) => void;
  resolveNode: (id: string) => void;
  addEdge: (edge: ArchEdge) => void;
  messages: ChatMessage[];
  addMessage: (msg: ChatMessage) => void;
  readinessScore: number;
  focusedNodeId: string | null;
  setFocusedNodeId: (id: string | null) => void;
  mapMinimized: boolean;
  setMapMinimized: (v: boolean) => void;
  saveToVault: (name: string) => void;
  savedSpecs: SavedSpec[];
  loadSpec: (spec: SavedSpec) => void;
  deleteSpec: (id: string) => void;
  resetSession: () => void;

  // ─── Cognitive engine ───────────────────────────────────────────────────────
  decisionLedger: Decision[];
  contradictions: Contradiction[];
  /** Add a locked decision. */
  addDecision: (statement: string, source?: Decision["source"], nodeIds?: string[]) => Decision;
  /** Mark a decision superseded. */
  supersedeDecision: (id: string) => void;
  /** Resolve a contradiction (user picked a side). */
  resolveContradiction: (id: string, choice: "keep-decision" | "supersede-decision") => void;
  /** Answer a node's strategic question (flips it out of amber-pulse). */
  answerStrategicQuestion: (nodeId: string, answer: string) => void;
  /** Spawn nodes from a Claude decomposition. Returns the new node IDs. */
  spawnFromDecomposition: (result: DecompositionResult) => { newNodeIds: string[]; flagged: number };
  /** Active GOAL node id — the focal point of the radial layout. */
  activeGoalId: string | null;
  setActiveGoalId: (id: string | null) => void;
}

const AxiomContext = createContext<AxiomState | null>(null);

const STORAGE_KEY = "axiom-workspace-v2";
const VAULT_KEY = "axiom-vault";

// Legacy seed nodes — tagged as MUST so signal system treats them coherently.
const INITIAL_NODES: ArchNode[] = [
  { id: "auth", label: "Authentication", type: "auth", resolved: false, x: 300, y: 80, kind: "MUST", spawnedFrom: "seed" },
  { id: "db",   label: "Database",       type: "database", resolved: false, x: 150, y: 200, kind: "MUST", spawnedFrom: "seed" },
  { id: "api",  label: "API Routes",     type: "api", resolved: false, x: 450, y: 200, kind: "MUST", spawnedFrom: "seed" },
  { id: "state",label: "State Management",type: "state", resolved: false, x: 300, y: 320, kind: "SHOULD", spawnedFrom: "seed" },
  { id: "ui",   label: "UI Components",  type: "ui", resolved: false, x: 150, y: 440, kind: "MUST", spawnedFrom: "seed" },
  { id: "logic",label: "Business Logic", type: "logic", resolved: false, x: 450, y: 440, kind: "MUST", spawnedFrom: "seed" },
];

const INITIAL_EDGES: ArchEdge[] = [
  { id: "e1", from: "auth", to: "db" },
  { id: "e2", from: "auth", to: "api" },
  { id: "e3", from: "api", to: "db" },
  { id: "e4", from: "api", to: "state" },
  { id: "e5", from: "state", to: "ui" },
  { id: "e6", from: "state", to: "logic" },
  { id: "e7", from: "logic", to: "api" },
];

function loadWorkspace() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function loadVault(): SavedSpec[] {
  try {
    const raw = localStorage.getItem(VAULT_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as SavedSpec[];
  } catch {
    return [];
  }
}

// ─── Radial layout helper ────────────────────────────────────────────────────
// Place children around their parent goal in concentric rings.
function radialPosition(parentX: number, parentY: number, index: number, total: number, ring = 1) {
  const radius = 140 * ring;
  const angle = (index / Math.max(total, 1)) * Math.PI * 2 - Math.PI / 2;
  return {
    x: Math.round(parentX + Math.cos(angle) * radius),
    y: Math.round(parentY + Math.sin(angle) * radius),
  };
}

export function AxiomProvider({ children }: { children: ReactNode }) {
  const saved = typeof window !== "undefined" ? loadWorkspace() : null;

  const [atmosphere, setAtmosphere] = useState<AtmosphereMode>(saved?.atmosphere ?? "cinematic");
  const [detectedBuilder, setDetectedBuilder] = useState<BuilderType>(saved?.detectedBuilder ?? null);
  const [nodes, setNodes] = useState<ArchNode[]>(saved?.nodes ?? INITIAL_NODES);
  const [edges, setEdges] = useState<ArchEdge[]>(saved?.edges ?? INITIAL_EDGES);
  const [messages, setMessages] = useState<ChatMessage[]>(
    saved?.messages ?? [
      {
        id: "welcome",
        role: "system",
        content: "Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?",
        timestamp: Date.now(),
      },
    ]
  );
  const [focusedNodeId, setFocusedNodeId] = useState<string | null>(null);
  const [mapMinimized, setMapMinimized] = useState(false);
  const [savedSpecs, setSavedSpecs] = useState<SavedSpec[]>(
    typeof window !== "undefined" ? loadVault() : []
  );
  const [decisionLedger, setDecisionLedger] = useState<Decision[]>(saved?.decisionLedger ?? []);
  const [contradictions, setContradictions] = useState<Contradiction[]>(saved?.contradictions ?? []);
  const [activeGoalId, setActiveGoalId] = useState<string | null>(saved?.activeGoalId ?? null);

  // Persist
  useEffect(() => {
    const data = { nodes, edges, messages, atmosphere, detectedBuilder, decisionLedger, contradictions, activeGoalId };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [nodes, edges, messages, atmosphere, detectedBuilder, decisionLedger, contradictions, activeGoalId]);

  useEffect(() => {
    localStorage.setItem(VAULT_KEY, JSON.stringify(savedSpecs));
  }, [savedSpecs]);

  const addNode = useCallback((node: ArchNode) => {
    setNodes((prev) => [...prev, node]);
  }, []);

  const resolveNode = useCallback((id: string) => {
    setNodes((prev) => prev.map((n) => (n.id === id ? { ...n, resolved: true } : n)));
  }, []);

  const addEdge = useCallback((edge: ArchEdge) => {
    setEdges((prev) => [...prev, edge]);
  }, []);

  const addMessage = useCallback((msg: ChatMessage) => {
    setMessages((prev) => [...prev, msg]);
    const lower = msg.content.toLowerCase();
    if (lower.includes("lovable")) setDetectedBuilder("lovable");
    else if (lower.includes("cursor")) setDetectedBuilder("cursor");
    else if (lower.includes("replit")) setDetectedBuilder("replit");

    const keywords: Record<string, string[]> = {
      auth: ["login", "auth", "sign up", "sign in", "oauth", "magic link"],
      db: ["database", "postgres", "supabase", "table", "schema"],
      api: ["api", "endpoint", "route", "rest", "graphql"],
      state: ["state", "redux", "zustand", "context", "store"],
      ui: ["component", "ui", "button", "form", "page", "layout"],
      logic: ["logic", "function", "algorithm", "calculation", "validation"],
    };
    if (msg.role === "user") {
      Object.entries(keywords).forEach(([nodeId, words]) => {
        if (words.some((w) => lower.includes(w))) {
          setNodes((prev) => prev.map((n) => (n.id === nodeId ? { ...n, resolved: true } : n)));
        }
      });
    }
  }, []);

  const readinessScore = useMemo(
    () => Math.round((nodes.filter((n) => n.resolved).length / Math.max(nodes.length, 1)) * 100),
    [nodes]
  );

  // ─── Cognitive engine actions ─────────────────────────────────────────────

  const addDecision = useCallback(
    (statement: string, source: Decision["source"] = "manual", nodeIds?: string[]) => {
      const decision: Decision = {
        id: crypto.randomUUID(),
        statement,
        source,
        timestamp: Date.now(),
        status: "active",
        nodeIds,
      };
      setDecisionLedger((prev) => [decision, ...prev]);
      return decision;
    },
    []
  );

  const supersedeDecision = useCallback((id: string) => {
    setDecisionLedger((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "superseded" } : d))
    );
  }, []);

  const resolveContradiction = useCallback(
    (id: string, choice: "keep-decision" | "supersede-decision") => {
      setContradictions((prev) => {
        const c = prev.find((x) => x.id === id);
        if (!c) return prev;
        if (choice === "supersede-decision") {
          setDecisionLedger((dl) =>
            dl.map((d) => (d.id === c.decisionId ? { ...d, status: "superseded" } : d))
          );
          // Clear conflict marker on the node
          setNodes((ns) =>
            ns.map((n) =>
              n.id === c.nodeId
                ? { ...n, conflictWith: (n.conflictWith ?? []).filter((d) => d !== c.decisionId) }
                : n
            )
          );
        } else {
          // keep decision -> remove the offending node
          setNodes((ns) => ns.filter((n) => n.id !== c.nodeId));
        }
        return prev.map((x) => (x.id === id ? { ...x, resolved: true } : x));
      });
    },
    []
  );

  const answerStrategicQuestion = useCallback((nodeId: string, answer: string) => {
    setNodes((prev) =>
      prev.map((n) =>
        n.id === nodeId
          ? { ...n, strategicAnswer: answer, resolved: answer.trim().length > 0 ? true : n.resolved }
          : n
      )
    );
  }, []);

  const spawnFromDecomposition = useCallback(
    (result: DecompositionResult) => {
      const newNodeIds: string[] = [];
      const labelToId = new Map<string, string>();
      const now = Date.now();
      let flagged = 0;

      // Anchor a GOAL — first one becomes active goal if none exists.
      const goalNodes: ArchNode[] = (result.goals ?? []).map((g, i) => {
        const id = crypto.randomUUID();
        labelToId.set(g.label, id);
        newNodeIds.push(id);
        return {
          id,
          label: g.label,
          type: "decision",
          resolved: false,
          x: 400 + i * 60,
          y: 240,
          kind: "GOAL",
          strategicQuestion: g.strategicQuestion,
          spawnedFrom: "transcript",
          bornAt: now + i * 80,
        };
      });

      const goalAnchor = goalNodes[0] ?? nodes.find((n) => n.kind === "GOAL");
      const anchorX = goalAnchor?.x ?? 300;
      const anchorY = goalAnchor?.y ?? 240;
      const anchorId = goalAnchor?.id;

      const buildKindNodes = (
        items: { label: string; strategicQuestion?: string; dependsOn?: string[] }[] | undefined,
        kind: NodeKind,
        ring: number,
        baseDelay: number
      ): ArchNode[] =>
        (items ?? []).map((item, i, arr) => {
          const id = crypto.randomUUID();
          labelToId.set(item.label, id);
          newNodeIds.push(id);
          const pos = radialPosition(anchorX, anchorY, i, arr.length, ring);
          return {
            id,
            label: item.label,
            type: kind === "BLOCKER" ? "decision" : "logic",
            resolved: false,
            x: pos.x,
            y: pos.y,
            kind,
            strategicQuestion: item.strategicQuestion,
            spawnedFrom: "transcript",
            bornAt: now + baseDelay + i * 80,
            parentGoalId: anchorId,
          };
        });

      const mustNodes = buildKindNodes(result.musts, "MUST", 1, 120);
      const shouldNodes = buildKindNodes(result.shoulds, "SHOULD", 2, 240);
      const couldNodes = buildKindNodes(result.coulds, "COULD", 2, 320);
      const blockerNodes = buildKindNodes(
        (result.blockers ?? []).map((b) => ({ label: b.label, strategicQuestion: b.reason })),
        "BLOCKER",
        1,
        400
      );

      const allNew = [...goalNodes, ...mustNodes, ...shouldNodes, ...couldNodes, ...blockerNodes];

      // Build edges from goal -> direct children + MUST -> dependsOn
      const newEdges: ArchEdge[] = [];
      if (anchorId) {
        [...mustNodes, ...shouldNodes, ...blockerNodes].forEach((n) => {
          newEdges.push({ id: crypto.randomUUID(), from: anchorId, to: n.id });
        });
      }
      (result.musts ?? []).forEach((m, i) => {
        const fromId = mustNodes[i]?.id;
        (m.dependsOn ?? []).forEach((depLabel) => {
          const toId = labelToId.get(depLabel);
          if (fromId && toId) {
            newEdges.push({ id: crypto.randomUUID(), from: fromId, to: toId });
            // Track dependency on node
            const idx = allNew.findIndex((n) => n.id === fromId);
            if (idx >= 0) {
              allNew[idx] = {
                ...allNew[idx],
                dependencies: [...(allNew[idx].dependencies ?? []), toId],
              };
            }
          }
        });
      });

      // ─── Decision Catch ─────────────────────────────────────────────────
      // For each contradiction the AI flagged, find the matching decision and node.
      const newContradictions: Contradiction[] = [];
      (result.contradictions ?? []).forEach((c) => {
        const node = allNew.find((n) => n.label === c.nodeLabel);
        const decision = decisionLedger.find(
          (d) => d.status === "active" && d.statement.toLowerCase().includes(c.decisionStatement.toLowerCase().slice(0, 24))
        );
        if (node && decision) {
          flagged++;
          node.conflictWith = [...(node.conflictWith ?? []), decision.id];
          newContradictions.push({
            id: crypto.randomUUID(),
            nodeId: node.id,
            decisionId: decision.id,
            reason: c.reason,
            timestamp: now,
            resolved: false,
          });
        }
      });

      // Lock new decisions into the ledger
      const decisionsToAdd: Decision[] = (result.newDecisions ?? []).map((d) => ({
        id: crypto.randomUUID(),
        statement: d.statement,
        source: "transcript",
        timestamp: now,
        status: "active",
      }));

      setNodes((prev) => [...prev, ...allNew]);
      setEdges((prev) => [...prev, ...newEdges]);
      if (decisionsToAdd.length) setDecisionLedger((prev) => [...decisionsToAdd, ...prev]);
      if (newContradictions.length) setContradictions((prev) => [...newContradictions, ...prev]);
      if (!activeGoalId && goalNodes[0]) setActiveGoalId(goalNodes[0].id);

      return { newNodeIds, flagged };
    },
    [nodes, decisionLedger, activeGoalId]
  );

  const saveToVault = useCallback(
    (name: string) => {
      const spec: SavedSpec = {
        id: crypto.randomUUID(),
        name,
        builder: detectedBuilder,
        score: readinessScore,
        date: new Date().toISOString().split("T")[0],
        nodes,
        edges,
        messages,
        decisionLedger,
      };
      setSavedSpecs((prev) => [spec, ...prev]);
    },
    [detectedBuilder, readinessScore, nodes, edges, messages, decisionLedger]
  );

  const loadSpec = useCallback((spec: SavedSpec) => {
    setNodes(spec.nodes);
    setEdges(spec.edges);
    setMessages(spec.messages);
    setDetectedBuilder(spec.builder as BuilderType);
    setDecisionLedger(spec.decisionLedger ?? []);
  }, []);

  const deleteSpec = useCallback((id: string) => {
    setSavedSpecs((prev) => prev.filter((s) => s.id !== id));
  }, []);

  const resetSession = useCallback(() => {
    setNodes(INITIAL_NODES.map((n) => ({ ...n, resolved: false })));
    setEdges(INITIAL_EDGES);
    setDetectedBuilder(null);
    setDecisionLedger([]);
    setContradictions([]);
    setActiveGoalId(null);
    setMessages([
      {
        id: "welcome",
        role: "system",
        content: "Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?",
        timestamp: Date.now(),
      },
    ]);
  }, []);

  return (
    <AxiomContext.Provider
      value={{
        atmosphere, setAtmosphere,
        detectedBuilder, setDetectedBuilder,
        nodes, edges, addNode, resolveNode, addEdge,
        messages, addMessage,
        readinessScore,
        focusedNodeId, setFocusedNodeId,
        mapMinimized, setMapMinimized,
        saveToVault, savedSpecs, loadSpec, deleteSpec, resetSession,
        decisionLedger, contradictions,
        addDecision, supersedeDecision, resolveContradiction,
        answerStrategicQuestion, spawnFromDecomposition,
        activeGoalId, setActiveGoalId,
      }}
    >
      {children}
    </AxiomContext.Provider>
  );
}

export function useAxiom() {
  const ctx = useContext(AxiomContext);
  if (!ctx) throw new Error("useAxiom must be used within AxiomProvider");
  return ctx;
}
