
alter function public.has_active_subscription(uuid, text) set search_path = public;
revoke execute on function public.has_active_subscription(uuid, text) from anon;

alter function public.has_role(uuid, app_role) set search_path = public;
revoke execute on function public.has_role(uuid, app_role) from anon;
