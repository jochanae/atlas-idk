CREATE TABLE IF NOT EXISTS monthly_usage (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  month text NOT NULL,
  call_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, month)
);

CREATE INDEX IF NOT EXISTS monthly_usage_user_month_idx ON monthly_usage(user_id, month);

ALTER TABLE monthly_usage ENABLE ROW LEVEL SECURITY;

-- Service role access for edge function
CREATE POLICY "Service role full access"
  ON monthly_usage
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Authenticated users can read their own usage (for UI display)
CREATE POLICY "Users can view own usage"
  ON monthly_usage
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);