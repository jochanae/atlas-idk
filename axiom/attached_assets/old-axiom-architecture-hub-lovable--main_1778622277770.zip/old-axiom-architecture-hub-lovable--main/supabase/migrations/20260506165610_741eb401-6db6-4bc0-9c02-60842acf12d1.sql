
DROP POLICY IF EXISTS "anon_insert" ON public.legacy_log;
DROP POLICY IF EXISTS "anon_select" ON public.legacy_log;
