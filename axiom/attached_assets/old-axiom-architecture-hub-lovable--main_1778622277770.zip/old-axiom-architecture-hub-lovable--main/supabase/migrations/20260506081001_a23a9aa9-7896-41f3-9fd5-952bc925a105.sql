CREATE POLICY "anon_select" ON legacy_log
  FOR SELECT
  TO anon, authenticated
  USING (true);