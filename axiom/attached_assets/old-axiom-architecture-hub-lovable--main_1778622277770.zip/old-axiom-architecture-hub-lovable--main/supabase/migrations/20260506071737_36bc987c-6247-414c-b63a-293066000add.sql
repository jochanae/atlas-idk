ALTER TABLE legacy_log ALTER COLUMN user_id DROP NOT NULL;

CREATE POLICY "anon_insert" ON legacy_log
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);