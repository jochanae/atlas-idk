
-- Projects table
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own projects" ON public.projects FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can create own projects" ON public.projects FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own projects" ON public.projects FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own projects" ON public.projects FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Architectures table
CREATE TABLE public.architectures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE NOT NULL,
  manifest_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.architectures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own architectures" ON public.architectures FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.projects WHERE projects.id = architectures.project_id AND projects.user_id = auth.uid()));
CREATE POLICY "Users can create own architectures" ON public.architectures FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.projects WHERE projects.id = architectures.project_id AND projects.user_id = auth.uid()));
CREATE POLICY "Users can update own architectures" ON public.architectures FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.projects WHERE projects.id = architectures.project_id AND projects.user_id = auth.uid()));
CREATE POLICY "Users can delete own architectures" ON public.architectures FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.projects WHERE projects.id = architectures.project_id AND projects.user_id = auth.uid()));

-- System maps table
CREATE TABLE public.system_maps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  architecture_id UUID REFERENCES public.architectures(id) ON DELETE CASCADE NOT NULL,
  nodes_edges JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.system_maps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own system maps" ON public.system_maps FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.architectures a JOIN public.projects p ON p.id = a.project_id WHERE a.id = system_maps.architecture_id AND p.user_id = auth.uid()));
CREATE POLICY "Users can create own system maps" ON public.system_maps FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.architectures a JOIN public.projects p ON p.id = a.project_id WHERE a.id = system_maps.architecture_id AND p.user_id = auth.uid()));
CREATE POLICY "Users can update own system maps" ON public.system_maps FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.architectures a JOIN public.projects p ON p.id = a.project_id WHERE a.id = system_maps.architecture_id AND p.user_id = auth.uid()));
CREATE POLICY "Users can delete own system maps" ON public.system_maps FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.architectures a JOIN public.projects p ON p.id = a.project_id WHERE a.id = system_maps.architecture_id AND p.user_id = auth.uid()));

-- Legacy log (Gold Vault)
CREATE TABLE public.legacy_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  prompt_output TEXT,
  builder TEXT,
  compatibility_score INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.legacy_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own legacy logs" ON public.legacy_log FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can create own legacy logs" ON public.legacy_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own legacy logs" ON public.legacy_log FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Builder profiles
CREATE TABLE public.builder_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.builder_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view builder profiles" ON public.builder_profiles FOR SELECT TO authenticated USING (true);

-- Seed builder profiles
INSERT INTO public.builder_profiles (name, config) VALUES
  ('Lovable', '{"color": "#9b59b6", "strengths": ["UI/UX", "Rapid prototyping", "Full-stack"], "tips": "Provide detailed component descriptions for best results."}'::jsonb),
  ('Cursor', '{"color": "#3498db", "strengths": ["Code editing", "Refactoring", "Complex logic"], "tips": "Break specs into file-level tasks for optimal code generation."}'::jsonb),
  ('Replit', '{"color": "#27ae60", "strengths": ["Quick deployment", "Multi-language", "Collaboration"], "tips": "Include environment setup steps in your spec."}'::jsonb);
