
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS builder text,
  ADD COLUMN IF NOT EXISTS tech_stack text DEFAULT '',
  ADD COLUMN IF NOT EXISTS file_structure text DEFAULT '',
  ADD COLUMN IF NOT EXISTS notes text DEFAULT '',
  ADD COLUMN IF NOT EXISTS last_used timestamptz;
