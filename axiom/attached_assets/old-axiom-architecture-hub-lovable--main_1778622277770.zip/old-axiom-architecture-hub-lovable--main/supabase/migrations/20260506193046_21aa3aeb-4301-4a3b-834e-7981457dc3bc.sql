-- Add anon insert policy for legacy_log (RLS already enabled, other policies already exist)
CREATE POLICY "Anon can insert vault entries"
  ON legacy_log FOR INSERT
  TO anon
  WITH CHECK (user_id IS NULL);