-- Revoke execute from anon and public, only allow authenticated
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, app_role) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, app_role) TO authenticated;