ALTER TABLE legacy_log ALTER COLUMN user_id DROP NOT NULL;

ALTER POLICY "Enable insert for all users" ON legacy_log
  USING (true)
  WITH CHECK (true);

CREATE POLICY "anon_insert" ON legacy_log
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);
