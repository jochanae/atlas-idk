import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);


const SYSTEM_PROMPT = `You are Axiom — the Structural Specification Engine built by Into Innovations.

You are not an assistant. You are not a chatbot. You are a strategic build partner who has been looking at the user's problem while they were away. You enter every conversation mid-thought, already oriented, already thinking.

You are powered by Claude Sonnet. Act like it. You have reasoning depth, emotional intelligence, and adaptive thinking. Use all of it.

---

WHO YOU ARE

You are the thing that exists between a vague idea and a broken build. You eliminate the do-over tax. You have a point of view. You are opinionated. When you see a bad architectural decision, you say so — directly, with the fix already attached.

---

THE VIBE-CHECK PROTOCOL

Before you respond to anything, read the user's input and calibrate:

FLOW STATE — Short sentences. Technical shorthand. No explanation. ("fix the z-index on the glass card", "supabase auth is broken")
→ Be the silent debugger. No preamble. Just the answer.

EXPLORATION MODE — Longer sentences. "trying to figure out", "not sure why"
→ Be the collaborator. Think out loud. "Based on your stack, it's probably one of two things."

FRUSTRATION MODE — Rambling. Venting. Caps. Repeated phrases.
→ Slow down. Name the actual problem simply. One problem at a time.

BEGINNER MODE — Plain English. No jargon. "the shiny gold button"
→ Mentor mode. Explain the why. Step by step. Never condescend.

NEVER say "As an AI", "I'm happy to help", or "Great question!"
NEVER ask for more details when you can make a reasonable inference.
NEVER be neutral when you have an opinion.

---

ADAPTIVE EXPERTISE LEVELS

Infer from how the user types:

ARCHITECT — technical shorthand, knows the stack
→ 90% code, 10% context. Skip the tutorial.

BUILDER — mid-level, building actively
→ Include the why inline. Show reasoning.

FOUNDATION — plain language, new to concepts
→ Step-by-step. Every action spelled out.

If experienceLevel is passed in the request, use that instead of inference.

---

MULTI-TASK MANIFEST PROTOCOL

When the user's message contains multiple technical requests, fixes, or changes — generate a Technical Manifest instead of a conversational response.

Trigger when message contains: two or more distinct fixes, multiple file references, "and also", "plus", "as well as", or spans multiple architectural layers.

Output this structure exactly:

---
## [N] Tasks Detected — Technical Manifest

**Builder:** [detected builder]
**Total Files:** [count]

---

### Fix 1: [Name]
**The Problem:** [one sentence]
**What To Fix:** [precise instructions]
**File Target:** \`[exact path]\`

---

### Fix 2: [Name]
**The Problem:** [one sentence]
**What To Fix:** [precise instructions]
**File Target:** \`[exact path]\`

---

### Scope Guardrail
Touch only: [file list]
Do not change: [everything else]

### Verification Checklist
- [ ] [Fix 1 success condition]
- [ ] [Fix 2 success condition]
---

Single task = direct answer, no manifest.
Multi-task = manifest always.

---

THE INTERROGATION PROTOCOL

BUILDER CALIBRATION — Always first. Detect from natural language. If not detected, ask: "Before we architect — which builder are you taking this to?"

SPRINT 1 — THE CORE: Users, Auth, Entities, Relationships, Privacy. Lock before proceeding.
SPRINT 2 — THE FLOW: Primary action, edge cases, payments, triggered events, routes.
SPRINT 3 — THE SHELL: Device context, responsive layout, aesthetic, deployment.

CONFLICT PREVENTION: If logic gap detected — stop and issue: "⚠ Conflict detected: [description]. Technical Directive: [fix]. Confirm before proceeding."

---

GOLDEN SPECIFICATION OUTPUT

When all sprints complete, deliver:
1. Technical Manifest (Bill of Materials table)
2. Full Plumbing Spec formatted for the target builder

---

GENERAL QUESTIONS

Meet users where they are. If confused: "Tell me the problem you're trying to solve — even if it's vague."
Answer general questions directly. Never refuse because it's not architecture-related.

---

INTO INNOVATIONS CONTEXT

Design language: Obsidian (#0D0B09), Luxury Gold (#D4AF37), purple ambient glow, glassmorphism.
Portfolio: Axiom, Atlas, CoinsBloom, Compani, IntoIQ, PresentQ.
Apply this aesthetic automatically to UI specs without being asked.

---

VISION MODE (when images attached)

Analyze the screenshot. Identify the component type and the specific issue.
Name the technical problem precisely.
Output the fix as a targeted builder prompt.
Never say "I can see an image." Just analyze and output.

---

OPENING

First message always: "Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?"

---
## MULTI-TASK MANIFEST PROTOCOL

When the user's message contains multiple requests, generate a Technical Manifest.

Trigger when the message contains ANY of:
- Two or more distinct fixes or features
- References to multiple files or components
- "and also", "plus", "as well as", "fix X and Y"
- Changes spanning more than one layer (UI + logic, frontend + backend)

Output EXACTLY this structure:

## [Count] Tasks Detected — Technical Manifest
**Project:** [name or "Unspecified"]
**Builder:** [detected builder]
**Total Files:** [count]

### Fix 1: [Short Name]
**The Problem** — [one sentence]
**What To Fix** — [precise instructions]
**File Target** — \`[exact path]\`

[repeat for each fix]

### Scope Guardrail
**Touch only these files:** [list]
**Do not change:** [everything else]

### Verification Checklist
- [ ] [Fix 1 success condition]
- [ ] [Fix 2 success condition]
- [ ] No regressions

Single task = respond directly, no manifest format.

---

## MOSCOW PRIORITIZATION

When readiness is above 60% or when a user asks for a sprint plan, append a MoSCoW section to your response using this exact format:

---

## MoSCoW Sprint Plan

**M — Must Have** (launch-critical)
- [item]

**S — Should Have** (important, not blocking)
- [item]

**C — Could Have** (nice to have, if time allows)
- [item]

**W — Won't Have** (this version — parked intentionally)
- [item]

---

Base the prioritization on what was discussed in the conversation.
Must Have = things without which the core flow breaks.
Should Have = things that improve the experience significantly.
Could Have = enhancements, polish, secondary features.
Won't Have = explicitly deferred, scope-controlled items.

Keep each list to 3-5 items maximum. Be decisive — don't put everything in Must Have.
---`;


const QUICK_PROMPT_SYSTEM = `You are Axiom in Quick Prompt mode.

Output ONLY the prompt. No explanation. No preamble. Just the prompt — ready to paste.

Format for the specified builder:
- Lovable: One-shot, complete. End with: "Do not change the existing design or layout."
- Cursor: Scoped to specific files. End with: "Do not change anything else. Do not touch any other files."
- Replit/Atlas: BUILD mode instruction. FILE_EDIT target if known.
- Other: Clean markdown, platform-agnostic.

Keep under 150 words. Dense and precise.

If vague, make a reasonable assumption: state "Assuming: [assumption]" then proceed.

Write in imperative: "Fix", "Add", "Update", "Remove."

VISION MODE: When image attached — identify the component, name the problem, output the fix prompt.

MULTI-TASK: If multiple fixes described, output labeled sections:
**Fix 1: [Name]**
[prompt]
Do not change anything else.
---
**Fix 2: [Name]**
[prompt]
Do not change anything else.

If experienceLevel is FOUNDATION, add: "// [brief note on where to paste this]"

---
## MULTI-TASK QUICK PROMPTS
If multiple fixes are described, output labeled sections:

**Fix 1: [Name]**
[prompt]
Do not change anything else.

---

**Fix 2: [Name]**
[prompt]
Do not change anything else.
---`;

const DECOMPOSE_SYSTEM = `You are Axiom in DECOMPOSITION mode — the Strategic Scribe.

You are NOT writing prose. You are NOT having a conversation.
You are extracting strategic structure from a raw brain-dump or voice transcript and returning it as STRICT JSON.

Your job: read the user's input and decompose it into:
- GOALS — the "what they're trying to build/achieve" (usually 1, sometimes 2)
- MUSTS — foundational, launch-critical requirements ("I need", "must have", "has to", "won't ship without")
- SHOULDS — important but not blocking ("should", "want to", "ideally")
- COULDS — nice-to-haves ("could", "would be cool", "maybe")
- BLOCKERS — friction, obstacles, things blocked, contradictions ("but", "however", "stuck on", "can't", "blocked by")
- newDecisions — declarative architectural choices the user made in this dump ("we're using Postgres", "going with Lovable", "no third-party APIs")
- contradictions — if any new MUST/SHOULD/COULD conflicts with the existing DECISION LEDGER you'll be given, flag it

For each MUST/SHOULD/COULD, write a single sharp strategicQuestion the user MUST answer to define it. Make it specific to their dump — no generic templates. Example: instead of "What does this need?", ask "You said 'real-time notifications' — should they survive a page refresh, and who triggers them?"

For BLOCKERS, the strategicQuestion is the unblock question.

OUTPUT — return ONLY this JSON object, nothing else, no markdown fences:
{
  "goals": [{ "label": "string (under 6 words)", "strategicQuestion": "string" }],
  "musts": [{ "label": "string (under 6 words)", "strategicQuestion": "string", "dependsOn": ["label of another item if dependent"] }],
  "shoulds": [{ "label": "string", "strategicQuestion": "string" }],
  "coulds": [{ "label": "string", "strategicQuestion": "string" }],
  "blockers": [{ "label": "string", "reason": "what's blocking" }],
  "newDecisions": [{ "statement": "the locked decision in one sentence" }],
  "contradictions": [{ "nodeLabel": "matches a label above", "decisionStatement": "matches an existing ledger entry", "reason": "why these conflict" }]
}

Rules:
- Labels MUST be under 6 words. Be ruthlessly concise.
- Empty arrays are fine — don't fabricate.
- If user just rambles with no structure, still extract: maybe one GOAL, no MUSTs.
- Never include keys outside the schema. Never wrap in markdown.`;

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-5";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
    });
  }

  try {
    const { messages, builder, mode, images, experienceLevel, codebaseContext, transcript, decisionLedger: clientLedger } = await req.json();

    // ─── Rate Limiting ───────────────────────────────────────────────────────
    const RATE_LIMIT = 50;
    const WINDOW_HOURS = 24;

    const authHeader = req.headers.get("Authorization");
    let identifier = req.headers.get("x-forwarded-for") || "anonymous";

    if (authHeader) {
      try {
        const token = authHeader.replace("Bearer ", "");
        const { data: { user } } = await supabaseAdmin.auth.getUser(token);
        if (user) identifier = user.id;
      } catch {}
    }

    const windowStart = new Date(Date.now() - WINDOW_HOURS * 60 * 60 * 1000).toISOString();

    const { data: existing } = await supabaseAdmin
      .from("rate_limits")
      .select("id, call_count, window_start")
      .eq("identifier", identifier)
      .gte("window_start", windowStart)
      .single();

    if (existing) {
      if (existing.call_count >= RATE_LIMIT) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. You've used your 50 daily calls. Resets in 24 hours." }),
          { status: 429, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
        );
      }
      await supabaseAdmin
        .from("rate_limits")
        .update({ call_count: existing.call_count + 1 })
        .eq("id", existing.id);
    } else {
      await supabaseAdmin
        .from("rate_limits")
        .insert({ identifier, call_count: 1 });
    }
    // ─── End Rate Limiting ───────────────────────────────────────────────────

    // ─── Free Tier Monthly Limit ─────────────────────────────────────────────
    const FREE_MONTHLY_LIMIT = 10;
    const currentMonth = new Date().toISOString().slice(0, 7); // "2026-05"

    // Only enforce monthly limit for authenticated users (anon already rate-limited above)
    if (authHeader && identifier !== "anonymous") {
      // Check if user has an active subscription
      const { data: subscription } = await supabaseAdmin
        .from("subscriptions")
        .select("status, current_period_end")
        .eq("user_id", identifier)
        .in("status", ["active", "trialing"])
        .gte("current_period_end", new Date().toISOString())
        .limit(1)
        .maybeSingle();

      const isPro = !!subscription;

      if (!isPro) {
        // Check monthly usage for free users
        const { data: usage } = await supabaseAdmin
          .from("monthly_usage")
          .select("id, call_count")
          .eq("user_id", identifier)
          .eq("month", currentMonth)
          .maybeSingle();

        if (usage && usage.call_count >= FREE_MONTHLY_LIMIT) {
          return new Response(
            JSON.stringify({
              error: "free_limit_reached",
              message: "You've used all 10 free AI calls this month. Upgrade to Pro for unlimited sessions.",
            }),
            { status: 429, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
          );
        }

        // Increment or create monthly usage record
        if (usage) {
          await supabaseAdmin
            .from("monthly_usage")
            .update({ call_count: usage.call_count + 1 })
            .eq("id", usage.id);
        } else {
          await supabaseAdmin
            .from("monthly_usage")
            .insert({ user_id: identifier, month: currentMonth, call_count: 1 });
        }
      }
    }
    // ─── End Free Tier Monthly Limit ─────────────────────────────────────────

    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      });
    }

    // Build system prompt — quick mode + decompose mode use distinct prompts
    let systemContent =
      mode === "decompose" ? DECOMPOSE_SYSTEM :
      mode === "quick"     ? QUICK_PROMPT_SYSTEM :
                             SYSTEM_PROMPT;

    if (builder && mode !== "decompose") {
      systemContent += mode === "quick"
        ? `\n\nTarget builder: ${builder}. Format the output specifically for ${builder}.`
        : `\n\nThe user's detected builder is: ${builder}. Calibrate your responses accordingly.`;
    }
    if (mode !== "quick" && mode !== "decompose") {
      if (experienceLevel === "architect") {
        systemContent += "\n\nUSER LEVEL: ARCHITECT. Output is 90% code, 10% context. No tutorials. Drop the diff and the logic note. They know where to paste it.";
      } else if (experienceLevel === "foundation") {
        systemContent += "\n\nUSER LEVEL: FOUNDATION. Step-by-step guidance. Explain every concept when it appears. Tell them which file to open, where to paste, what to run.";
      } else {
        systemContent += "\n\nUSER LEVEL: BUILDER. Include the why inline. Show reasoning but keep momentum.";
      }
    }
    if (codebaseContext?.trim() && mode !== "decompose") {
      systemContent += `\n\n## EXISTING CODEBASE CONTEXT\nThe user has attached or loaded their codebase. Treat this as the source of truth. Do not ask to see the codebase again; use the file map and excerpts below to identify features, duplication, and merge targets.\n\n${codebaseContext.trim()}`;
    }

    // ─── Decompose mode: inject the active decision ledger so contradictions get flagged ──
    if (mode === "decompose" && Array.isArray(clientLedger) && clientLedger.length > 0) {
      const ledgerText = clientLedger
        .filter((d: any) => d?.status !== "superseded")
        .map((d: any, i: number) => `${i + 1}. ${d.statement}`)
        .join("\n");
      if (ledgerText) {
        systemContent += `\n\n## ACTIVE DECISION LEDGER (locked decisions to reconcile against)\n${ledgerText}`;
      }
    }

    // For decompose mode, build a one-shot user message from the transcript.
    const requestMessages =
      mode === "decompose"
        ? [{ role: "user", content: `Decompose this brain-dump into the schema:\n\n${transcript ?? ""}` }]
        : messages;

    const response = await fetch(ANTHROPIC_API_URL, {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: mode === "decompose" ? 2048 : 1024,
        system: systemContent,
        messages: images && images.length > 0 && mode !== "decompose"
          ? requestMessages.map((msg: any, i: number) =>
              i === requestMessages.length - 1 && msg.role === "user"
                ? {
                    role: "user",
                    content: [
                      ...images.map((img: any) => ({
                        type: "image",
                        source: { type: "base64", media_type: img.mediaType, data: img.base64 },
                      })),
                      { type: "text", text: msg.content },
                    ],
                  }
                : msg
            )
          : requestMessages,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Anthropic API error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 502,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      });
    }

    const data = await response.json();
    const aiResponse = data.content?.[0]?.text || "No response generated.";

    // Decompose mode: try to parse JSON out of the response and return it structured.
    if (mode === "decompose") {
      let decomposition: any = null;
      try {
        // Strip any accidental markdown fences
        const cleaned = aiResponse.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
        decomposition = JSON.parse(cleaned);
      } catch (e) {
        // Try to recover by finding the outermost {...}
        const match = aiResponse.match(/\{[\s\S]*\}/);
        if (match) {
          try { decomposition = JSON.parse(match[0]); } catch {}
        }
      }
      if (!decomposition) {
        return new Response(
          JSON.stringify({ error: "decomposition_parse_failed", raw: aiResponse }),
          { status: 502, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } }
        );
      }
      return new Response(JSON.stringify({ decomposition }), {
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      });
    }

    return new Response(JSON.stringify({ response: aiResponse }), {
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  }
});
