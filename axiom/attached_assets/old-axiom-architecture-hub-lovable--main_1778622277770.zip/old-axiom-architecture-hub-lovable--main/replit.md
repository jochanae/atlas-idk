# Axiom — Structural Specification Engine

An AI-driven architectural planning tool that turns unstructured ideas into complete, connected architecture.

## Tech Stack

- **Framework**: TanStack Start (SSR-capable React framework) with TanStack Router (file-based routing)
- **Build**: Vite 7 via `@lovable.dev/vite-tanstack-config`
- **Language**: TypeScript + React 19
- **Styling**: Tailwind CSS 4
- **UI Components**: Radix UI primitives + Shadcn/UI-style components
- **Backend/DB**: Supabase (Auth + Database)
- **AI**: Claude `claude-sonnet-4-5` via `src/lib/axiom-api.ts` (`createServerFn` — live path, NOT edge function)
- **Package Manager**: npm

## Project Structure

```
src/
  routes/          # File-based routing (TanStack Router)
  components/
    axiom/
      AxiomLayout.tsx    # Main layout + gear icon → Settings
      ChatHook.tsx       # AI chat interface (auto-grow textarea, glassmorphic input)
      SystemMap.tsx      # Architecture visualization
      CockpitBar.tsx     # Bottom bar + readiness strip + curved mobile footer
      FloatingPanel.tsx  # Floating 'A' panel (QuickPrompt inside)
      QuickPrompt.tsx    # Quick Prompt mode + Load Project button
      Settings.tsx       # Settings bottom sheet (5 sections)
      ProjectProfiles.tsx # Project profile CRUD (localStorage)
      VaultGrid.tsx      # Vault/history grid
    ui/            # Base Radix/Shadcn components
  hooks/
    use-axiom-store.tsx  # Global state
  lib/
    axiom-api.ts   # callAxiomChat + callQuickPrompt (server fns, Claude)
    haptics.ts     # Respects axiom_haptics_enabled localStorage key
    sounds.ts      # Respects axiom_sounds_enabled localStorage key
supabase/
  functions/axiom-chat/  # Edge function (kept in sync, not live path in dev)
  migrations/
```

## Development

- Dev server: port 5000, host 0.0.0.0 — `npm run dev`
- Build: `npm run build`

## Environment Variables

- `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` — Supabase
- `ANTHROPIC_API_KEY` — Replit Secret (used by server fn)

## localStorage Keys

| Key | Purpose |
|-----|---------|
| `axiom_default_builder` | Settings default builder (Settings panel) |
| `axiom_builder_default` | QuickPrompt last-used builder |
| `axiom_builder_freq` | QuickPrompt builder frequency map |
| `axiom_experience_level` | architect / builder / foundation |
| `axiom_haptics_enabled` | "false" to disable haptics |
| `axiom_sounds_enabled` | "false" to disable sounds |
| `axiom_project_profiles` | JSON array of ProjectProfile objects |

## Key Features

- **Chat Hook**: AI chat with auto-grow textarea, glassmorphic pocket, dynamic placeholder per focused node, platform indicator pill
- **System Map**: Visual graph of architecture components
- **Settings Panel**: Gear icon in header opens bottom sheet — Default Builder, Experience Level (architect/builder/foundation), Project Profiles, Haptics/Sound toggles, About
- **Project Profiles**: Save named project contexts (builder, stack, file structure, notes); load into QuickPrompt via "Load Project ▾"
- **Experience Level**: Injected into every AI request; adapts response density and style
- **Quick Prompt**: Builder dropdown with YOUR STACK / ALL PLATFORMS sections + frequency tracking
- **Cockpit Bar**: Readiness score, mode switcher, curved mobile footer, 3px gold readiness strip
- **Flex Mode**: Optimized layout for Samsung Z Fold 6
- **Vault**: History of past architectural specifications

## Architecture Decisions

- `createServerFn` (not edge function) is the live AI path — ANTHROPIC_API_KEY stays server-side
- `experienceLevel` appended to system prompt on every request (both `axiom-api.ts` and edge function)
- haptics/sounds check localStorage at call time (not at module load) so toggle takes effect immediately
- ProjectProfiles lives in localStorage only — no DB needed for local-first UX
- Settings panel is portal-style (fixed position), rendered once per layout variant
