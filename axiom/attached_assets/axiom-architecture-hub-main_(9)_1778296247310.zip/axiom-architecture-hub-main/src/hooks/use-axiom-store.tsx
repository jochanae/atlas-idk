import { useState, useCallback, useEffect, createContext, useContext, type ReactNode } from "react";

export type AtmosphereMode = "stealth" | "cinematic" | "studio";
export type BuilderType = "lovable" | "cursor" | "replit" | null;

export interface ArchNode {
  id: string;
  label: string;
  type: "database" | "api" | "auth" | "state" | "logic" | "ui";
  resolved: boolean;
  x: number;
  y: number;
  details?: string;
}

export interface ArchEdge {
  id: string;
  from: string;
  to: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "system";
  content: string;
  timestamp: number;
}

export interface SavedSpec {
  id: string;
  name: string;
  builder: string | null;
  score: number;
  date: string;
  nodes: ArchNode[];
  edges: ArchEdge[];
  messages: ChatMessage[];
}

interface AxiomState {
  atmosphere: AtmosphereMode;
  setAtmosphere: (m: AtmosphereMode) => void;
  detectedBuilder: BuilderType;
  setDetectedBuilder: (b: BuilderType) => void;
  nodes: ArchNode[];
  edges: ArchEdge[];
  addNode: (node: ArchNode) => void;
  resolveNode: (id: string) => void;
  addEdge: (edge: ArchEdge) => void;
  messages: ChatMessage[];
  addMessage: (msg: ChatMessage) => void;
  readinessScore: number;
  focusedNodeId: string | null;
  setFocusedNodeId: (id: string | null) => void;
  mapMinimized: boolean;
  setMapMinimized: (v: boolean) => void;
  saveToVault: (name: string) => void;
  savedSpecs: SavedSpec[];
  loadSpec: (spec: SavedSpec) => void;
  deleteSpec: (id: string) => void;
  resetSession: () => void;
}

const AxiomContext = createContext<AxiomState | null>(null);

const STORAGE_KEY = "axiom-workspace";
const VAULT_KEY = "axiom-vault";

const INITIAL_NODES: ArchNode[] = [
  { id: "auth", label: "Authentication", type: "auth", resolved: false, x: 300, y: 80 },
  { id: "db", label: "Database", type: "database", resolved: false, x: 150, y: 200 },
  { id: "api", label: "API Routes", type: "api", resolved: false, x: 450, y: 200 },
  { id: "state", label: "State Management", type: "state", resolved: false, x: 300, y: 320 },
  { id: "ui", label: "UI Components", type: "ui", resolved: false, x: 150, y: 440 },
  { id: "logic", label: "Business Logic", type: "logic", resolved: false, x: 450, y: 440 },
];

const INITIAL_EDGES: ArchEdge[] = [
  { id: "e1", from: "auth", to: "db" },
  { id: "e2", from: "auth", to: "api" },
  { id: "e3", from: "api", to: "db" },
  { id: "e4", from: "api", to: "state" },
  { id: "e5", from: "state", to: "ui" },
  { id: "e6", from: "state", to: "logic" },
  { id: "e7", from: "logic", to: "api" },
];

function loadWorkspace() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as {
      nodes: ArchNode[];
      edges: ArchEdge[];
      messages: ChatMessage[];
      atmosphere: AtmosphereMode;
      detectedBuilder: BuilderType;
    };
  } catch {
    return null;
  }
}

function loadVault(): SavedSpec[] {
  try {
    const raw = localStorage.getItem(VAULT_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as SavedSpec[];
  } catch {
    return [];
  }
}

export function AxiomProvider({ children }: { children: ReactNode }) {
  const saved = typeof window !== "undefined" ? loadWorkspace() : null;

  const [atmosphere, setAtmosphere] = useState<AtmosphereMode>(saved?.atmosphere ?? "cinematic");
  const [detectedBuilder, setDetectedBuilder] = useState<BuilderType>(saved?.detectedBuilder ?? null);
  const [nodes, setNodes] = useState<ArchNode[]>(saved?.nodes ?? INITIAL_NODES);
  const [edges, setEdges] = useState<ArchEdge[]>(saved?.edges ?? INITIAL_EDGES);
  const [messages, setMessages] = useState<ChatMessage[]>(
    saved?.messages ?? [
      {
        id: "welcome",
        role: "system",
        content: "Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?",
        timestamp: Date.now(),
      },
    ]
  );
  const [focusedNodeId, setFocusedNodeId] = useState<string | null>(null);
  const [mapMinimized, setMapMinimized] = useState(false);
  const [savedSpecs, setSavedSpecs] = useState<SavedSpec[]>(
    typeof window !== "undefined" ? loadVault() : []
  );

  // Persist workspace to localStorage
  useEffect(() => {
    const data = { nodes, edges, messages, atmosphere, detectedBuilder };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [nodes, edges, messages, atmosphere, detectedBuilder]);

  // Persist vault to localStorage
  useEffect(() => {
    localStorage.setItem(VAULT_KEY, JSON.stringify(savedSpecs));
  }, [savedSpecs]);

  const addNode = useCallback((node: ArchNode) => {
    setNodes((prev) => [...prev, node]);
  }, []);

  const resolveNode = useCallback((id: string) => {
    setNodes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, resolved: true } : n))
    );
  }, []);

  const addEdge = useCallback((edge: ArchEdge) => {
    setEdges((prev) => [...prev, edge]);
  }, []);

  const addMessage = useCallback((msg: ChatMessage) => {
    setMessages((prev) => [...prev, msg]);
    const lower = msg.content.toLowerCase();
    if (lower.includes("lovable")) setDetectedBuilder("lovable");
    else if (lower.includes("cursor")) setDetectedBuilder("cursor");
    else if (lower.includes("replit")) setDetectedBuilder("replit");

    const keywords: Record<string, string[]> = {
      auth: ["login", "auth", "sign up", "sign in", "oauth", "magic link"],
      db: ["database", "postgres", "supabase", "table", "schema"],
      api: ["api", "endpoint", "route", "rest", "graphql"],
      state: ["state", "redux", "zustand", "context", "store"],
      ui: ["component", "ui", "button", "form", "page", "layout"],
      logic: ["logic", "function", "algorithm", "calculation", "validation"],
    };
    if (msg.role === "user") {
      Object.entries(keywords).forEach(([nodeId, words]) => {
        if (words.some((w) => lower.includes(w))) {
          setNodes((prev) =>
            prev.map((n) => (n.id === nodeId ? { ...n, resolved: true } : n))
          );
        }
      });
    }
  }, []);

  const readinessScore = Math.round(
    (nodes.filter((n) => n.resolved).length / Math.max(nodes.length, 1)) * 100
  );

  const saveToVault = useCallback((name: string) => {
    const spec: SavedSpec = {
      id: crypto.randomUUID(),
      name,
      builder: detectedBuilder,
      score: readinessScore,
      date: new Date().toISOString().split("T")[0],
      nodes,
      edges,
      messages,
    };
    setSavedSpecs((prev) => [spec, ...prev]);
  }, [detectedBuilder, readinessScore, nodes, edges, messages]);

  const loadSpec = useCallback((spec: SavedSpec) => {
    setNodes(spec.nodes);
    setEdges(spec.edges);
    setMessages(spec.messages);
    setDetectedBuilder(spec.builder as BuilderType);
  }, []);

  const deleteSpec = useCallback((id: string) => {
    setSavedSpecs((prev) => prev.filter((s) => s.id !== id));
  }, []);

  const resetSession = useCallback(() => {
    setNodes(INITIAL_NODES.map((n) => ({ ...n, resolved: false })));
    setEdges(INITIAL_EDGES);
    setDetectedBuilder(null);
    setMessages([
      {
        id: "welcome",
        role: "system",
        content: "Welcome to Axiom. Before we build anything — what are you building, and which platform are you taking it to?",
        timestamp: Date.now(),
      },
    ]);
  }, []);

  return (
    <AxiomContext.Provider
      value={{
        atmosphere, setAtmosphere,
        detectedBuilder, setDetectedBuilder,
        nodes, edges, addNode, resolveNode, addEdge,
        messages, addMessage,
        readinessScore,
        focusedNodeId, setFocusedNodeId,
        mapMinimized, setMapMinimized,
        saveToVault, savedSpecs, loadSpec, deleteSpec, resetSession,
      }}
    >
      {children}
    </AxiomContext.Provider>
  );
}

export function useAxiom() {
  const ctx = useContext(AxiomContext);
  if (!ctx) throw new Error("useAxiom must be used within AxiomProvider");
  return ctx;
}
