import React, { useState, useRef, useEffect } from "react";
import { useAxiom, type ChatMessage } from "@/hooks/use-axiom-store";
import { supabase } from "@/integrations/supabase/client";
import { callAxiomChat } from "@/lib/axiom-api";
import { loadProfilesAsync, markProfileUsed, type ProjectProfile } from "./ProjectProfiles";
import ReactMarkdown from "react-markdown";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";
import { useUpgradeGate } from "@/hooks/use-upgrade-gate";
import { useSubscription as useSubscriptionHook } from "@/hooks/use-subscription";
import JSZip from "jszip";

// ─── Image attachment types ──────────────────────────────────────────────────

interface AttachedImage {
  id: string;
  base64: string;
  mediaType: string;
  preview: string;
  name: string;
}

const MAX_IMG_MB = 5;
const MAX_CODEBASE_MB = 25;
const CODEBASE_CONTEXT_KEY = "axiom_codebase_context";
const CODEBASE_EXTENSIONS = new Set([
  ".ts", ".tsx", ".js", ".jsx", ".css", ".scss", ".html", ".json", ".md", ".sql",
]);
const CODEBASE_IMPORTANT_FILES = new Set([
  "package.json", "vite.config.ts", "src/router.tsx", "src/routes/index.tsx", "src/routes/__root.tsx",
]);
const CODEBASE_IGNORED_SEGMENTS = new Set([
  "node_modules", ".git", "dist", "build", ".next", ".turbo", "coverage", "vendor",
]);

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(file);
  });
}

function isCodebaseArchive(file: File) {
  return file.name.toLowerCase().endsWith(".zip") || file.type === "application/zip" || file.type === "application/x-zip-compressed";
}

function shouldIncludeZipPath(path: string) {
  const cleanPath = path.replace(/^\/+/, "");
  const parts = cleanPath.split("/");
  if (parts.some((part) => CODEBASE_IGNORED_SEGMENTS.has(part))) return false;
  const fileName = parts[parts.length - 1];
  if (!fileName || fileName.startsWith(".")) return false;
  const dot = fileName.lastIndexOf(".");
  const ext = dot >= 0 ? fileName.slice(dot).toLowerCase() : "";
  return CODEBASE_IMPORTANT_FILES.has(cleanPath) || CODEBASE_EXTENSIONS.has(ext);
}

function isImportantProjectFile(path: string) {
  const parts = path.replace(/^\/+/, "").split("/");
  const withoutArchiveRoot = parts.length > 1 ? parts.slice(1).join("/") : parts[0];
  return CODEBASE_IMPORTANT_FILES.has(path) || CODEBASE_IMPORTANT_FILES.has(withoutArchiveRoot);
}

function summarizePaths(paths: string[]) {
  return paths.slice(0, 180).map((path) => `- ${path}`).join("\n") + (paths.length > 180 ? `\n- …${paths.length - 180} more files` : "");
}

async function extractCodebaseContext(file: File) {
  if (file.size > MAX_CODEBASE_MB * 1024 * 1024) {
    throw new Error(`ZIP is larger than ${MAX_CODEBASE_MB}MB`);
  }

  const zip = await JSZip.loadAsync(file);
  const paths = Object.keys(zip.files)
    .filter((path) => !zip.files[path].dir)
    .map((path) => path.replace(/^\/+/, ""))
    .filter(shouldIncludeZipPath)
    .sort();

  const excerptPaths = paths
    .filter((path) => isImportantProjectFile(path) || /\/(App|Index|Home|Dashboard|Layout|Header|Pricing|Auth)[^/]*\.(tsx|ts|jsx|js)$/i.test(path))
    .slice(0, 14);

  const excerpts: string[] = [];
  let budget = 18000;
  for (const path of excerptPaths) {
    if (budget <= 0) break;
    const entry = zip.files[path];
    if (!entry) continue;
    const text = (await entry.async("text")).slice(0, Math.min(1800, budget));
    budget -= text.length;
    excerpts.push(`--- ${path} ---\n${text}`);
  }

  return [
    `Uploaded codebase archive: ${file.name}`,
    `File map (${paths.length} relevant files):\n${summarizePaths(paths)}`,
    excerpts.length ? `Key file excerpts:\n\n${excerpts.join("\n\n")}` : "",
  ].filter(Boolean).join("\n\n");
}

// ─── Form modules ───────────────────────────────────────────────────────────

const FORM_MODULES: Record<string, { label: string; options: string[] }> = {
  login: { label: "Auth Provider", options: ["Google", "Email/Password", "Magic Link"] },
  database: { label: "Database Type", options: ["PostgreSQL", "MongoDB", "SQLite"] },
  payments: { label: "Payment Provider", options: ["Stripe", "Paddle", "LemonSqueezy"] },
  storage: { label: "File Storage", options: ["S3", "Supabase Storage", "Cloudflare R2"] },
  email: { label: "Email Service", options: ["Resend", "SendGrid", "Postmark"] },
};

// ─── Node resolution keywords ────────────────────────────────────────────────

const NODE_KEYWORDS: Record<string, string[]> = {
  auth: ["access logic", "auth", "login", "sign in", "oauth", "magic link", "identity"],
  db: ["data layer", "schema", "database", "table", "entity", "supabase", "postgres"],
  api: ["api", "route", "endpoint", "edge function", "rest"],
  state: ["state", "sprint 2", "flow", "logic"],
  ui: ["shell", "sprint 3", "layout", "component", "responsive"],
  logic: ["revenue", "payment", "stripe", "webhook", "cron", "trigger"],
};

// ─── Keyword definitions ─────────────────────────────────────────────────────

const KEYWORD_DEFINITIONS: Record<string, string> = {
  "auth": "Authentication verifies who a user is before granting access. Common methods: Email/Password, Google OAuth, or Magic Link (passwordless).",
  "auth method": "How users prove their identity. Choosing the wrong method early is expensive to change later.",
  "schema": "The blueprint of your database — defines what tables exist, what columns they have, and how they relate to each other.",
  "database": "Where your app's data lives permanently. Tables store structured information like users, orders, or tasks.",
  "entity": "A real-world object your app needs to track. Users, Orders, Tasks, and Projects are all examples of entities.",
  "relationships": "How database tables connect to each other. Example: a Task belongs to a Project, a Project belongs to a User.",
  "privacy model": "Rules that control who can see what data. Critical for multi-user apps — gets complex fast if not defined early.",
  "api": "Application Programming Interface — the layer between your frontend UI and your database. Routes data in and out.",
  "api routes": "The specific paths your app uses to send and receive data. Example: POST /tasks creates a task, GET /tasks lists them.",
  "state management": "How your app remembers information while a user is actively using it — before anything is saved to the database.",
  "state": "Temporary data your app holds in memory during a session. Forms, selections, and UI state all live here.",
  "middleware": "Code that runs between a request arriving and your app responding — used for auth checks, logging, and validation.",
  "edge function": "A small serverless function that runs close to the user for speed. Supabase Edge Functions handle backend logic without a full server.",
  "webhook": "An automatic notification sent from one system to another when something happens. Example: Stripe notifies your app when a payment succeeds.",
  "validation": "Rules that check if data is correct before saving it. Prevents bad data from entering your database.",
  "rls": "Row Level Security — Supabase's system for ensuring users can only access their own data in the database.",
  "supabase": "Your backend platform — handles database, authentication, file storage, and serverless functions in one place.",
  "oauth": "Open Authorization — a secure way to let users log in with an existing account like Google or GitHub without sharing their password.",
  "sprint": "A focused phase of the Axiom interrogation. Sprint 1 covers data, Sprint 2 covers logic, Sprint 3 covers the shell.",
};

const SORTED_KEYWORDS = Object.keys(KEYWORD_DEFINITIONS).sort((a, b) => b.length - a.length);
const KW_REGEX = new RegExp(
  `(${SORTED_KEYWORDS.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`,
  "gi"
);

// ─── Sprint card types & constants ───────────────────────────────────────────

interface SprintQuestion {
  label: string;
  question: string;
}

const CARD_TO_NODE_MAP: Record<string, string> = {
  "users": "auth",
  "auth method": "auth",
  "auth": "auth",
  "task entity": "db",
  "entity": "db",
  "database": "db",
  "schema": "db",
  "relationships": "db",
  "privacy model": "db",
  "primary user action": "logic",
  "core loop": "logic",
  "edge cases": "logic",
  "payment layer": "logic",
  "revenue": "logic",
  "triggered events": "api",
  "webhooks": "api",
  "notifications": "api",
  "protected routes": "api",
  "api routes": "api",
  "responsive layout": "ui",
  "layout": "ui",
  "screens": "ui",
  "deployment": "api",
  "integrations": "api",
};

// ─── Sprint detection helpers ────────────────────────────────────────────────

function parseSprintQuestions(text: string): SprintQuestion[] | null {
  // Primary: **Label**: Question?
  const boldRegex = /\*\*([^*]+)\*\*:\s*([^?\n]*\?)/g;
  const bold: SprintQuestion[] = [];
  let m: RegExpExecArray | null;
  while ((m = boldRegex.exec(text)) !== null) {
    bold.push({ label: m[1].trim(), question: m[2].trim() });
  }
  if (bold.length >= 2) return bold;

  // Secondary: numbered list ending in ?
  const numberedRegex = /^\d+\.\s+(.+\?)\s*$/gm;
  const numbered: SprintQuestion[] = [];
  let i = 1;
  while ((m = numberedRegex.exec(text)) !== null) {
    numbered.push({ label: `Question ${i++}`, question: m[1].trim() });
  }
  if (numbered.length >= 2) return numbered;

  return null;
}

function extractSprintHeader(text: string, questions: SprintQuestion[]): string {
  if (questions.length === 0) return "";
  const firstLabel = questions[0].label;
  const boldIdx = text.indexOf(`**${firstLabel}**:`);
  if (boldIdx > 0) return text.slice(0, boldIdx).trim();
  const numIdx = text.search(/^\d+\./m);
  if (numIdx > 0) return text.slice(0, numIdx).trim();
  return "";
}

// ─── Strip markdown (for copy) ───────────────────────────────────────────────

function stripMarkdown(text: string): string {
  return text
    .replace(/#{1,6}\s+/g, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/\*(.*?)\*/g, "$1")
    .replace(/`{3}[\s\S]*?`{3}/g, (m) => m.replace(/`{3}[^\n]*\n?/g, "").replace(/\n?`{3}/g, ""))
    .replace(/`([^`]+)`/g, "$1")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/^\s*---+\s*$/gm, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ─── Keyword processing helpers ──────────────────────────────────────────────

function processTextForKeywords(
  text: string,
  activeKw: string | null,
  setActiveKw: (k: string | null) => void
): React.ReactNode[] {
  const parts = text.split(KW_REGEX);
  return parts
    .map((part, i) => {
      if (!part) return null;
      const lowerPart = part.toLowerCase();
      const def = KEYWORD_DEFINITIONS[lowerPart];
      if (def !== undefined) {
        const isOpen = activeKw === lowerPart;
        return (
          <span key={i}>
            <span
              role="button"
              tabIndex={0}
              onClick={() => { haptics.tap(); sounds.tap(); setActiveKw(isOpen ? null : lowerPart); }}
              onKeyDown={(e) => { if (e.key === "Enter") { haptics.tap(); sounds.tap(); setActiveKw(isOpen ? null : lowerPart); } }}
              style={{
                color: "#D4AF37",
                fontWeight: 500,
                cursor: "pointer",
                textDecoration: "underline",
                textDecorationColor: "rgba(212,175,55,0.4)",
                textUnderlineOffset: "2px",
              }}
            >
              {part}
            </span>
            {isOpen && (
              <span
                style={{
                  display: "block",
                  marginTop: 4,
                  marginBottom: 4,
                  background: "rgba(212, 175, 55, 0.08)",
                  border: "1px solid rgba(212, 175, 55, 0.25)",
                  borderLeft: "3px solid #D4AF37",
                  borderRadius: 8,
                  padding: "8px 12px",
                  fontSize: 12,
                  color: "#9ca3af",
                  lineHeight: 1.5,
                }}
              >
                {def}
              </span>
            )}
          </span>
        );
      }
      return <span key={i}>{part}</span>;
    })
    .filter(Boolean) as React.ReactNode[];
}

function processChildren(
  children: React.ReactNode,
  activeKw: string | null,
  setActiveKw: (k: string | null) => void
): React.ReactNode {
  if (typeof children === "string") {
    return <>{processTextForKeywords(children, activeKw, setActiveKw)}</>;
  }
  if (Array.isArray(children)) {
    return (
      <>
        {children.map((child, i) => {
          if (typeof child === "string") {
            return (
              <React.Fragment key={i}>
                {processTextForKeywords(child, activeKw, setActiveKw)}
              </React.Fragment>
            );
          }
          return <React.Fragment key={i}>{child}</React.Fragment>;
        })}
      </>
    );
  }
  return children;
}

// ─── Utility helpers ─────────────────────────────────────────────────────────

function detectModule(text: string): string | null {
  const lower = text.toLowerCase();
  if (lower.includes("login") || lower.includes("auth") || lower.includes("sign")) return "login";
  if (lower.includes("database") || lower.includes("db") || lower.includes("postgres")) return "database";
  if (lower.includes("payment") || lower.includes("stripe") || lower.includes("billing")) return "payments";
  if (lower.includes("upload") || lower.includes("storage") || lower.includes("file")) return "storage";
  if (lower.includes("email") || lower.includes("notification")) return "email";
  return null;
}

function resolveNodesFromResponse(text: string, resolveNode: (id: string) => void) {
  const lower = text.toLowerCase();
  Object.entries(NODE_KEYWORDS).forEach(([nodeId, words]) => {
    if (words.some((w) => lower.includes(w))) resolveNode(nodeId);
  });
}

// ─── SprintCardMessage ───────────────────────────────────────────────────────

function SprintCardMessage({
  questions,
  headerText,
  onCompile,
  resolveNode,
  activeKw,
  setActiveKw,
}: {
  questions: SprintQuestion[];
  headerText: string;
  onCompile: (text: string) => void;
  resolveNode: (id: string) => void;
  activeKw: string | null;
  setActiveKw: (k: string | null) => void;
}) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [openCard, setOpenCard] = useState<string | null>(null);
  const [draftInput, setDraftInput] = useState("");
  const draftRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (openCard && draftRef.current) {
      draftRef.current.focus();
    }
  }, [openCard]);

  const allAnswered = questions.every((q) => q.label in answers);

  const handleConfirm = (label: string) => {
    if (!draftInput.trim()) return;
    const answer = draftInput.trim();
    setAnswers((prev) => ({ ...prev, [label]: answer }));
    setDraftInput("");
    setOpenCard(null);
    haptics.cardConfirmed();
    sounds.cardConfirmed();
    const nodeId = CARD_TO_NODE_MAP[label.toLowerCase()];
    if (nodeId) {
      resolveNode(nodeId);
      haptics.nodeResolved();
      sounds.nodeResolved();
    }
  };

  const handleSkip = (label: string) => {
    setAnswers((prev) => ({ ...prev, [label]: "(skipped)" }));
    setDraftInput("");
    setOpenCard(null);
  };

  const handleCardTap = (label: string) => {
    if (openCard === label) {
      setOpenCard(null);
      setDraftInput("");
    } else {
      const existing = answers[label];
      setOpenCard(label);
      setDraftInput(existing === "(skipped)" ? "" : existing || "");
    }
  };

  const handleCompile = () => {
    const compiled = questions
      .map((q) => `${q.label}: ${answers[q.label] || "(skipped)"}`)
      .join("\n");
    onCompile(compiled);
  };

  return (
    <div>
      {/* Intro / header text */}
      {headerText && (
        <div style={{ marginBottom: 12, fontSize: 13, color: "#9ca3af", lineHeight: 1.6 }}>
          {renderContent(headerText, "system", activeKw, setActiveKw, undefined)}
        </div>
      )}

      {/* Question cards */}
      {questions.map((q) => {
        const isAnswered = q.label in answers && answers[q.label] !== "(skipped)";
        const isSkipped = answers[q.label] === "(skipped)";
        const isOpen = openCard === q.label;

        return (
          <div key={q.label} style={{ marginBottom: 6 }}>
            {/* Card */}
            <div
              role="button"
              tabIndex={0}
              onClick={() => handleCardTap(q.label)}
              onKeyDown={(e) => e.key === "Enter" && handleCardTap(q.label)}
              style={{
                background: isAnswered
                  ? "rgba(212, 175, 55, 0.10)"
                  : "rgba(212, 175, 55, 0.06)",
                border: isOpen
                  ? "1px solid rgba(212, 175, 55, 0.5)"
                  : isAnswered
                  ? "1px solid rgba(212, 175, 55, 0.4)"
                  : "1px solid rgba(212, 175, 55, 0.2)",
                borderLeft: isAnswered
                  ? "3px solid #D4AF37"
                  : isOpen
                  ? "3px solid rgba(212,175,55,0.5)"
                  : "3px solid transparent",
                borderRadius: 10,
                padding: "12px 14px",
                cursor: "pointer",
                transition: "border 150ms, background 150ms",
                userSelect: "none",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    color: "#D4AF37",
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                  }}
                >
                  {q.label}
                </span>
                <span
                  style={{
                    fontSize: 13,
                    color: isAnswered ? "#D4AF37" : isSkipped ? "#6b7280" : "#374151",
                    lineHeight: 1,
                  }}
                >
                  {isAnswered ? "✓" : isSkipped ? "–" : "○"}
                </span>
              </div>
              <div style={{ fontSize: 12, color: "#9ca3af", marginTop: 5, lineHeight: 1.5 }}>
                {q.question}
              </div>
              {isAnswered && (
                <div style={{ fontSize: 11, color: "#6b7280", marginTop: 6, fontStyle: "italic" }}>
                  → {answers[q.label]}
                </div>
              )}
              {isSkipped && (
                <div style={{ fontSize: 11, color: "#4b5563", marginTop: 6, fontStyle: "italic" }}>
                  → skipped
                </div>
              )}
            </div>

            {/* Inline answer input — expands below card */}
            {isOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                style={{
                  marginTop: 3,
                  padding: "10px 12px",
                  background: "rgba(255,255,255,0.025)",
                  border: "1px solid rgba(212, 175, 55, 0.18)",
                  borderRadius: 8,
                }}
              >
                <input
                  ref={draftRef}
                  type="text"
                  value={draftInput}
                  onChange={(e) => setDraftInput(e.target.value)}
                  onKeyDown={(e) => {
                    e.stopPropagation();
                    if (e.key === "Enter") handleConfirm(q.label);
                  }}
                  placeholder="Your answer..."
                  style={{
                    width: "100%",
                    background: "transparent",
                    border: "none",
                    outline: "none",
                    fontSize: 12,
                    color: "#e5e7eb",
                    marginBottom: 8,
                    padding: 0,
                  }}
                />
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleConfirm(q.label); }}
                    disabled={!draftInput.trim()}
                    style={{
                      flex: 1,
                      background: draftInput.trim() ? "#D4AF37" : "rgba(212,175,55,0.25)",
                      border: "none",
                      borderRadius: 6,
                      padding: "7px 0",
                      fontSize: 11,
                      fontWeight: 700,
                      color: "#14120e",
                      cursor: draftInput.trim() ? "pointer" : "not-allowed",
                      transition: "background 150ms",
                    }}
                  >
                    Confirm
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleSkip(q.label); }}
                    style={{
                      flex: 1,
                      background: "transparent",
                      border: "1px solid rgba(255,255,255,0.10)",
                      borderRadius: 6,
                      padding: "7px 0",
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#6b7280",
                      cursor: "pointer",
                    }}
                  >
                    Skip
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* Send All Answers — appears when every card is answered or skipped */}
      {allAnswered && (
        <button
          onClick={handleCompile}
          style={{
            width: "100%",
            marginTop: 10,
            background: "#D4AF37",
            border: "none",
            borderRadius: 8,
            padding: "11px 0",
            fontSize: 13,
            fontWeight: 700,
            color: "#14120e",
            cursor: "pointer",
            letterSpacing: "0.02em",
          }}
        >
          Send All Answers →
        </button>
      )}
    </div>
  );
}

// ─── CopyButton ──────────────────────────────────────────────────────────────

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const clean = stripMarkdown(text);
    try {
      await navigator.clipboard.writeText(clean);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = clean;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex justify-end mt-2 pt-1.5 border-t border-gold/10">
      <button
        onClick={handleCopy}
        style={{ minHeight: 32, minWidth: 32 }}
        className={`flex items-center gap-1 rounded px-2 py-0.5 text-[11px] transition-colors ${
          copied ? "text-gold" : "text-silver-muted hover:text-gold"
        }`}
      >
        {copied ? (
          <span className="font-medium">Copied ✓</span>
        ) : (
          <>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
              <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
            </svg>
            <span>Copy</span>
          </>
        )}
      </button>
    </div>
  );
}

// ─── MessageActionBar ────────────────────────────────────────────────────────

function MessageActionBar({
  msg,
  isLatestAI,
  onRegenerate,
  isTyping,
}: {
  msg: ChatMessage;
  isLatestAI: boolean;
  onRegenerate: () => void;
  isTyping: boolean;
}) {
  const { detectedBuilder, readinessScore } = useAxiom();
  const { openUpgrade } = useUpgradeGate();
  const { status: subStatus } = useSubscriptionHook();
  const [savedMsg, setSavedMsg] = useState(false);
  const [savingMsg, setSavingMsg] = useState(false);

  const handleSaveMsg = async () => {
    if (subStatus === "free") {
      openUpgrade("Vault access requires Pro");
      return;
    }
    if (savingMsg) return;
    setSavingMsg(true);
    try {
      const { error } = await supabase.from("legacy_log").insert({
        prompt_output: msg.content,
        builder: detectedBuilder,
        compatibility_score: readinessScore,
      });
      if (error) throw error;
      setSavedMsg(true);
      setTimeout(() => setSavedMsg(false), 2000);
    } catch (e) {
      console.error("Save to vault failed:", e);
    } finally {
      setSavingMsg(false);
    }
  };

  return (
    <div className="flex items-center gap-2 pt-1.5 pl-1">
      {isLatestAI && (
        <button
          onClick={onRegenerate}
          disabled={isTyping}
          className="flex items-center gap-1 text-xs text-silver-muted hover:text-gold transition-colors disabled:opacity-30"
          style={{ minHeight: "36px", minWidth: "36px" }}
          title="Regenerate"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 2v6h-6" /><path d="M3 12a9 9 0 0115.36-6.36L21 8" />
            <path d="M3 22v-6h6" /><path d="M21 12a9 9 0 01-15.36 6.36L3 16" />
          </svg>
        </button>
      )}
      <button
        onClick={handleSaveMsg}
        disabled={savingMsg}
        className="flex items-center gap-1 text-xs transition-colors disabled:opacity-40"
        style={{
          minHeight: "36px", minWidth: "36px",
          color: savedMsg ? "#D4AF37" : "rgba(156,163,175,0.6)",
        }}
        title="Save to Vault"
      >
        <span style={{ fontSize: 13, lineHeight: 1, transition: "color 200ms" }}>◆</span>
        <span className="text-[10px]" style={{ transition: "opacity 200ms", opacity: savedMsg ? 1 : 0, position: "absolute", marginLeft: 16, whiteSpace: "nowrap", color: "#D4AF37" }}>
          Saved to Vault
        </span>
      </button>
    </div>
  );
}

// ─── ChatHook (main component) ───────────────────────────────────────────────

export function ChatHook() {
  const { messages, addMessage, atmosphere, focusedNodeId, setFocusedNodeId, detectedBuilder, resolveNode, readinessScore, resetSession, nodes } = useAxiom();
  const [input, setInput] = useState("");
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [activeKw, setActiveKw] = useState<string | null>(null);
  const [inputFocused, setInputFocused] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const sessionIdRef = useRef<string>(crypto.randomUUID());
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [attachedImages, setAttachedImages] = useState<AttachedImage[]>([]);
  const [attachedContextName, setAttachedContextName] = useState<string | null>(null);
  const [contextError, setContextError] = useState<string | null>(null);
  const [imagesByMsgId, setImagesByMsgId] = useState<Record<string, string[]>>({});
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [voiceToast, setVoiceToast] = useState(false);
  const [mapDropdownOpen, setMapDropdownOpen] = useState(false);
  const [expandedNodeId, setExpandedNodeId] = useState<string | null>(null);
  const [nudgeDismissed, setNudgeDismissed] = useState(false);
  const [nudgeProfiles, setNudgeProfiles] = useState<ProjectProfile[]>([]);
  const recognitionRef = useRef<any>(null);

  const speechSupported = typeof window !== "undefined" && (
    "SpeechRecognition" in window || "webkitSpeechRecognition" in window
  );

  const handleMicClick = () => {
    if (!speechSupported) {
      setVoiceToast(true);
      setTimeout(() => setVoiceToast(false), 2000);
      return;
    }
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SR();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setInput((prev) => prev ? prev + " " + transcript : transcript);
    };
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
  };

  const autoResize = () => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    const maxH = 20 * 6 + 16;
    el.style.height = Math.min(el.scrollHeight, maxH) + "px";
  };

  useEffect(() => { autoResize(); }, [input]);

  const NODE_PLACEHOLDERS: Record<string, string> = {
    auth: "Describe your auth flow...",
    db: "Describe your data structure...",
    api: "Define your API routes and triggers...",
    state: "Map out your app logic and flow...",
    ui: "What component are we building?",
    logic: "Define your revenue and logic layer...",
  };
  const inputPlaceholder = (focusedNodeId && NODE_PLACEHOLDERS[focusedNodeId]) || "Define your intent…";

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const zipFile = selectedFiles.find(isCodebaseArchive);

    if (zipFile) {
      try {
        const context = await extractCodebaseContext(zipFile);
        localStorage.setItem(CODEBASE_CONTEXT_KEY, context);
        setAttachedContextName(zipFile.name);
        setContextError(null);
        haptics.cardConfirmed();
        sounds.cardConfirmed();
      } catch (err) {
        console.error("Codebase ZIP parse failed:", err);
        setContextError("Couldn’t read that ZIP. Try a smaller source-code archive.");
      }
    }

    const files = selectedFiles.filter((file) => file.type.startsWith("image/")).slice(0, 10 - attachedImages.length);
    const results: AttachedImage[] = [];
    for (const file of files) {
      if (file.size > MAX_IMG_MB * 1024 * 1024) continue;
      const dataUrl = await fileToBase64(file);
      results.push({
        id: crypto.randomUUID(),
        base64: dataUrl.split(",")[1],
        mediaType: file.type,
        preview: dataUrl,
        name: file.name,
      });
    }
    if (results.length > 0) {
      haptics.tap();
      sounds.tap();
      setAttachedImages((prev) => [...prev, ...results].slice(0, 10));
    }
    e.target.value = "";
  };

  const removeImage = (id: string) => {
    haptics.tap();
    sounds.tap();
    setAttachedImages((prev) => prev.filter((img) => img.id !== id));
  };

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    setActiveModule(detectModule(input));
  }, [input]);

  // Load profiles for the nudge — check once when user sends first message
  useEffect(() => {
    if (nudgeDismissed) return;
    const userMsgCount = messages.filter(m => m.role === "user").length;
    if (userMsgCount === 1 && nudgeProfiles.length === 0) {
      loadProfilesAsync().then(profiles => {
        if (profiles.length > 0) setNudgeProfiles(profiles);
      });
    }
  }, [messages, nudgeDismissed, nudgeProfiles.length]);

  const handleNudgeLoad = (profile: ProjectProfile) => {
    const parts = [
      profile.techStack ? `Tech stack:\n${profile.techStack}` : "",
      profile.fileStructure ? `File structure:\n${profile.fileStructure}` : "",
      profile.notes ? `Notes:\n${profile.notes}` : "",
    ].filter(Boolean);
    const contextText = parts.join("\n\n");
    if (contextText) {
      try { localStorage.setItem("axiom_codebase_context", contextText); } catch {}
    }
    if (profile.builder) {
      try { localStorage.setItem("axiom_default_builder", profile.builder); } catch {}
    }
    markProfileUsed(profile.id);
    addMessage({
      id: crypto.randomUUID(),
      role: "system",
      content: `Project loaded: **${profile.name}**${profile.builder ? ` — targeting ${profile.builder}` : ""}. Context applied to this session.`,
      timestamp: Date.now(),
    });
    haptics.cardConfirmed();
    sounds.cardConfirmed();
    setNudgeDismissed(true);
  };

  useEffect(() => {
    try {
      const spec = localStorage.getItem("axiom_inject_spec");
      if (spec) {
        addMessage({ id: crypto.randomUUID(), role: "system", content: `Loaded from Vault:\n\n${spec}`, timestamp: Date.now() });
        localStorage.removeItem("axiom_inject_spec");
      }
    } catch {}
  }, []);

  const callAxiomAI = async (userContent: string, images: AttachedImage[] = []) => {
    setIsTyping(true);
    try {
      const apiMessages = messages
        .filter((m) => m.id !== "welcome")
        .map((m) => ({
          role: m.role === "system" ? "assistant" as const : "user" as const,
          content: m.content,
        }));
      apiMessages.push({ role: "user" as const, content: userContent });

      const experienceLevel = (() => { try { return localStorage.getItem("axiom_experience_level") || "builder"; } catch { return "builder"; } })();
      const savedDefaultBuilder = (() => { try { return localStorage.getItem("axiom_default_builder") || undefined; } catch { return undefined; } })();
      const codebaseContext = (() => { try { return localStorage.getItem(CODEBASE_CONTEXT_KEY) || undefined; } catch { return undefined; } })();

      const aiResponse = await callAxiomChat({
        data: {
          messages: apiMessages,
          builder: detectedBuilder || savedDefaultBuilder || undefined,
          images: images.length > 0 ? images.map((img) => ({ base64: img.base64, mediaType: img.mediaType })) : undefined,
          experienceLevel,
          codebaseContext,
        },
      });

      addMessage({
        id: crypto.randomUUID(),
        role: "system",
        content: aiResponse,
        timestamp: Date.now(),
      });

      resolveNodesFromResponse(aiResponse, resolveNode);
      haptics.nodeResolved();
      sounds.nodeResolved();

      const lowerResponse = aiResponse.toLowerCase();
      if (lowerResponse.includes("golden specification")) {
        haptics.specComplete();
        sounds.specComplete();
      } else if (lowerResponse.includes("context shift")) {
        haptics.contextShift();
        sounds.contextShift();
      }

      const isSprintRelated =
        lowerResponse.includes("sprint") ||
        lowerResponse.includes("architecture locked") ||
        lowerResponse.includes("schema") ||
        lowerResponse.includes("golden specification");

      if (isSprintRelated) {
        try {
          const allMessages = [
            ...messages.filter((m) => m.id !== "welcome"),
            { role: "system" as const, content: aiResponse },
          ];
          const fullText = allMessages
            .map((m) => `${m.role === "user" ? "YOU" : "AXIOM"}: ${m.content}`)
            .join("\n\n");
          await supabase.from("legacy_log").insert({
            prompt_output: fullText,
            builder: detectedBuilder,
            compatibility_score: readinessScore,
          });
        } catch (e) {
          console.error("Autosave failed:", e);
        }
      }
    } catch (err: any) {
      console.error("Axiom AI error:", err);
      const errMsg = err?.message || "";
      const isFreeLimit = errMsg.includes("free_limit_reached") || errMsg.includes("10 free AI calls");
      const isRateLimit = errMsg.includes("Rate limit") || errMsg.includes("429") || errMsg.includes("daily limit");
      addMessage({
        id: crypto.randomUUID(),
        role: "system",
        content: isFreeLimit
          ? "You've used all 10 free AI calls this month. Upgrade to Axiom Pro for unlimited sessions — $19/month or $190/year."
          : isRateLimit
            ? "You've reached your daily limit of 50 AI calls. Your limit resets in 24 hours. Upgrade to Pro for unlimited sessions."
            : "Axiom encountered an issue. Please try again.",
        timestamp: Date.now(),
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleSend = () => {
    if ((!input.trim() && attachedImages.length === 0 && !attachedContextName) || isTyping) return;
    const content = input.trim() || (attachedContextName ? "Please analyze the attached codebase." : "Please analyze the attached image(s).");
    const msgId = crypto.randomUUID();
    addMessage({ id: msgId, role: "user", content, timestamp: Date.now() });
    if (attachedImages.length > 0) {
      setImagesByMsgId((prev) => ({ ...prev, [msgId]: attachedImages.map((img) => img.preview) }));
      haptics.cardConfirmed();
      sounds.cardConfirmed();
    }
    const imagesToSend = [...attachedImages];
    setInput("");
    setAttachedImages([]);
    setAttachedContextName(null);
    setActiveModule(null);
    callAxiomAI(content, imagesToSend);
  };

  const handleModuleSelect = (option: string) => {
    const text = `${input} → ${option}`;
    setInput("");
    const content = text.trim();
    addMessage({ id: crypto.randomUUID(), role: "user", content, timestamp: Date.now() });
    setActiveModule(null);
    callAxiomAI(content);
  };

  const handleRegenerate = () => {
    const lastUserMsg = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUserMsg || isTyping) return;
    callAxiomAI(lastUserMsg.content);
  };

  // Called by SprintCardMessage when "Send All Answers" is tapped
  const handleCompileAnswers = (compiled: string) => {
    setInput(compiled);
    setTimeout(() => {
      inputRef.current?.focus();
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    }, 50);
  };

  const latestAIMsgId = [...messages].reverse().find((m) => m.role === "system" && m.id !== "welcome")?.id;
  const animClass = atmosphere === "studio" || atmosphere === "cinematic" ? "animate-ghost-type" : "";

  return (
    <div className="flex h-full flex-col relative">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border/50 px-4 py-3">
        <button
          onClick={() => setMapDropdownOpen(!mapDropdownOpen)}
          style={{
            width: 10,
            height: 10,
            borderRadius: "50%",
            border: "none",
            cursor: "pointer",
            padding: 0,
            flexShrink: 0,
            background: readinessScore >= 100
              ? "#D4AF37"
              : readinessScore > 0
                ? "#D4AF37"
                : "#D4AF37",
            boxShadow: readinessScore >= 100
              ? "0 0 8px rgba(212,175,55,0.8)"
              : readinessScore > 0
                ? "0 0 6px rgba(212,175,55,0.5)"
                : "0 0 4px rgba(212,175,55,0.3)",
            animation: readinessScore >= 100
              ? "gold-pulse 1.5s ease-in-out infinite"
              : readinessScore > 0
                ? "gold-pulse 2.5s ease-in-out infinite"
                : "amber-pulse 3s ease-in-out infinite",
            transition: "all 300ms",
          }}
          title="View system map"
        />
        <span className="text-sm font-semibold text-gold">INTENT CAPTURE</span>

        <div className="ml-auto flex items-center gap-2">
          {confirmReset ? (
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-silver-muted whitespace-nowrap">Clear this session?</span>
              <button
                onClick={() => { haptics.sessionCleared(); sounds.sessionCleared(); resetSession(); setConfirmReset(false); setActiveKw(null); setAttachedImages([]); setImagesByMsgId({}); }}
                className="rounded border border-gold/50 bg-gold/10 px-2 py-0.5 text-[10px] font-semibold text-gold hover:bg-gold/20 transition-colors"
              >
                Yes, clear
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="rounded border border-border/50 px-2 py-0.5 text-[10px] text-silver-muted hover:text-foreground transition-colors"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmReset(true)}
              className="rounded border border-gold/40 bg-obsidian-surface px-2.5 py-1 text-[10px] font-semibold text-gold hover:bg-gold/10 transition-colors"
            >
              New Signal
            </button>
          )}

          {focusedNodeId && (
            <span className="text-xs text-silver-muted">
              Focused: <span className="text-gold">{focusedNodeId}</span>
              <button onClick={() => setFocusedNodeId(null)} className="ml-2 text-muted-foreground hover:text-foreground">
                ✕
              </button>
            </span>
          )}
        </div>
      </div>

      {mapDropdownOpen && (
        <div style={{
          position: "absolute",
          top: "52px",
          left: 0,
          right: 0,
          zIndex: 50,
          background: "rgba(13,11,9,0.97)",
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(212,175,55,0.15)",
          padding: "8px 0",
          maxHeight: 280,
          overflowY: "auto",
        }}>
          {/* Header row */}
          <div style={{
            display: "flex", alignItems: "center",
            justifyContent: "space-between",
            padding: "4px 16px 8px",
            borderBottom: "1px solid rgba(212,175,55,0.08)",
            marginBottom: 4,
          }}>
            <span style={{ fontSize: 9, fontWeight: 700,
              letterSpacing: "0.12em", color: "rgba(212,175,55,0.5)",
              textTransform: "uppercase" }}>
              SYSTEM MAP
            </span>
            <span style={{ fontSize: 9, color: "rgba(156,163,175,0.4)" }}>
              {nodes.filter(n => n.resolved).length}/{nodes.length} resolved
            </span>
          </div>

          {/* Node rows */}
          {nodes.map(node => (
            <div key={node.id}>
              <button
                onClick={() => setExpandedNodeId(
                  expandedNodeId === node.id ? null : node.id
                )}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "8px 16px",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "background 150ms",
                }}
                onMouseEnter={e =>
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(212,175,55,0.04)"}
                onMouseLeave={e =>
                  (e.currentTarget as HTMLButtonElement).style.background = "none"}
              >
                <span style={{
                  width: 6, height: 6, borderRadius: "50%", flexShrink: 0,
                  background: node.resolved ? "#D4AF37" : "transparent",
                  border: node.resolved
                    ? "1px solid #D4AF37"
                    : "1px solid rgba(212,175,55,0.4)",
                  boxShadow: node.resolved
                    ? "0 0 4px rgba(212,175,55,0.5)" : "none",
                }} />
                <span style={{
                  fontSize: 12,
                  color: node.resolved
                    ? "rgba(212,175,55,0.9)"
                    : "rgba(229,231,235,0.6)",
                  flex: 1,
                  fontWeight: node.resolved ? 600 : 400,
                }}>
                  {node.label}
                </span>
                <span style={{
                  fontSize: 9,
                  color: node.resolved
                    ? "rgba(212,175,55,0.5)"
                    : "rgba(156,163,175,0.35)",
                }}>
                  {node.resolved ? "100%" : "0%"}
                </span>
                <span style={{
                  fontSize: 9,
                  color: "rgba(156,163,175,0.3)",
                  marginLeft: 4,
                }}>
                  {expandedNodeId === node.id ? "▲" : "▼"}
                </span>
              </button>

              {/* Expanded detail */}
              {expandedNodeId === node.id && (
                <div style={{
                  padding: "0 16px 10px 32px",
                  fontSize: 11,
                  color: "rgba(229,231,235,0.55)",
                  lineHeight: 1.6,
                  borderBottom: "1px solid rgba(212,175,55,0.06)",
                }}>
                  {node.details
                    ? node.details
                    : node.resolved
                      ? "Node resolved — no detail captured."
                      : (
                        <button
                          onClick={() => {
                            setFocusedNodeId(node.id);
                            setMapDropdownOpen(false);
                          }}
                          style={{
                            display: "inline-flex", alignItems: "center",
                            gap: 5, marginTop: 4, padding: "5px 12px",
                            borderRadius: 16, fontSize: 11,
                            background: "rgba(212,175,55,0.08)",
                            border: "1px solid rgba(212,175,55,0.2)",
                            color: "#D4AF37", cursor: "pointer",
                            fontFamily: "inherit",
                          }}
                        >
                          Define this layer →
                        </button>
                      )
                  }
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Voice input toast */}
      {voiceToast && (
        <div style={{
          position: "absolute", top: 8, left: "50%", transform: "translateX(-50%)",
          zIndex: 9999, background: "rgba(13,11,9,0.97)",
          border: "1px solid rgba(212,175,55,0.4)", borderRadius: 8,
          padding: "8px 16px", color: "#D4AF37", fontSize: 12, fontWeight: 600,
          whiteSpace: "nowrap", boxShadow: "0 4px 16px rgba(0,0,0,0.5)",
          pointerEvents: "none",
        }}>
          Voice input coming soon
        </div>
      )}

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 pt-4 space-y-3" style={{ paddingBottom: "8px" }}>
        {messages.map((msg) => {
          // Detect sprint questions on AI messages (not welcome)
          const sprintQuestions = (msg.role === "system" && msg.id !== "welcome")
            ? parseSprintQuestions(msg.content)
            : null;

          return (
            <div
              key={msg.id}
              className={`${animClass} ${msg.role === "user" ? "ml-auto max-w-[85%]" : "mr-auto max-w-[85%]"}`}
            >
              <div
                className={`rounded-lg px-4 py-2.5 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "glass border-gold/20 text-foreground"
                    : "bg-obsidian-light text-silver"
                }`}
              >
                {/* Image thumbnails in sent user messages */}
                {msg.role === "user" && imagesByMsgId[msg.id] && imagesByMsgId[msg.id].length > 0 && (
                  <div className="flex gap-2 overflow-x-auto mb-2 pb-1">
                    {imagesByMsgId[msg.id].map((src, idx) => (
                      <img
                        key={idx}
                        src={src}
                        alt={`attachment-${idx}`}
                        onClick={() => setLightboxSrc(src)}
                        className="h-20 w-20 rounded-lg object-cover shrink-0 cursor-pointer"
                        style={{ border: "1px solid rgba(212,175,55,0.5)" }}
                      />
                    ))}
                  </div>
                )}
                {sprintQuestions ? (
                  /* Sprint card mode */
                  <SprintCardMessage
                    questions={sprintQuestions}
                    headerText={extractSprintHeader(msg.content, sprintQuestions)}
                    onCompile={handleCompileAnswers}
                    resolveNode={resolveNode}
                    activeKw={activeKw}
                    setActiveKw={setActiveKw}
                  />
                ) : (
                  /* Normal render */
                  renderContent(
                    msg.content,
                    msg.role,
                    activeKw,
                    setActiveKw,
                    msg.role === "system" ? (opt) => {
                      setInput(opt);
                      setTimeout(() => handleSend(), 50);
                    } : undefined
                  )
                )}

                {/* Always-visible copy button on every AI message except welcome */}
                {msg.role === "system" && msg.id !== "welcome" && (
                  <CopyButton text={msg.content} />
                )}
              </div>

              {/* Action bar (hover/tap) for AI messages */}
              {msg.role === "system" && msg.id !== "welcome" && (
                <MessageActionBar
                  msg={msg}
                  isLatestAI={msg.id === latestAIMsgId}
                  onRegenerate={handleRegenerate}
                  isTyping={isTyping}
                />
              )}
            </div>
          );
        })}

        {/* Project profile nudge — appears once after first user message */}
        {!nudgeDismissed && nudgeProfiles.length > 0 && !isTyping && (
          <div
            className="mr-auto max-w-[85%]"
            style={{
              animation: "slideUpSheet 250ms ease-out",
            }}
          >
            <div
              style={{
                background: "rgba(212, 175, 55, 0.06)",
                border: "1px solid rgba(212, 175, 55, 0.2)",
                borderLeft: "3px solid rgba(212, 175, 55, 0.4)",
                borderRadius: 10,
                padding: "10px 12px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: "#9ca3af", lineHeight: 1.4 }}>
                  Have a project profile? Load it to skip the basics.
                </span>
                <button
                  onClick={() => setNudgeDismissed(true)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "rgba(156,163,175,0.4)",
                    fontSize: 12,
                    cursor: "pointer",
                    padding: "2px 4px",
                    marginLeft: 8,
                    flexShrink: 0,
                  }}
                >
                  ✕
                </button>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {nudgeProfiles.slice(0, 3).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleNudgeLoad(p)}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 5,
                      padding: "5px 10px",
                      borderRadius: 8,
                      fontSize: 11,
                      fontWeight: 600,
                      background: "rgba(212,175,55,0.08)",
                      border: "1px solid rgba(212,175,55,0.25)",
                      color: "#D4AF37",
                      cursor: "pointer",
                      transition: "background 150ms",
                    }}
                  >
                    <span style={{ fontSize: 8 }}>◆</span>
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Typing indicator */}
        {isTyping && (
          <div className="mr-auto max-w-[85%]">
            <div className="rounded-lg px-4 py-3 bg-obsidian-light flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="h-2 w-2 rounded-full bg-gold animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </div>
        )}
      </div>

      {/* Dynamic Form Module */}
      {activeModule && FORM_MODULES[activeModule] && (
        <div className="px-4 pb-2">
          <div className="glass rounded-lg p-3">
            <p className="text-xs font-medium text-gold mb-2">{FORM_MODULES[activeModule].label}</p>
            <div className="flex flex-wrap gap-2">
              {FORM_MODULES[activeModule].options.map((opt) => (
                <button
                  key={opt}
                  onClick={() => handleModuleSelect(opt)}
                  className="rounded-md border border-gold/30 bg-obsidian-surface px-3 py-1.5 text-xs text-foreground transition-all hover:border-gold hover:bg-gold/10"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-border/30 px-3 py-3" style={{ paddingBottom: "max(12px, env(safe-area-inset-bottom))", position: "sticky", bottom: 0, zIndex: 10, background: "rgba(13,11,9,0.97)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
        {/* Attached context + image thumbnails */}
        {(attachedContextName || contextError || attachedImages.length > 0) && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-2">
            {attachedContextName && (
              <div className="flex shrink-0 items-center gap-2 rounded-lg border border-gold/40 bg-gold/10 px-2.5 py-1.5 text-[11px] text-gold">
                <span>Codebase loaded: {attachedContextName}</span>
              </div>
            )}
            {contextError && (
              <div className="flex shrink-0 items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-2.5 py-1.5 text-[11px] text-destructive">
                <span>{contextError}</span>
              </div>
            )}
            {attachedImages.map((img) => (
              <div key={img.id} className="relative shrink-0">
                <img
                  src={img.preview}
                  alt={img.name}
                  onClick={() => setLightboxSrc(img.preview)}
                  className="h-14 w-14 rounded-lg object-cover cursor-pointer"
                  style={{ border: "1px solid #D4AF37" }}
                />
                <button
                  onClick={() => removeImage(img.id)}
                  className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-obsidian-surface text-gold text-[10px] font-bold"
                  style={{ border: "1px solid #D4AF37" }}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Glassmorphic input pocket */}
        <div
          style={{
            background: "rgba(13, 11, 9, 0.72)",
            backdropFilter: "blur(16px)",
            WebkitBackdropFilter: "blur(16px)",
            border: `0.5px solid ${inputFocused ? "rgba(212,175,55,0.55)" : "rgba(212,175,55,0.22)"}`,
            borderRadius: 16,
            boxShadow: inputFocused
              ? "0 0 0 3px rgba(212,175,55,0.08), 0 4px 24px rgba(0,0,0,0.3)"
              : "0 2px 12px rgba(0,0,0,0.2)",
            transition: "border-color 200ms, box-shadow 200ms",
            padding: "10px 12px 8px",
          }}
        >
          {/* Platform indicator + textarea row */}
          {detectedBuilder && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
              <span
                style={{
                  fontSize: 10,
                  fontWeight: 700,
                  color: "#D4AF37",
                  background: "rgba(212,175,55,0.12)",
                  border: "0.5px solid rgba(212,175,55,0.35)",
                  borderRadius: 5,
                  padding: "1px 7px",
                  letterSpacing: "0.07em",
                  textTransform: "uppercase",
                  whiteSpace: "nowrap",
                }}
              >
                {detectedBuilder}
              </span>
              <span style={{ fontSize: 10, color: "rgba(156,163,175,0.6)" }}>
                prompt aimed
              </span>
            </div>
          )}

          <style>{`
            @keyframes waveform {
              from { transform: scaleY(0.4); opacity: 0.7; }
              to { transform: scaleY(1); opacity: 1; }
            }
          `}</style>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>

            {/* Textarea — full width */}
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              onFocus={() => setInputFocused(true)}
              onBlur={() => setInputFocused(false)}
              placeholder={inputPlaceholder}
              disabled={isTyping}
              rows={1}
              style={{
                background: "transparent",
                border: "none",
                outline: "none",
                resize: "none",
                fontSize: 14,
                color: "rgba(229,231,235,0.9)",
                lineHeight: "20px",
                minHeight: 20,
                maxHeight: 136,
                overflowY: "auto",
                fontFamily: "inherit",
                opacity: isTyping ? 0.5 : 1,
              }}
              className="placeholder:text-muted-foreground"
            />

            {/* Action row */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>

              {/* Left — paperclip */}
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isTyping}
                  style={{ flexShrink: 0 }}
                  className="flex h-7 w-7 items-center justify-center rounded-lg transition-all disabled:opacity-30"
                  title="Attach images or a codebase ZIP"
                >
                  {attachedImages.length > 0 || attachedContextName ? (
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gold text-gold-foreground text-[10px] font-bold">
                      {attachedImages.length > 0 ? attachedImages.length : "✓"}
                    </span>
                  ) : (
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={inputFocused ? "rgba(212,175,55,0.7)" : "#6b7280"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transition: "stroke 200ms" }}>
                      <path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" />
                    </svg>
                  )}
                </button>
              </div>

              {/* Right — mic + send */}
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button
                  onClick={handleMicClick}
                  disabled={isTyping}
                  title={speechSupported ? (isRecording ? "Stop recording" : "Voice input") : "Voice not supported"}
                  style={{ flexShrink: 0, position: "relative", display: "flex", alignItems: "center", gap: 4 }}
                  className="flex items-center justify-center rounded-lg transition-all disabled:opacity-30"
                >
                  {isRecording ? (
                    <span style={{ display: "flex", alignItems: "center", gap: 2 }}>
                      {[0, 1, 2, 3, 4].map((i) => (
                        <span
                          key={i}
                          style={{
                            display: "inline-block",
                            width: 3,
                            borderRadius: 2,
                            background: "#D4AF37",
                            animation: `waveform 0.8s ease-in-out ${i * 0.1}s infinite alternate`,
                            height: [8, 14, 10, 16, 8][i],
                          }}
                        />
                      ))}
                    </span>
                  ) : (
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                      stroke="rgba(107,114,128,0.7)" strokeWidth="2"
                      strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
                      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                      <line x1="12" y1="19" x2="12" y2="23" />
                      <line x1="8" y1="23" x2="16" y2="23" />
                    </svg>
                  )}
                </button>

                {/* Send */}
                <button
                  onClick={handleSend}
                  disabled={(!input.trim() && attachedImages.length === 0 && !attachedContextName) || isTyping}
                  style={{ flexShrink: 0 }}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-gold text-gold-foreground transition-all hover:shadow-gold disabled:opacity-30"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 2L11 13" /><path d="M22 2L15 22L11 13L2 9L22 2Z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.zip,application/zip,application/x-zip-compressed"
          multiple
          onChange={handleFileSelect}
          style={{ display: "none" }}
        />
      </div>

      {/* Lightbox */}
      {lightboxSrc && (
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/80 backdrop-blur-sm"
          onClick={() => setLightboxSrc(null)}
        >
          <img
            src={lightboxSrc}
            alt="Preview"
            className="max-w-[90vw] max-h-[90vh] rounded-xl object-contain"
            style={{ border: "1px solid rgba(212,175,55,0.4)" }}
          />
        </div>
      )}
    </div>
  );
}

// ─── renderContent ────────────────────────────────────────────────────────────

function renderContent(
  text: string,
  role: "user" | "system",
  activeKw: string | null,
  setActiveKw: (k: string | null) => void,
  onOptionTap?: (text: string) => void
) {
  if (role === "system") {
    return (
      <ReactMarkdown
        components={{
          strong: ({ children }) => (
            <strong style={{ color: "#D4AF37", fontWeight: 600 }}>
              {processChildren(children, activeKw, setActiveKw)}
            </strong>
          ),
          h2: ({ children }) => (
            <h2 style={{ color: "#D4AF37", fontSize: "0.95rem", letterSpacing: "0.05em", textTransform: "uppercase", margin: "0.75rem 0 0.25rem" }}>
              {processChildren(children, activeKw, setActiveKw)}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 style={{ color: "#D4AF37", fontSize: "0.875rem", letterSpacing: "0.05em", textTransform: "uppercase", margin: "0.5rem 0 0.25rem" }}>
              {processChildren(children, activeKw, setActiveKw)}
            </h3>
          ),
          hr: () => (
            <hr style={{ borderColor: "rgba(212, 175, 55, 0.2)", borderTopWidth: 1, margin: "8px 0" }} />
          ),
          ul: ({ children }) => (
            <ul style={{ paddingLeft: onOptionTap ? "0" : "1.25rem", margin: "0.25rem 0" }}>{children}</ul>
          ),
          ol: ({ children }) => (
            <ol style={{ paddingLeft: "1.25rem", margin: "0.25rem 0" }}>{children}</ol>
          ),
          li: ({ children }) => {
            const raw = typeof children === "string"
              ? children
              : Array.isArray(children)
                ? children
                    .map(c => (typeof c === "string" ? c :
                      (c as React.ReactElement<{ children?: React.ReactNode }>)?.props?.children ?? ""))
                    .join("")
                : "";
            const isTappable = onOptionTap &&
              typeof raw === "string" &&
              raw.trim().length > 0 &&
              raw.trim().length < 80 &&
              !raw.includes("\n");

            if (isTappable) {
              return (
                <li style={{ listStyle: "none", marginBottom: 6 }}>
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => onOptionTap!(raw.trim().replace(/\?$/, ""))}
                    onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") onOptionTap!(raw.trim().replace(/\?$/, "")); }}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      padding: "6px 14px",
                      borderRadius: 20,
                      background: "rgba(212,175,55,0.08)",
                      border: "1px solid rgba(212,175,55,0.25)",
                      color: "rgba(212,175,55,0.9)",
                      fontSize: 13,
                      cursor: "pointer",
                      transition: "all 150ms",
                      textAlign: "left",
                      fontFamily: "inherit",
                      userSelect: "none",
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLDivElement).style.background = "rgba(212,175,55,0.15)";
                      (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(212,175,55,0.5)";
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLDivElement).style.background = "rgba(212,175,55,0.08)";
                      (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(212,175,55,0.25)";
                    }}
                  >
                    {raw.trim()}
                  </div>
                </li>
              );
            }
            return (
              <li style={{ lineHeight: 1.6, marginBottom: "0.2rem" }}>
                {processChildren(children, activeKw, setActiveKw)}
              </li>
            );
          },
          p: ({ children }) => (
            <p style={{ marginBottom: "0.5rem", lineHeight: 1.6 }}>
              {processChildren(children, activeKw, setActiveKw)}
            </p>
          ),
          code: ({ children, className }) =>
            className ? (
              <code style={{ background: "rgba(0,0,0,0.3)", color: "#D4AF37", padding: "2px 6px", borderRadius: 4, fontFamily: "monospace", fontSize: "0.8em" }}>{children}</code>
            ) : (
              <code style={{ background: "rgba(212, 175, 55, 0.1)", color: "#D4AF37", padding: "2px 6px", borderRadius: 4, fontFamily: "monospace", fontSize: "0.8em" }}>{children}</code>
            ),
          pre: ({ children }) => (
            <pre style={{ background: "rgba(0,0,0,0.3)", padding: 12, borderRadius: 8, border: "1px solid rgba(212,175,55,0.2)", overflowX: "auto", margin: "0.5rem 0" }}>{children}</pre>
          ),
        }}
      >
        {text}
      </ReactMarkdown>
    );
  }

  // User message — gold keyword highlighting (decorative, no definitions)
  const keywords = ["database", "auth", "api", "login", "table", "route", "state", "component", "logic", "schema"];
  const regex = new RegExp(`\\b(${keywords.join("|")})\\b`, "gi");
  const parts = text.split(regex);
  return parts.map((part, i) =>
    keywords.some((k) => k.toLowerCase() === part.toLowerCase()) ? (
      <span key={i} className="text-gold font-medium">
        {part}
      </span>
    ) : (
      <span key={i}>{part}</span>
    )
  );
}
