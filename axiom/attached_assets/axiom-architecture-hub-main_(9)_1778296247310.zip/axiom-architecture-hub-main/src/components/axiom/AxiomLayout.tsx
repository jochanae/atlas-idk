import { useState, useEffect } from "react";
import { useAxiom } from "@/hooks/use-axiom-store";
import { useFlexMode } from "@/hooks/use-flex-mode";
import { useIsMobile } from "@/hooks/use-mobile";
import { useNavigate } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import { ChatHook } from "./ChatHook";
import { SystemMap } from "./SystemMap";
import { CockpitBar } from "./CockpitBar";
import { FloatingPanel } from "./FloatingPanel";
import { InstallPrompt } from "./InstallPrompt";
import { Settings } from "./Settings";
import { supabase } from "@/integrations/supabase/client";
import { FolderPanel } from "./FolderPanel";
import { Onboarding } from "./Onboarding";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";

// Folder / vault icon (inline SVG — no extra deps)
function VaultIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="#D4AF37"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z" />
    </svg>
  );
}

function AxiomLayoutInner() {
  const isFlex = useFlexMode();
  const isMobile = useIsMobile();
  const { readinessScore } = useAxiom();
  const [chatFullscreen, setChatFullscreen] = useState(false);
  const [chatVisible, setChatVisible] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [collabToast, setCollabToast] = useState(false);
  const [userAvatar, setUserAvatar] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const u = data?.user;
      if (u) {
        setUserAvatar(u.user_metadata?.avatar_url || u.user_metadata?.picture || null);
        setUserName(u.user_metadata?.full_name || u.user_metadata?.name || u.email?.split("@")[0] || "");
      }
    });
  }, []);
  const [folderOpen, setFolderOpen] = useState(false);
  const [activeProject, setActiveProject] = useState<{id:string; name:string} | null>(() => {
    try {
      const r = localStorage.getItem("axiom_active_project");
      return r ? JSON.parse(r) : null;
    } catch { return null; }
  });
  const navigate = useNavigate();

  useEffect(() => {
    const sync = () => {
      try {
        const r = localStorage.getItem("axiom_active_project");
        setActiveProject(r ? JSON.parse(r) : null);
      } catch { setActiveProject(null); }
    };
    window.addEventListener("axiom-project-change", sync);
    return () => window.removeEventListener("axiom-project-change", sync);
  }, []);

  const goToVault = () => {
    haptics.tap();
    sounds.tap();
    navigate({ to: "/vault" });
  };

  // Shared persistent header (desktop + flex + mobile)
  // Absorbs safe-area-inset-top so content is never clipped by notch/island
  const PersistentHeader = ({ showReadiness = false }: { showReadiness?: boolean }) => (
    <div
      className="flex items-center gap-2.5 border-b shrink-0"
      style={{
        background: "rgba(13, 11, 9, 0.95)",
        borderBottomColor: "rgba(212, 175, 55, 0.2)",
        paddingTop: "max(env(safe-area-inset-top), 12px)",
        paddingBottom: "10px",
        paddingLeft: "16px",
        paddingRight: "16px",
        minHeight: "44px",
      }}
    >
      <button
        onClick={() => { haptics.tap(); sounds.tap(); setFolderOpen(true); }}
        title="Projects"
        className="flex items-center justify-center rounded-md p-1 hover:bg-gold/10 transition-colors"
      >
        <VaultIcon size={18} />
      </button>
      <img
        src="/axiom-logo.svg"
        alt="Axiom"
        style={{ width: 28, height: 28, borderRadius: "22%", flexShrink: 0 }}
      />
      <span
        className="text-xs font-bold text-gold animate-shimmer"
        style={{ letterSpacing: "0.1em", fontSize: "13px" }}
      >
        AXIOM
      </span>
      <div className="flex-1" />

      {activeProject && (
        <button
          onClick={() => { haptics.tap(); setFolderOpen(true); }}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 5,
            padding: "3px 10px",
            borderRadius: 20,
            background: "rgba(212,175,55,0.1)",
            border: "1px solid rgba(212,175,55,0.35)",
            color: "#D4AF37",
            fontSize: 10,
            fontWeight: 700,
            letterSpacing: "0.06em",
            maxWidth: 120,
            overflow: "hidden",
            whiteSpace: "nowrap",
            textOverflow: "ellipsis",
            cursor: "pointer",
            marginRight: 6,
          }}
        >
          <span style={{ fontSize: 8 }}>◆</span>
          <span style={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}>
            {activeProject.name}
          </span>
        </button>
      )}

      {showReadiness && (
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold ${readinessScore < 60 ? "text-amber-glow" : "text-gold"}`}>
            {readinessScore}%
          </span>
          <div className="h-2 w-2 rounded-full bg-gold animate-gold-pulse" />
        </div>
      )}

      {/* Divider */}
      <div style={{ width: 1, height: 20, background: "rgba(212,175,55,0.25)", marginLeft: 4, flexShrink: 0 }} />

      {/* Avatar stack */}
      <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
        {/* A squircle — opens Settings */}
        <button
          onClick={() => setSettingsOpen(true)}
          title="Your profile"
          style={{
            width: 32,
            height: 32,
            borderRadius: "22%",
            background: "#0D0B09",
            border: "1.5px solid #D4AF37",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            position: "relative",
            zIndex: 2,
            cursor: "pointer",
          }}
        >
          {userAvatar ? (
            <img
              src={userAvatar}
              alt={userName}
              style={{ width: 32, height: 32, borderRadius: "22%", objectFit: "cover" }}
              referrerPolicy="no-referrer"
            />
          ) : (
            <span style={{ fontSize: 13, fontWeight: 700, color: "#D4AF37", lineHeight: 1 }}>
              {userName?.[0]?.toUpperCase() || "A"}
            </span>
          )}
        </button>

        {/* + squircle — collaboration coming soon */}
        <button
          onClick={() => {
            setCollabToast(true);
            setTimeout(() => setCollabToast(false), 2200);
          }}
          title="Collaboration coming soon"
          style={{
            width: 24,
            height: 24,
            borderRadius: "22%",
            background: "transparent",
            border: "1px dashed rgba(212,175,55,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            marginLeft: -4,
            position: "relative",
            zIndex: 1,
            cursor: "pointer",
          }}
        >
          <span style={{ fontSize: 11, color: "rgba(212,175,55,0.5)", lineHeight: 1 }}>+</span>
        </button>

        {/* Collab toast */}
        {collabToast && (
          <div style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            right: 0,
            whiteSpace: "nowrap",
            background: "#0D0B09",
            border: "1px solid rgba(212,175,55,0.35)",
            borderRadius: 8,
            padding: "6px 12px",
            fontSize: 11,
            fontWeight: 600,
            color: "#D4AF37",
            zIndex: 9999,
            boxShadow: "0 4px 16px rgba(0,0,0,0.5)",
          }}>
            Collaboration coming soon
          </div>
        )}
      </div>
    </div>
  );

  // Flex Mode — Z Fold 6 Tactical Workstation
  if (isFlex) {
    return (
      <div className="flex flex-col bg-background" style={{ height: "100dvh", overflow: "hidden" }}>
        <Onboarding />
        <PersistentHeader showReadiness />
        <div className="relative flex-1 border-b border-border/30">
          <SystemMap />
        </div>
        <div className="relative h-1 bg-obsidian-surface">
          <div
            className="absolute left-0 top-0 h-full transition-all duration-1000"
            style={{
              width: `${readinessScore}%`,
              background: "var(--gradient-gold)",
              boxShadow: "0 0 12px oklch(0.76 0.12 85 / 40%)",
            }}
          />
        </div>
        <div className="flex-1">
          <ChatHook />
        </div>
        <CockpitBar />
        <FloatingPanel />
        <InstallPrompt />
        <Settings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
        <FolderPanel open={folderOpen} onClose={() => setFolderOpen(false)} />
      </div>
    );
  }

  // Mobile
  if (isMobile) {
    return (
      <div className="flex flex-col bg-background" style={{ height: "100dvh", overflow: "hidden" }}>
        <Onboarding />
        {/* Persistent header — always visible, safe-area-aware */}
        <PersistentHeader showReadiness />

        {/* System Map — hidden when chat is fullscreen */}
        {!chatFullscreen && (
          <div className={`relative border-b border-border/30 ${chatVisible ? "h-[40vh]" : "flex-1"}`}>
            <SystemMap />
          </div>
        )}

        {/* Chat Toggle */}
        <div
          className="w-full border-y py-2.5 text-xs font-medium text-gold flex items-center justify-center gap-3 shrink-0"
          style={{
            borderColor: "oklch(0.76 0.12 85 / 25%)",
            background: "oklch(0.13 0.01 60)",
            minHeight: "44px",
          }}
        >
          <button
            onClick={() => {
              if (chatFullscreen) {
                setChatFullscreen(false);
              } else {
                setChatVisible((v) => !v);
              }
            }}
            className="text-xs font-medium text-gold"
          >
            {chatFullscreen
              ? "▼ Collapse Chat"
              : chatVisible
                ? "▼ Hide Chat — See Full Map"
                : "▲ Show Chat"}
          </button>
          {chatVisible && !chatFullscreen && (
            <button
              onClick={() => setChatFullscreen(true)}
              className="ml-2 rounded border border-gold/30 px-2 py-0.5 text-[10px] text-gold hover:bg-gold/10 transition-colors"
            >
              ⛶ Fullscreen
            </button>
          )}
        </div>

        {/* Chat */}
        {(chatVisible || chatFullscreen) && (
          <div
            className="flex-1 min-h-0"
            style={{
              minHeight: "160px",
            }}
          >
            <ChatHook />
          </div>
        )}

        <CockpitBar />
        <FloatingPanel />
        <InstallPrompt />
        <Settings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
        <FolderPanel open={folderOpen} onClose={() => setFolderOpen(false)} />
      </div>
    );
  }

  // Desktop — Architect Mode
  return (
    <div className="flex flex-col bg-background" style={{ height: "100dvh", overflow: "hidden" }}>
      <Onboarding />
      <PersistentHeader />
      <div className="flex flex-1 min-h-0">
        {/* Left: Chat Hook 40% */}
        <div className="w-[40%] border-r border-border/30">
          <ChatHook />
        </div>
        {/* Right: System Map 60% */}
        <div className="relative w-[60%]">
          <SystemMap />
        </div>
      </div>
      <CockpitBar />
      <FloatingPanel />
      <InstallPrompt />
      <Settings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <FolderPanel open={folderOpen} onClose={() => setFolderOpen(false)} />
    </div>
  );
}

export function AxiomLayout() {
  return (
    <ClientOnly fallback={
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="text-center">
          <div className="text-2xl font-bold animate-shimmer">AXIOM</div>
          <p className="mt-2 text-xs text-silver-muted">Initializing Structural Engine...</p>
        </div>
      </div>
    }>
      <AxiomLayoutInner />
    </ClientOnly>
  );
}
