import { useAxiom, type ArchNode } from "@/hooks/use-axiom-store";
import { useCallback, useEffect, useRef, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "sonner";
import { haptics } from "@/lib/haptics";
import { sounds } from "@/lib/sounds";

const NODE_ICONS: Record<string, string> = {
  database: "⬡",
  api: "◈",
  auth: "◉",
  state: "◆",
  logic: "△",
  ui: "□",
};

const NODE_DESCRIPTIONS: Record<string, string> = {
  auth: "Controls who can access your app and how they prove their identity. Must be defined before anything else.",
  db: "The permanent storage layer. Every piece of data your app remembers lives here in structured tables.",
  api: "The communication layer between your UI and your database. Routes define how data flows in and out.",
  state: "Temporary memory your app holds while a user is active. Manages UI interactions before data is saved.",
  ui: "The visual shell — screens, components, and layouts your users interact with directly.",
  logic: "The rules engine — business logic, calculations, validations, and automated processes.",
};

const NODE_PIVOT_QUESTIONS: Record<string, string> = {
  auth: "Who needs to log in, and how should they verify their identity?",
  db: "What are the main things your app needs to remember permanently?",
  api: "What actions will your app need to perform on that data?",
  state: "What does your app need to remember while a user is actively using it?",
  ui: "What are the primary screens or views your users will navigate between?",
  logic: "What rules or calculations does your app need to enforce automatically?",
};

const SPRINT_MAP: Record<string, number> = {
  auth: 1, db: 1,
  api: 2, logic: 2,
  ui: 3, state: 3,
};

const SPRINT_LABELS = [
  { sprint: 1, x: 180, y: 60 },
  { sprint: 2, x: 350, y: 250 },
  { sprint: 3, x: 180, y: 390 },
];

const EDGE_FLOW_STYLE = `
@keyframes edge-flow {
  from { stroke-dashoffset: 0; }
  to   { stroke-dashoffset: -20; }
}
`;

const ZOOM_MIN = 0.5;
const ZOOM_MAX = 2;
const ZOOM_DEFAULT_MOBILE = 0.85;
const ZOOM_DEFAULT_DESKTOP = 1;
const TAP_THRESHOLD = 8;
const CANVAS_PADDING = 80;

export function SystemMap() {
  const { nodes, edges, detectedBuilder, setFocusedNodeId, atmosphere, addMessage } = useAxiom();
  const isMobile = useIsMobile();

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  const defaultZoom = isMobile ? ZOOM_DEFAULT_MOBILE : ZOOM_DEFAULT_DESKTOP;
  const [zoom, setZoom] = useState(defaultZoom);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [activeCardNodeId, setActiveCardNodeId] = useState<string | null>(null);

  // Touch/mouse state refs (avoid re-renders during drag)
  const dragState = useRef({
    dragging: false,
    startX: 0,
    startY: 0,
    startPanX: 0,
    startPanY: 0,
    moved: false,
    lastTap: 0,
    lastNodeTapTime: 0,
    pinchStartDist: 0,
    pinchStartZoom: 1,
  });

  // Fit map to container
  const fitMap = useCallback(() => {
    if (!containerRef.current || nodes.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const minX = Math.min(...nodes.map((n) => n.x)) - 40;
    const maxX = Math.max(...nodes.map((n) => n.x)) + 40;
    const minY = Math.min(...nodes.map((n) => n.y)) - 30;
    const maxY = Math.max(...nodes.map((n) => n.y)) + 60;
    const mapW = maxX - minX + CANVAS_PADDING * 2;
    const mapH = maxY - minY + CANVAS_PADDING * 2;
    const scaleX = rect.width / mapW;
    const scaleY = rect.height / mapH;
    const newZoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, Math.min(scaleX, scaleY)));
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    setZoom(newZoom);
    setPan({
      x: rect.width / 2 / newZoom - centerX,
      y: rect.height / 2 / newZoom - centerY,
    });
  }, [nodes]);

  // Fit on mount and when mobile chat toggles (container resizes)
  useEffect(() => {
    fitMap();
    const observer = new ResizeObserver(() => fitMap());
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [fitMap]);

  const resetView = useCallback(() => {
    fitMap();
    toast("Map Reset", {
      duration: 1000,
      style: { color: "#D4AF37", background: "oklch(0.15 0.01 60)", border: "1px solid oklch(0.76 0.12 85 / 30%)" },
    });
  }, [fitMap]);

  // --- Mouse events (desktop) ---
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    const ds = dragState.current;
    ds.dragging = true;
    ds.startX = e.clientX;
    ds.startY = e.clientY;
    ds.startPanX = pan.x;
    ds.startPanY = pan.y;
    ds.moved = false;
  }, [pan]);

  const onMouseMove = useCallback((e: React.MouseEvent) => {
    const ds = dragState.current;
    if (!ds.dragging) return;
    const dx = e.clientX - ds.startX;
    const dy = e.clientY - ds.startY;
    if (Math.abs(dx) > TAP_THRESHOLD || Math.abs(dy) > TAP_THRESHOLD) ds.moved = true;
    setPan({ x: ds.startPanX + dx / zoom, y: ds.startPanY + dy / zoom });
  }, [zoom]);

  const onMouseUp = useCallback(() => {
    dragState.current.dragging = false;
  }, []);

  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    setZoom((z) => Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, z - e.deltaY * 0.001)));
  }, []);

  const onDoubleClick = useCallback(() => {
    resetView();
  }, [resetView]);

  // Close card on background click (nodes stop propagation)
  const onContainerClick = useCallback(() => {
    if (!dragState.current.moved && Date.now() - dragState.current.lastNodeTapTime > 150) {
      setActiveCardNodeId(null);
    }
  }, []);

  // --- Touch events (mobile) ---
  const onTouchStart = useCallback((e: React.TouchEvent) => {
    const ds = dragState.current;
    if (e.touches.length === 1) {
      ds.dragging = true;
      ds.startX = e.touches[0].clientX;
      ds.startY = e.touches[0].clientY;
      ds.startPanX = pan.x;
      ds.startPanY = pan.y;
      ds.moved = false;
    } else if (e.touches.length === 2) {
      ds.dragging = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      ds.pinchStartDist = Math.hypot(dx, dy);
      ds.pinchStartZoom = zoom;
    }
  }, [pan, zoom]);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    const ds = dragState.current;
    if (e.touches.length === 1 && ds.dragging) {
      const dx = e.touches[0].clientX - ds.startX;
      const dy = e.touches[0].clientY - ds.startY;
      if (Math.abs(dx) > TAP_THRESHOLD || Math.abs(dy) > TAP_THRESHOLD) ds.moved = true;
      setPan({ x: ds.startPanX + dx / zoom, y: ds.startPanY + dy / zoom });
    } else if (e.touches.length === 2 && ds.pinchStartDist > 0) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const newZoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, ds.pinchStartZoom * (dist / ds.pinchStartDist)));
      setZoom(newZoom);
    }
  }, [zoom]);

  const onTouchEnd = useCallback((e: React.TouchEvent) => {
    const ds = dragState.current;
    ds.dragging = false;
    // Double-tap detection
    if (e.changedTouches.length === 1 && !ds.moved) {
      const now = Date.now();
      if (now - ds.lastTap < 180) {
        resetView();
        ds.lastTap = 0;
      } else {
        ds.lastTap = now;
      }
    }
  }, [resetView]);

  const handleNodeTap = useCallback((nodeId: string, e: React.MouseEvent | React.TouchEvent) => {
    dragState.current.lastNodeTapTime = Date.now();
    dragState.current.dragging = false;
    if (!dragState.current.moved) {
      e.stopPropagation();

      // Existing focus behavior (still happens)
      setFocusedNodeId(nodeId);

      if (activeCardNodeId === nodeId) {
        // Tap same node again — close the card
        setActiveCardNodeId(null);
      } else {
        haptics.tap();
        sounds.tap();
        setActiveCardNodeId(nodeId);

        // Context-aware pivot message
        const node = nodes.find((n) => n.id === nodeId);
        if (node) {
          const pivotContent = node.resolved
            ? `Your ${node.label} layer is locked. To modify it, describe what you want to change.`
            : `Let's define your ${node.label}. ${NODE_PIVOT_QUESTIONS[nodeId] || ""}`;
          addMessage({
            id: crypto.randomUUID(),
            role: "system",
            content: pivotContent,
            timestamp: Date.now(),
          });
        }
      }
    }
  }, [setFocusedNodeId, activeCardNodeId, nodes, addMessage]);

  const builderClass = detectedBuilder === "lovable"
    ? "pulse-lovable"
    : detectedBuilder === "cursor"
    ? "pulse-cursor"
    : detectedBuilder === "replit"
    ? "pulse-replit"
    : "";

  const strokeWidth = Math.max(1, Math.min(2, 1.5 / zoom));

  // Compute card position in container-space from the active node
  const activeCardNode = activeCardNodeId ? nodes.find((n) => n.id === activeCardNodeId) : null;
  let cardLeft = 0;
  let cardTop = 0;
  const CARD_W = 220;
  if (activeCardNode) {
    const nodeScreenX = (activeCardNode.x + pan.x) * zoom;
    const nodeScreenY = (activeCardNode.y + pan.y) * zoom;
    cardLeft = nodeScreenX - CARD_W / 2;
    cardTop = nodeScreenY - 150; // try above the node
    const containerW = containerRef.current?.offsetWidth ?? 600;
    // Clamp horizontally
    cardLeft = Math.max(8, Math.min(cardLeft, containerW - CARD_W - 8));
    // If not enough room above, place below
    if (cardTop < 50) cardTop = nodeScreenY + 70;
  }

  return (
    <div
      ref={containerRef}
      className={`relative h-full w-full overflow-hidden rounded-lg system-map-glow ${builderClass}`}
      style={{ transition: "box-shadow 1s ease", touchAction: "none", cursor: dragState.current.dragging ? "grabbing" : "grab" }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onWheel={onWheel}
      onDoubleClick={onDoubleClick}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onClick={onContainerClick}
    >
      {/* Edge-flow keyframe injection */}
      <style>{EDGE_FLOW_STYLE}</style>

      {/* Grid background */}
      <div className="absolute inset-0" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, oklch(0.30 0.01 60 / 30%) 1px, transparent 0)`,
        backgroundSize: "40px 40px",
      }} />

      {/* Header */}
       <div className="absolute left-4 top-4 z-10 flex flex-col gap-1.5">
        <span className="text-xs font-semibold text-gold">SYSTEM MAP</span>
        {detectedBuilder && (
          <span className="self-start rounded-full border border-gold/30 bg-obsidian-surface px-2 py-0.5 text-[10px] text-gold-muted">
            {detectedBuilder.toUpperCase()} DETECTED
          </span>
        )}
      </div>

      {/* Transformable canvas */}
      <div
        ref={canvasRef}
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          transformOrigin: "0 0",
          transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)`,
        }}
      >
        {/* Sprint cluster ghost labels */}
        {SPRINT_LABELS.map(({ sprint, x, y }) => (
          <div
            key={sprint}
            style={{
              position: "absolute",
              left: x,
              top: y,
              fontSize: 9,
              fontWeight: 700,
              letterSpacing: "0.12em",
              color: "rgba(212,175,55,0.10)",
              textTransform: "uppercase",
              pointerEvents: "none",
              userSelect: "none",
              whiteSpace: "nowrap",
            }}
          >
            Sprint {sprint}
          </div>
        ))}

        {/* SVG layer for edges */}
        <svg className="absolute inset-0 h-full w-full" style={{ overflow: "visible" }}>
          {edges.map((edge) => {
            const fromNode = nodes.find((n) => n.id === edge.from);
            const toNode = nodes.find((n) => n.id === edge.to);
            if (!fromNode || !toNode) return null;
            const bothResolved = fromNode.resolved && toNode.resolved;
            return (
              <line
                key={edge.id}
                x1={fromNode.x}
                y1={fromNode.y}
                x2={toNode.x}
                y2={toNode.y}
                stroke={bothResolved ? "rgba(212,175,55,0.6)" : "oklch(0.35 0.01 60 / 50%)"}
                strokeWidth={strokeWidth}
                strokeDasharray={bothResolved ? "4 4" : "6 4"}
                style={bothResolved ? { animation: "edge-flow 1.5s linear infinite" } : undefined}
              />
            );
          })}
        </svg>

        {/* Nodes */}
        {nodes.map((node) => (
          <NodeComponent
            key={node.id}
            node={node}
            onFocus={handleNodeTap}
            atmosphere={atmosphere}
          />
        ))}
      </div>

      {/* Node Info Card — rendered in container space, above canvas transform */}
      {activeCardNode && (
        <div
          style={{
            position: "absolute",
            left: cardLeft,
            top: cardTop,
            width: CARD_W,
            zIndex: 50,
            background: "rgba(20, 18, 14, 0.95)",
            border: "1px solid rgba(212, 175, 55, 0.4)",
            borderRadius: 10,
            padding: 12,
            boxShadow: "0 4px 20px rgba(0,0,0,0.6)",
            pointerEvents: "auto",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close button */}
          <button
            onClick={(e) => { e.stopPropagation(); setActiveCardNodeId(null); }}
            style={{
              position: "absolute",
              top: 6,
              right: 8,
              color: "#9ca3af",
              background: "none",
              border: "none",
              cursor: "pointer",
              fontSize: 14,
              lineHeight: 1,
              padding: "2px 4px",
            }}
          >
            ✕
          </button>

          {/* Node name */}
          <div style={{ fontSize: 12, fontWeight: 600, color: "#D4AF37", marginBottom: 4, paddingRight: 20 }}>
            {activeCardNode.label}
          </div>

          {/* Status */}
          <div style={{ fontSize: 11, marginBottom: 8, color: activeCardNode.resolved ? "#D4AF37" : "#F59E0B" }}>
            {activeCardNode.resolved ? "✓ Resolved" : "○ Needs Definition"}
          </div>

          {/* Description */}
          <div style={{ fontSize: 11, color: "#9ca3af", lineHeight: 1.5, marginBottom: 8 }}>
            {NODE_DESCRIPTIONS[activeCardNodeId!] || ""}
          </div>

          {/* Resolved details section */}
          {activeCardNode.resolved && (
            <div style={{
              fontSize: 12,
              color: "rgba(229,231,235,0.8)",
              lineHeight: 1.6,
              maxHeight: 160,
              overflowY: "auto",
              marginTop: 8,
              borderTop: "1px solid rgba(212,175,55,0.15)",
              paddingTop: 8,
            }}>
              {(activeCardNode as any).details
                ? (activeCardNode as any).details
                : "No details captured yet for this node."}
            </div>
          )}

          {/* Tap-to-define prompt (unresolved only) */}
          {!activeCardNode.resolved && (
            <div style={{ fontSize: 11, color: "#9ca3af", fontStyle: "italic" }}>
              Tap to define this layer in the chat
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function NodeComponent({
  node,
  onFocus,
  atmosphere,
}: {
  node: ArchNode;
  onFocus: (id: string, e: React.MouseEvent | React.TouchEvent) => void;
  atmosphere: string;
}) {
  return (
    <button
      onClick={(e) => onFocus(node.id, e)}
      onTouchEnd={(e) => { e.preventDefault(); onFocus(node.id, e); }}
      className={`absolute flex flex-col items-center gap-1 transition-all duration-300 ${
        node.resolved ? "animate-node-resolve" : ""
      }`}
      style={{ left: node.x - 40, top: node.y - 30 }}
    >
      <div
        className={`flex h-16 w-16 items-center justify-center rounded-xl border text-lg transition-all ${
          node.resolved
            ? "border-gold bg-gold/15 text-gold shadow-gold"
            : "border-amber-glow/40 bg-obsidian-surface text-amber-glow animate-amber-pulse"
        }`}
      >
        {NODE_ICONS[node.type] || "●"}
      </div>
      <span className={`text-[10px] font-medium whitespace-nowrap ${
        node.resolved ? "text-gold" : "text-silver-muted"
      }`}>
        {node.label}
      </span>
      <span style={{
        fontSize: 9,
        color: node.resolved ? "#D4AF37" : "#F59E0B",
        lineHeight: 1,
      }}>
        {node.resolved ? "100%" : (node as any).details ? "50%" : "0%"}
      </span>
    </button>
  );
}
